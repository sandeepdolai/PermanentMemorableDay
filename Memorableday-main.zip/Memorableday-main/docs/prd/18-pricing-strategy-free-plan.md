# 18 — Pricing Strategy & Free Plan

**Sections:** §39 Pricing Strategy · §40 Free Plan  
**PRD Index:** [← Payments & Entitlements](17-payments-lemon-squeezy-entitlements.md) | [Next: SEO →](19-seo-content-programmatic-seo.md)

---

## §39 Pricing Strategy

### 39.1 Pricing Philosophy

MemorableDay's pricing must:
- Be simple enough to understand in 30 seconds
- Reflect genuine value (not arbitrary feature gating)
- Create a clear upgrade path at every stage
- Be competitive with adjacent tools while reflecting the unique value of the platform
- Support both personal and business audiences with distinct pricing tracks

**Pricing principles:**
- Personal pricing is affordable and accessible (impulse-buy range)
- Business pricing reflects measurable ROI (subscription to a business tool)
- Free plan drives acquisition and viral growth
- Annual plans reward commitment with meaningful discounts
- No surprise charges or hidden fees

### 39.2 Recommended Plan Structure

MemorableDay has two pricing tracks: **Personal** and **Business**.

#### Personal Track

| Plan | Monthly | Annual (per month) | Annual Savings |
|---|---|---|---|
| **Starter (Free)** | $0 | $0 | — |
| **Personal** | $9/mo | $7/mo | 22% |
| **Pro** | $19/mo | $15/mo | 21% |

#### Business Track

| Plan | Monthly | Annual (per month) | Annual Savings |
|---|---|---|---|
| **Business** | $49/mo | $39/mo | 20% |
| **Growth** | $99/mo | $79/mo | 20% |
| **Agency** | $249/mo | $199/mo | 20% |
| **Enterprise** | Custom | Custom | — |

### 39.3 Plan Descriptions

#### Starter (Free)
**For:** Anyone who wants to try MemorableDay  
**Tagline:** "Create your first memorable moment"  
**Key features:** 3 published experiences, 5 AI credits, 10 templates, basic analytics, MemorableDay branding

#### Personal — $9/month
**For:** Individuals who regularly create experiences for people they love  
**Tagline:** "For people who make every occasion special"  
**Key features:** 20 published experiences, 30 AI credits, all personal templates, scheduling, video upload, 1.5GB storage

#### Pro — $19/month
**For:** Power users who want the full personal experience  
**Tagline:** "The complete personal experience toolkit"  
**Key features:** Unlimited experiences, 100 AI credits, all templates, advanced analytics, branching experiences, 7GB storage

#### Business — $49/month
**For:** Small e-commerce businesses and Shopify merchants  
**Tagline:** "Turn every customer touchpoint into a moment they remember"  
**Key features:** 3 automations, Shopify integration, all business templates, team (3 members), rewards, 15GB storage

#### Growth — $99/month
**For:** Growing DTC brands and marketing teams  
**Tagline:** "Scale your customer experience without losing the personal touch"  
**Key features:** 10 automations, all integrations, white label, custom domain, 10 team members, drip sequences, 35GB storage

#### Agency — $249/month
**For:** Digital agencies managing multiple client brands  
**Tagline:** "One platform for all your clients"  
**Key features:** 10 brands, 25 automations per brand, full white label, 25 team members, client management, 70GB storage

#### Enterprise — Custom
**For:** Large brands and enterprises with custom requirements  
**Tagline:** "Built for your scale"  
**Key features:** Unlimited everything, SSO, SLA, dedicated support, custom integrations, custom AI credits

### 39.4 Pricing Rationale

**Why $9 for Personal?**
- Below the psychological $10 threshold
- Comparable to Netflix, Spotify — familiar subscription price
- Covers infrastructure costs with margin
- Low enough to be an impulse purchase

**Why $49 for Business?**
- Entry-level business SaaS pricing
- Comparable to Klaviyo's starter plan, Postscript, etc.
- Justifiable with a single prevented negative review or one repeat purchase
- Low enough for small Shopify merchants to try

**Why $99 for Growth?**
- Mid-market SaaS pricing
- Justifiable with measurable retention improvement
- Includes white label (significant value for agencies)

**Why $249 for Agency?**
- Agency plans command premium pricing
- Multi-brand management is a significant value multiplier
- Agencies can charge clients $50–$200/month each, making $249 very profitable

### 39.5 Pricing Comparison

| Competitor | Price | What They Offer |
|---|---|---|
| Hallmark (digital) | $3–$5/card | Static digital cards |
| Moonpig | $5–$10/card | Physical + digital cards |
| Evite | $0–$20/event | Digital invitations |
| Klaviyo (email) | $45–$700/mo | Email marketing |
| AfterShip | $11–$239/mo | Shipment tracking |
| Wonderment | $99–$499/mo | Post-purchase experience |
| Postscript (SMS) | $100+/mo | SMS marketing |

**MemorableDay's pricing advantage:**
- More emotionally impactful than any competitor
- Combines personal + business use cases
- 3D + AI + automation in one platform
- Significantly cheaper than building custom post-purchase experiences

### 39.6 Pricing Page Requirements

**Requirements:**
- `PRD-SEO-005`: Pricing page must be publicly accessible at `memorableday.online/pricing`
- `PRD-UX-024`: Pricing page must clearly show the difference between personal and business tracks
- `PRD-UX-025`: Pricing page must include a plan comparison table
- `PRD-UX-026`: Pricing page must include a FAQ section addressing common objections
- `PRD-UX-027`: Pricing page must include social proof (testimonials, logos)
- `PRD-UX-028`: Annual/monthly toggle must be prominent and easy to use
- `PRD-UX-029`: "Most popular" badge must be shown on the recommended plan (Business for business track, Personal for personal track)

### 39.7 Upgrade Prompts

**Requirements:**
- `PRD-UX-030`: Upgrade prompts must appear at the point of limit (not just in billing settings)
- `PRD-UX-031`: Upgrade prompts must show the specific benefit of upgrading (not just "upgrade to unlock")
- `PRD-UX-032`: Upgrade prompts must include a direct link to the checkout for the recommended plan
- `PRD-UX-033`: Upgrade prompts must not be intrusive — they should appear once per session, not on every action

### 39.8 Pricing Experiments

The pricing structure above is a recommendation, not a final decision. The following should be A/B tested:

| Test | Hypothesis |
|---|---|
| $9 vs $12 for Personal | Higher price may not reduce conversion significantly |
| $49 vs $59 for Business | Higher price may not reduce conversion significantly |
| 14-day trial vs no trial | Trial may increase Business plan conversion |
| Annual discount 20% vs 25% | Higher discount may increase annual plan adoption |
| Pay-per-experience vs subscription | Some users may prefer pay-per-experience |

---

## §40 Free Plan

### 40.1 Free Plan Philosophy

The free plan is a strategic product decision, not a charity. It must:

1. **Drive acquisition** — give users a reason to sign up without a credit card
2. **Drive viral growth** — free users create experiences that recipients see
3. **Drive conversion** — free users must hit limits that make upgrading obvious
4. **Not be economically unsustainable** — free users must not cost more than they're worth

**The free plan is not:**
- A full-featured product (that would eliminate the upgrade incentive)
- A crippled product (that would drive users away)
- A marketing trick (that would damage trust)

### 40.2 Free Plan Features

| Feature | Free Plan |
|---|---|
| Published experiences | 3 (lifetime, not monthly) |
| Experience views/month | 500 |
| AI credits/month | 5 |
| Templates | 10 (curated selection) |
| 3D objects | Limited library (10 objects) |
| Photo upload | ✓ (up to 5 photos per experience) |
| Video upload | ✗ |
| Voice messages | ✗ |
| Custom music | ✗ |
| Scheduling | ✗ |
| Password protection | ✗ |
| Analytics | Basic (opened: yes/no) |
| Rewards | ✗ |
| Business automations | ✗ |
| Team members | 1 |
| Storage | 100MB |
| MemorableDay branding | Required (cannot remove) |
| Custom domain | ✗ |

### 40.3 Free Plan Limits Rationale

**Why 3 published experiences (not monthly)?**
- Creates urgency to upgrade without being too restrictive
- 3 experiences is enough to experience the product's value
- Lifetime limit (not monthly) means free users don't get unlimited experiences by waiting

**Why 5 AI credits/month?**
- Enough to experience AI value (1–2 complete experiences)
- Not enough to rely on AI without upgrading
- Resets monthly to keep users engaged

**Why no scheduling?**
- Scheduling is a key value driver for Personal plan
- Removing it creates a clear upgrade reason for occasion-based users

**Why no video upload?**
- Video is a significant storage cost driver
- Removing it keeps free plan infrastructure costs low

### 40.4 Free Plan Conversion Strategy

**Conversion triggers (moments when free users are most likely to upgrade):**

| Trigger | Upgrade Prompt |
|---|---|
| Creating 3rd experience | "You've used all 3 free experiences. Upgrade to Personal for unlimited experiences." |
| Trying to schedule | "Scheduling is available on Personal plan. Upgrade to schedule this experience." |
| Trying to upload video | "Video upload is available on Personal plan. Upgrade to add video." |
| Running out of AI credits | "You've used all 5 AI credits. Upgrade for 30 credits/month." |
| Trying to remove branding | "Remove MemorableDay branding on Pro plan." |
| Recipient opens experience | "Your experience was opened! Upgrade to see detailed analytics." |

**Requirements:**
- `PRD-UX-034`: Conversion prompts must be contextual and specific
- `PRD-UX-035`: Conversion prompts must show the exact plan that unlocks the feature
- `PRD-UX-036`: Conversion prompts must include a direct checkout link
- `PRD-UX-037`: Free users must be able to see what they're missing (feature preview with lock icon)

### 40.5 Free Plan Infrastructure Cost

**Estimated cost per free user per month:**
- Storage (100MB): ~$0.002 (Cloudflare R2)
- CDN bandwidth (500 views × ~1MB): ~$0.05 (Cloudflare CDN)
- AI credits (5 × ~$0.01): ~$0.05
- Compute (Cloudflare Workers): ~$0.01
- **Total: ~$0.11/month per free user**

At 100,000 free users: ~$11,000/month in infrastructure costs.

This is acceptable if free-to-paid conversion rate is ≥ 3% (3,000 paying users × $9/month = $27,000 MRR).

**Requirements:**
- `PRD-INFRA-001`: Free plan infrastructure costs must be monitored monthly
- `PRD-INFRA-002`: If free plan costs exceed 20% of MRR, free plan limits must be reviewed

### 40.6 Free Plan Abuse Prevention

**Requirements:**
- `PRD-SEC-025`: Free plan must require email verification before creating experiences
- `PRD-SEC-026`: Free plan must have rate limiting on experience creation (max 3 per day)
- `PRD-SEC-027`: Free plan must have rate limiting on AI usage (max 2 per day)
- `PRD-SEC-028`: Multiple free accounts from the same IP/device must be detected and flagged
- `PRD-SEC-029`: Free plan experiences must be subject to content moderation

---

*Next: [SEO, Content & Programmatic SEO →](19-seo-content-programmatic-seo.md)*
