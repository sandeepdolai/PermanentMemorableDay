# 29 — Product Roadmap

**Section:** §67 Product Roadmap  
**PRD Index:** [← Risks & Dependencies](28-risks-edge-cases-dependencies.md) | [Next: Future Opportunities →](30-future-opportunities.md)

---

## §67 Product Roadmap

### 67.1 Roadmap Philosophy

The roadmap sequences delivery of the complete product vision. It does not remove features from the vision — it organizes them by dependency, risk, and business value.

**Roadmap principles:**
- Infrastructure before features (you can't build on sand)
- Core before advanced (nail the basics before adding complexity)
- Personal before business (simpler to build; validates core product)
- Validate before scaling (prove value before investing in scale)
- Revenue before growth (sustainable business before aggressive growth)

### 67.2 Feature Prioritization Framework

All features are categorized:

| Category | Definition | Examples |
|---|---|---|
| **Core** | Essential for the product to exist; must be at launch | Experience builder, 3D system, templates, sharing |
| **Important** | Significantly improves value; should be early | AI features, scheduling, analytics, Shopify integration |
| **Advanced** | Adds power for engaged users; Phase 2 | Branching experiences, drip sequences, advanced analytics |
| **Premium** | Justifies higher plan pricing; Phase 2 | White label, custom domains, agency features |
| **Enterprise** | Required for enterprise customers; Phase 3 | SSO, SLA, custom integrations, dedicated support |
| **Experimental** | Unproven; explore carefully | AR experiences, voice activation, mini-games |

### 67.3 Phase 0: Foundation (Months 1–2)

**Goal:** Build the infrastructure and core platform that everything else depends on.

**Infrastructure:**
- [ ] Cloudflare account setup (Pages, Workers, R2, D1)
- [ ] Domain configuration (`memorableday.online`, `app.memorableday.online`)
- [ ] SSL/TLS configuration
- [ ] DNS configuration
- [ ] CI/CD pipeline
- [ ] Error monitoring (Sentry)
- [ ] Uptime monitoring

**Authentication:**
- [ ] Email + password authentication
- [ ] Google OAuth
- [ ] Email verification
- [ ] Password reset
- [ ] Session management

**Database:**
- [ ] Database schema design
- [ ] Cloudflare D1 setup
- [ ] Migration system

**Billing:**
- [ ] Lemon Squeezy account setup
- [ ] Products and variants created
- [ ] Webhook endpoint
- [ ] Subscription status sync
- [ ] Entitlement system

**Deliverable:** Authenticated users can sign up, log in, and have a plan assigned.

---

### 67.4 Phase 1: Core Product (Months 2–4)

**Goal:** Build the minimum viable product that delivers genuine value to personal users.

**Experience Builder (Core):**
- [ ] Scene system (create, edit, reorder, delete scenes)
- [ ] Text block
- [ ] Image block (upload, display)
- [ ] Button/CTA block
- [ ] Scene transitions (fade, slide)
- [ ] Auto-save
- [ ] Undo/redo
- [ ] Mobile preview
- [ ] Publish experience
- [ ] Experience URL generation

**3D System (Core):**
- [ ] 3D rendering engine integration
- [ ] Core asset library (10 objects: rose, gift box, envelope, heart, confetti, balloons, birthday cake, stars, package, flowers)
- [ ] Basic animations (bloom, open, burst, float)
- [ ] 3D object block in builder
- [ ] 2D fallback system
- [ ] Performance optimization (mobile)

**Template System (Core):**
- [ ] 20 personal templates
- [ ] Template browser
- [ ] Template preview
- [ ] Apply template to builder

**Sharing (Core):**
- [ ] Unique experience URL
- [ ] Open Graph metadata
- [ ] Copy link
- [ ] QR code generation
- [ ] Recipient experience page

**Personal Dashboard (Core):**
- [ ] My Experiences list
- [ ] Create button
- [ ] Draft/Published status
- [ ] Basic open tracking (opened: yes/no)

**Onboarding (Core):**
- [ ] Personal onboarding flow
- [ ] Welcome email
- [ ] First experience creation guide

**Public Website (Core):**
- [ ] Homepage
- [ ] Pricing page
- [ ] Basic SEO setup (sitemap, robots.txt, meta tags)

**Deliverable:** Personal users can sign up, create a 3D experience, and share it with a recipient.

---

### 67.5 Phase 2: AI & Business (Months 4–7)

**Goal:** Add AI features and launch the business product.

**AI System:**
- [ ] AI message generator
- [ ] AI experience creator
- [ ] AI tone adjuster
- [ ] AI scene suggester
- [ ] AI credit system
- [ ] Content safety layer

**Business Features:**
- [ ] Business account type
- [ ] Business dashboard
- [ ] Business onboarding
- [ ] Brand settings (logo, colors, fonts)
- [ ] Business templates (20 templates)
- [ ] Automation builder (basic)
- [ ] Shopify integration
- [ ] Webhook integration
- [ ] Email delivery for automations
- [ ] Basic automation analytics

**Scheduling:**
- [ ] Schedule experience for later
- [ ] Time zone selection
- [ ] Scheduled experience management

**Rewards (Basic):**
- [ ] Coupon code reward
- [ ] Reward block in builder
- [ ] Reward reveal animation

**Analytics (Basic):**
- [ ] Experience open rate
- [ ] Scene-level analytics
- [ ] Automation analytics

**Additional Templates:**
- [ ] 30 more personal templates (total: 50)
- [ ] 20 business templates

**Deliverable:** Business users can sign up, connect Shopify, create automations, and send experiences to customers.

---

### 67.6 Phase 3: Growth & Scale (Months 7–12)

**Goal:** Add features that drive growth, retention, and revenue expansion.

**Growth Features:**
- [ ] Referral program
- [ ] Occasion reminders
- [ ] Recipient-to-creator conversion optimization
- [ ] Social sharing for recipients

**Advanced Experience Features:**
- [ ] Video block
- [ ] Audio/voice message block
- [ ] Photo gallery block
- [ ] Countdown timer block
- [ ] Scratch-to-reveal interaction
- [ ] Password reveal interaction
- [ ] Branching experiences (Pro+)

**Business Advanced:**
- [ ] WooCommerce integration
- [ ] Zapier integration
- [ ] Drip sequences (Growth+)
- [ ] Campaign management
- [ ] Customer list management
- [ ] Advanced automation conditions
- [ ] Team management (Business+)

**White Label & Custom Domains:**
- [ ] Remove MemorableDay branding (Growth+)
- [ ] Custom domain setup (Growth+)
- [ ] Custom email sender (Growth+)

**SEO & Content:**
- [ ] 50+ occasion pages
- [ ] 20+ business use case pages
- [ ] Blog (10+ articles)
- [ ] Template pages (100+)
- [ ] Programmatic SEO (occasion × recipient matrix)

**Analytics (Advanced):**
- [ ] Revenue attribution
- [ ] Custom date ranges
- [ ] CSV export
- [ ] Business-level analytics

**Deliverable:** Platform is growing organically through SEO and viral loops; business users are seeing measurable ROI.

---

### 67.7 Phase 4: Premium & Enterprise (Months 12–18)

**Goal:** Add premium features that justify higher pricing and enterprise contracts.

**Agency Features:**
- [ ] Multi-brand workspace
- [ ] Client management
- [ ] Approval workflows
- [ ] Client reporting
- [ ] Agency white label

**Enterprise Features:**
- [ ] SSO (SAML)
- [ ] SLA
- [ ] Dedicated support
- [ ] Custom integrations
- [ ] Custom AI credits
- [ ] Custom 3D assets

**API:**
- [ ] Public API (v1)
- [ ] API documentation
- [ ] Sandbox environment
- [ ] Zapier app
- [ ] Make app

**Additional Integrations:**
- [ ] Klaviyo
- [ ] HubSpot
- [ ] Attentive
- [ ] Gorgias
- [ ] Stripe

**3D Asset Expansion:**
- [ ] 50+ additional 3D assets
- [ ] Seasonal asset packs
- [ ] Luxury asset pack
- [ ] Business asset pack

**Deliverable:** Agency and enterprise customers are onboarded; API enables custom integrations.

---

### 67.8 Phase 5: Platform & Ecosystem (Months 18–24)

**Goal:** Build platform features that create network effects and defensibility.

**Template Marketplace:**
- [ ] Designer submission system
- [ ] Template review process
- [ ] Marketplace listing
- [ ] Revenue sharing

**Advanced AI:**
- [ ] AI translation
- [ ] AI narration (voice)
- [ ] AI image suggestions
- [ ] AI design recommendations

**Advanced 3D:**
- [ ] Full scene compositions
- [ ] Multi-object scenes
- [ ] Camera movement
- [ ] 3D environments

**Mobile App:**
- [ ] iOS app (PWA upgrade)
- [ ] Android app (PWA upgrade)
- [ ] Push notifications
- [ ] Camera integration

**Experimental:**
- [ ] AR experiences (WebXR)
- [ ] Voice activation
- [ ] Geolocation reveal
- [ ] Collaborative experiences

**Deliverable:** MemorableDay is a platform with an ecosystem of creators, designers, and businesses.

---

### 67.9 Roadmap Dependencies

```
Phase 0 (Infrastructure)
    ↓
Phase 1 (Core Product)
    ↓
Phase 2 (AI + Business) ← Requires Phase 1 complete
    ↓
Phase 3 (Growth + Scale) ← Requires Phase 2 complete
    ↓
Phase 4 (Premium + Enterprise) ← Requires Phase 3 validation
    ↓
Phase 5 (Platform + Ecosystem) ← Requires Phase 4 revenue
```

**Critical path:**
1. Infrastructure → Authentication → Billing → Core Builder → 3D → Templates → Sharing
2. AI → Business Dashboard → Shopify Integration → Automation → Analytics
3. SEO Content → Programmatic SEO → Referral → Viral Optimization

### 67.10 Validation Gates

Before advancing to the next phase, validate:

| Gate | Metric | Target |
|---|---|---|
| **Phase 1 → Phase 2** | Personal users creating experiences | 500+ experiences created |
| **Phase 2 → Phase 3** | Business automation open rate | > 40% |
| **Phase 3 → Phase 4** | MRR | $50K+ |
| **Phase 4 → Phase 5** | Net Revenue Retention | > 110% |

---

*Next: [Future Opportunities →](30-future-opportunities.md)*
