# 19 — SEO Strategy, Content Strategy & Programmatic SEO

**Sections:** §41 SEO Strategy · §42 Content Strategy · §43 Programmatic SEO  
**PRD Index:** [← Pricing](18-pricing-strategy-free-plan.md) | [Next: Growth & Onboarding →](20-growth-viral-loops-onboarding.md)

---

## §41 SEO Strategy

### 41.1 SEO as a Core Growth Channel

SEO is not a marketing afterthought for MemorableDay — it is a primary acquisition channel and a core product strategy. The goal is for MemorableDay to become the authoritative destination for:

- Digital gifting and occasion-based experiences
- Customer experience and post-purchase communication
- Interactive digital content creation

**SEO vision:**
> MemorableDay appears on the first page of Google for every meaningful search related to digital gifting, customer appreciation, and interactive experiences.

**Why SEO is critical:**
- Digital gifting searches have high commercial intent
- Occasion-based searches are predictable and recurring (birthdays, anniversaries, holidays)
- Business use-case searches have high LTV (business users pay more)
- SEO compounds over time — early investment pays dividends for years
- Viral growth (recipient-to-creator) amplifies SEO traffic

### 41.2 Public Website Architecture for SEO

The public website (`memorableday.online`) must be built for maximum SEO performance.

**Technical requirements:**

| Requirement | Description |
|---|---|
| `PRD-SEO-006` | Public website must be server-side rendered or statically generated (not client-side rendered) |
| `PRD-SEO-007` | Public website must achieve Core Web Vitals scores: LCP < 2.5s, FID < 100ms, CLS < 0.1 |
| `PRD-SEO-008` | Public website must achieve Lighthouse performance score ≥ 90 |
| `PRD-SEO-009` | All pages must have unique, descriptive `<title>` tags (50–60 characters) |
| `PRD-SEO-010` | All pages must have unique meta descriptions (150–160 characters) |
| `PRD-SEO-011` | All pages must have canonical URLs |
| `PRD-SEO-012` | XML sitemap must be generated automatically and submitted to Google Search Console |
| `PRD-SEO-013` | Robots.txt must be configured correctly (allow public pages, disallow app pages) |
| `PRD-SEO-014` | All images must have descriptive alt text |
| `PRD-SEO-015` | All images must be served in WebP format with appropriate sizes |
| `PRD-SEO-016` | Internal linking must be systematic and intentional |
| `PRD-SEO-017` | URL structure must be clean, descriptive, and consistent |
| `PRD-SEO-018` | HTTPS must be enforced on all pages |
| `PRD-SEO-019` | 301 redirects must be used for any URL changes |
| `PRD-SEO-020` | Structured data (JSON-LD) must be implemented on appropriate pages |

**Astro-oriented public website:**
The public website is designed with an Astro-based approach in mind — a framework optimized for fast, SEO-friendly static and server-rendered pages. This is a fixed technical decision. The PRD does not prescribe implementation details beyond this requirement.

### 41.3 Keyword Strategy

**Keyword categories:**

#### Category 1: Personal Gifting (High Volume, High Intent)

| Keyword | Monthly Searches (est.) | Intent | Priority |
|---|---|---|---|
| digital birthday gift | 40,000+ | Commercial | High |
| digital anniversary gift | 20,000+ | Commercial | High |
| digital gift for girlfriend | 30,000+ | Commercial | High |
| digital gift for boyfriend | 25,000+ | Commercial | High |
| digital gift for wife | 20,000+ | Commercial | High |
| digital gift for husband | 18,000+ | Commercial | High |
| digital gift for mom | 15,000+ | Commercial | High |
| digital gift for dad | 12,000+ | Commercial | High |
| digital gift for friend | 20,000+ | Commercial | High |
| interactive digital gift | 5,000+ | Commercial | High |
| online birthday gift | 50,000+ | Commercial | High |
| digital Valentine's Day gift | 30,000+ | Commercial | Seasonal |
| digital Christmas gift | 25,000+ | Commercial | Seasonal |
| digital Mother's Day gift | 20,000+ | Commercial | Seasonal |
| digital graduation gift | 15,000+ | Commercial | Seasonal |

#### Category 2: Occasion-Specific (Medium Volume, High Intent)

| Keyword | Monthly Searches (est.) | Intent | Priority |
|---|---|---|---|
| digital birthday card | 100,000+ | Commercial | High |
| interactive birthday card | 10,000+ | Commercial | High |
| digital anniversary card | 30,000+ | Commercial | High |
| digital thank you card | 20,000+ | Commercial | High |
| digital apology gift | 5,000+ | Commercial | High |
| long distance relationship gift | 15,000+ | Commercial | High |
| digital gift for long distance | 8,000+ | Commercial | High |
| surprise gift for girlfriend online | 10,000+ | Commercial | High |

#### Category 3: Business Use Cases (Lower Volume, Very High LTV)

| Keyword | Monthly Searches (est.) | Intent | Priority |
|---|---|---|---|
| post-purchase customer experience | 3,000+ | Commercial | High |
| Shopify post-purchase experience | 2,000+ | Commercial | High |
| customer appreciation ideas | 10,000+ | Informational | High |
| digital customer appreciation | 2,000+ | Commercial | High |
| shipping delay customer message | 1,000+ | Commercial | High |
| e-commerce customer retention | 5,000+ | Informational | High |
| post-purchase email examples | 5,000+ | Informational | High |
| customer thank you experience | 2,000+ | Commercial | High |
| Shopify customer experience app | 1,000+ | Commercial | High |

#### Category 4: Informational / Educational (High Volume, Lower Intent)

| Keyword | Monthly Searches (est.) | Intent | Priority |
|---|---|---|---|
| how to make a digital gift | 10,000+ | Informational | Medium |
| what to send instead of a card | 5,000+ | Informational | Medium |
| creative birthday ideas for long distance | 8,000+ | Informational | Medium |
| how to apologize to girlfriend | 20,000+ | Informational | Medium |
| customer appreciation ideas for small business | 5,000+ | Informational | High |
| how to improve post-purchase experience | 3,000+ | Informational | High |

### 41.4 URL Structure

**Public website URL structure:**

```
memorableday.online/                          — Homepage
memorableday.online/pricing                   — Pricing
memorableday.online/features                  — Features overview
memorableday.online/business                  — Business landing page
memorableday.online/personal                  — Personal landing page

memorableday.online/occasions/                — Occasion hub
memorableday.online/occasions/birthday        — Birthday page
memorableday.online/occasions/anniversary     — Anniversary page
memorableday.online/occasions/valentines-day  — Valentine's Day page
memorableday.online/occasions/[occasion]      — Any occasion

memorableday.online/for/                      — Recipient hub
memorableday.online/for/girlfriend            — Gift for girlfriend
memorableday.online/for/boyfriend             — Gift for boyfriend
memorableday.online/for/wife                  — Gift for wife
memorableday.online/for/[recipient]           — Any recipient

memorableday.online/business/                 — Business use case hub
memorableday.online/business/post-purchase    — Post-purchase experience
memorableday.online/business/shipping         — Shipping experience
memorableday.online/business/delivery         — Delivery experience
memorableday.online/business/apology          — Apology experience
memorableday.online/business/vip              — VIP experience
memorableday.online/business/[use-case]       — Any use case

memorableday.online/templates/                — Template hub
memorableday.online/templates/birthday        — Birthday templates
memorableday.online/templates/[occasion]      — Any occasion templates

memorableday.online/blog/                     — Blog hub
memorableday.online/blog/[slug]               — Blog post

memorableday.online/guides/                   — Guides hub
memorableday.online/guides/[slug]             — Guide

memorableday.online/compare/                  — Comparison hub
memorableday.online/compare/[competitor]      — Competitor comparison

memorableday.online/integrations/             — Integration hub
memorableday.online/integrations/shopify      — Shopify integration page
memorableday.online/integrations/[platform]   — Any integration
```

### 41.5 Structured Data

**Structured data types to implement:**

| Page Type | Schema Type |
|---|---|
| Homepage | `Organization`, `WebSite`, `SoftwareApplication` |
| Pricing page | `Product`, `Offer` |
| Blog posts | `Article`, `BlogPosting` |
| Guides | `HowTo`, `Article` |
| FAQ sections | `FAQPage` |
| Template pages | `CreativeWork` |
| Comparison pages | `Product`, `Review` |

**Requirements:**
- `PRD-SEO-021`: All structured data must be validated with Google's Rich Results Test
- `PRD-SEO-022`: Structured data must be implemented as JSON-LD (not Microdata)
- `PRD-SEO-023`: Structured data must be kept up-to-date with page content

### 41.6 Core Web Vitals Strategy

**LCP (Largest Contentful Paint) < 2.5s:**
- Hero images must be preloaded and served in WebP
- Critical CSS must be inlined
- Fonts must be preloaded
- Server response time must be < 200ms (Cloudflare edge)

**FID/INP (Interaction to Next Paint) < 100ms:**
- JavaScript must be minimal on public pages
- Third-party scripts must be deferred or loaded asynchronously
- No render-blocking resources

**CLS (Cumulative Layout Shift) < 0.1:**
- All images must have explicit width and height attributes
- Fonts must use `font-display: swap` with fallback fonts
- No dynamically injected content above the fold

---

## §42 Content Strategy

### 42.1 Content Philosophy

Content must provide genuine value to the reader. MemorableDay's content strategy is not about keyword stuffing — it is about becoming the most helpful resource for people who want to create meaningful digital moments.

**Content principles:**
- Every piece of content must answer a real question or solve a real problem
- Content must be specific and actionable (not generic advice)
- Content must naturally lead to MemorableDay as the solution
- Content must be updated regularly to maintain freshness

### 42.2 Content Types

| Content Type | Purpose | Frequency |
|---|---|---|
| **Blog posts** | Informational, educational, SEO | 2–4/month |
| **Occasion guides** | Occasion-specific advice + templates | Ongoing |
| **Business guides** | E-commerce CX advice + use cases | 2/month |
| **Template showcases** | Feature specific templates | Ongoing |
| **Comparison pages** | Compare MemorableDay to alternatives | As needed |
| **Integration guides** | How to use MemorableDay with other tools | Per integration |
| **Case studies** | Business success stories | Monthly |
| **Help center** | Product documentation | Ongoing |

### 42.3 Blog Content Calendar (Sample)

**Personal gifting topics:**
- "50 Creative Digital Gift Ideas for Long-Distance Relationships"
- "How to Create a Meaningful Digital Anniversary Gift (Without Being a Designer)"
- "The Best Way to Apologize to Your Partner Digitally"
- "Digital Birthday Gift Ideas That Are Actually Impressive"
- "How to Celebrate a Graduation When You Can't Be There in Person"

**Business topics:**
- "How to Turn a Shipping Delay Into a Customer Loyalty Opportunity"
- "Post-Purchase Experience: Why Your Thank-You Email Is Failing"
- "5 Ways Shopify Merchants Can Reduce Churn with Better Customer Communication"
- "The ROI of Customer Appreciation: What the Data Says"
- "How to Create a VIP Customer Experience That Actually Feels VIP"

### 42.4 Occasion Pages

Each major occasion gets a dedicated landing page optimized for that occasion's keywords.

**Occasion page structure:**
1. Hero: "Create a [Occasion] Experience They'll Never Forget"
2. What makes MemorableDay different for this occasion
3. Template showcase (3–5 templates for this occasion)
4. How it works (3 steps)
5. Example experience (interactive demo or video)
6. Testimonials
7. FAQ
8. CTA: "Create Your [Occasion] Experience"

**Priority occasion pages:**
- Birthday
- Anniversary
- Valentine's Day
- Mother's Day
- Father's Day
- Christmas
- Graduation
- Wedding
- New Baby
- Apology
- Long Distance
- Thank You
- Congratulations

### 42.5 Business Use Case Pages

Each major business use case gets a dedicated landing page.

**Business page structure:**
1. Hero: "Turn [Scenario] Into a Customer Loyalty Moment"
2. The problem (what businesses currently do)
3. The MemorableDay solution
4. Example experience (interactive demo)
5. Business outcomes (metrics)
6. Integration showcase (Shopify, etc.)
7. Pricing for this use case
8. CTA: "Start Free Trial"

**Priority business pages:**
- Post-purchase thank you
- Shipping experience
- Delivery experience
- Delay apology
- VIP customer experience
- Win-back campaign
- Review request

---

## §43 Programmatic SEO

### 43.1 Programmatic SEO Philosophy

Programmatic SEO generates pages at scale from structured data. Done well, it creates thousands of genuinely useful pages. Done poorly, it creates thin content that Google penalizes.

**MemorableDay's programmatic SEO rule:**
> Every programmatically generated page must provide genuine value to the searcher. If a page is not useful to a real person, it should not exist.

### 43.2 Programmatic SEO Opportunities

#### 43.2.1 Occasion × Recipient Matrix

Generate pages for every combination of occasion and recipient relationship:

**Template:** `memorableday.online/[occasion]/for/[recipient]`

**Examples:**
- `memorableday.online/birthday/for/girlfriend`
- `memorableday.online/birthday/for/boyfriend`
- `memorableday.online/anniversary/for/wife`
- `memorableday.online/anniversary/for/husband`
- `memorableday.online/graduation/for/daughter`
- `memorableday.online/graduation/for/son`

**Scale:** 20 occasions × 20 recipients = 400 pages

**Content per page:**
- Unique headline and intro (AI-assisted, human-reviewed)
- 3–5 relevant templates
- Occasion + recipient specific advice
- Example experience
- FAQ

**Requirements:**
- `PRD-SEO-024`: Programmatic pages must have unique, non-duplicate content (not just template swaps)
- `PRD-SEO-025`: Programmatic pages must be reviewed for quality before indexing
- `PRD-SEO-026`: Programmatic pages must have canonical URLs
- `PRD-SEO-027`: Low-quality programmatic pages must be noindexed or removed

#### 43.2.2 Business Industry × Use Case Matrix

Generate pages for every combination of industry and business use case:

**Template:** `memorableday.online/business/[industry]/[use-case]`

**Examples:**
- `memorableday.online/business/shopify/post-purchase-experience`
- `memorableday.online/business/woocommerce/shipping-notification`
- `memorableday.online/business/fashion/customer-appreciation`
- `memorableday.online/business/beauty/vip-experience`

**Scale:** 20 industries × 10 use cases = 200 pages

#### 43.2.3 Template Pages

Each template gets its own SEO-optimized page:

**Template:** `memorableday.online/templates/[template-slug]`

**Examples:**
- `memorableday.online/templates/rose-bloom-anniversary`
- `memorableday.online/templates/birthday-surprise-box`
- `memorableday.online/templates/shopify-post-purchase-thank-you`

**Content per page:**
- Template preview (interactive or video)
- Template description
- Who it's for
- How to customize it
- Related templates
- CTA: "Use This Template"

**Scale:** 100+ templates at launch, growing to 500+

#### 43.2.4 Comparison Pages

Compare MemorableDay to alternatives:

**Template:** `memorableday.online/compare/[competitor]`

**Examples:**
- `memorableday.online/compare/hallmark`
- `memorableday.online/compare/moonpig`
- `memorableday.online/compare/evite`
- `memorableday.online/compare/wonderment`

**Content per page:**
- Honest comparison table
- Where MemorableDay wins
- Where the competitor wins (honesty builds trust)
- Who should use each
- CTA

#### 43.2.5 Integration Pages

Each integration gets its own SEO-optimized page:

**Template:** `memorableday.online/integrations/[platform]`

**Examples:**
- `memorableday.online/integrations/shopify`
- `memorableday.online/integrations/klaviyo`
- `memorableday.online/integrations/woocommerce`

### 43.3 Programmatic SEO Quality Controls

**Requirements:**
- `PRD-SEO-028`: All programmatic pages must be reviewed by a human before indexing
- `PRD-SEO-029`: Programmatic pages must have a minimum word count of 300 words of unique content
- `PRD-SEO-030`: Programmatic pages must include at least 3 relevant templates or examples
- `PRD-SEO-031`: Programmatic pages must be monitored for Google Search Console errors
- `PRD-SEO-032`: Pages with low traffic after 6 months must be reviewed for improvement or removal
- `PRD-SEO-033`: Programmatic page generation must be rate-limited (not all pages indexed at once)

### 43.4 SEO Monitoring and Reporting

**Requirements:**
- `PRD-SEO-034`: Google Search Console must be configured and monitored weekly
- `PRD-SEO-035`: Google Analytics 4 (or privacy-respecting alternative) must be configured
- `PRD-SEO-036`: Core Web Vitals must be monitored monthly
- `PRD-SEO-037`: Keyword rankings must be tracked for priority keywords
- `PRD-SEO-038`: Backlink profile must be monitored monthly
- `PRD-SEO-039`: SEO performance must be reported monthly to the founding team

---

*Next: [Growth, Viral Loops & Onboarding →](20-growth-viral-loops-onboarding.md)*
