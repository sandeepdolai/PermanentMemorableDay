# 13 — E-commerce Integrations

**Section:** §28 E-commerce Integrations  
**PRD Index:** [← Business Automation](12-business-automation.md) | [Next: Dashboard & Analytics →](14-dashboard-analytics.md)

---

## §28 E-commerce Integrations

### 28.1 Integration Philosophy

MemorableDay is not an island. Businesses already have tools they rely on — Shopify, Klaviyo, Gorgias, Attentive. MemorableDay must integrate with these tools, not replace them.

**Integration principles:**
- Integrations must be setup in minutes, not hours
- Integrations must be reliable — a broken integration means missed customer moments
- Integrations must be secure — customer data must be handled with care
- Integrations must be testable — businesses must be able to verify before going live
- MemorableDay is the experience layer; existing tools remain the communication layer

### 28.2 Integration Architecture

```
External System (Shopify, WooCommerce, etc.)
        ↓
Integration Layer (webhook, API, OAuth)
        ↓
MemorableDay Event Processing
        ↓
Automation Engine
        ↓
Experience Generation & Personalization
        ↓
Delivery (Email, SMS, Webhook, API)
        ↓
Analytics & Reporting
```

### 28.3 Shopify Integration

Shopify is the highest-priority integration. It is the most common e-commerce platform for MemorableDay's target business users.

**Integration method:** Shopify App (listed in Shopify App Store) + OAuth

**Data accessed:**

| Data | Purpose | Permission |
|---|---|---|
| Orders | Trigger automations, personalize experiences | `read_orders` |
| Customers | Customer data for personalization | `read_customers` |
| Products | Product information for experiences | `read_products` |
| Fulfillments | Shipping/delivery triggers | `read_fulfillments` |
| Discount codes | Create and manage coupon rewards | `write_discounts` |
| Customer tags | Condition filtering | `read_customers` |

**Shopify webhooks subscribed:**

| Webhook | Trigger |
|---|---|
| `orders/create` | `order.created` |
| `orders/paid` | `order.paid` |
| `orders/fulfilled` | `order.fulfilled` |
| `orders/cancelled` | `order.cancelled` |
| `orders/refunded` | `order.refunded` |
| `fulfillments/create` | `order.shipped` |
| `customers/create` | New customer |
| `customers/update` | Customer data update |

**Requirements:**
- `PRD-INT-001`: Shopify integration must be installable from the Shopify App Store
- `PRD-INT-002`: Shopify OAuth must request only the minimum required permissions
- `PRD-INT-003`: Shopify webhooks must be verified using HMAC signature validation
- `PRD-INT-004`: Shopify integration must handle webhook retries (Shopify retries failed webhooks)
- `PRD-INT-005`: Shopify integration must support multiple stores per MemorableDay workspace
- `PRD-INT-006`: Shopify discount codes created by MemorableDay must be trackable in Shopify
- `PRD-INT-007`: Shopify integration must be testable with a development store

**Shopify App Store listing requirements:**
- App must comply with Shopify's Partner Program Agreement
- App must pass Shopify's app review process
- App must have a clear privacy policy
- App must handle Shopify's mandatory webhooks (GDPR: customer data request, customer erasure, shop erasure)

### 28.4 WooCommerce Integration

WooCommerce is the second-highest-priority integration.

**Integration method:** WooCommerce plugin + REST API + webhooks

**Data accessed:**

| Data | Purpose |
|---|---|
| Orders | Trigger automations, personalize experiences |
| Customers | Customer data for personalization |
| Products | Product information for experiences |
| Coupons | Create and manage coupon rewards |

**WooCommerce webhooks:**

| Webhook | Trigger |
|---|---|
| `order.created` | `order.created` |
| `order.updated` | Status changes |
| `order.deleted` | Order deletion |
| `customer.created` | New customer |

**Requirements:**
- `PRD-INT-008`: WooCommerce plugin must be installable from WordPress.org plugin directory
- `PRD-INT-009`: WooCommerce integration must use WooCommerce REST API with API key authentication
- `PRD-INT-010`: WooCommerce webhooks must be verified using webhook secret
- `PRD-INT-011`: WooCommerce integration must support WooCommerce 6.0+

### 28.5 Stripe Integration

For businesses that use Stripe directly (not via Shopify/WooCommerce).

**Integration method:** Stripe Connect or API key

**Data accessed:**

| Data | Purpose |
|---|---|
| Payment intents | `order.paid` trigger |
| Customers | Customer data |
| Charges | Order value |

**Requirements:**
- `PRD-INT-012`: Stripe integration must use Stripe webhooks for event triggers
- `PRD-INT-013`: Stripe webhooks must be verified using Stripe's webhook signature
- `PRD-INT-014`: Stripe integration must handle Stripe's event types correctly

### 28.6 Zapier Integration

Zapier enables MemorableDay to connect with hundreds of additional tools without native integrations.

**MemorableDay as a Zapier trigger:**
- New experience created
- Experience opened by recipient
- Reward claimed

**MemorableDay as a Zapier action:**
- Create and send an experience
- Trigger an automation
- Create a customer record

**Requirements:**
- `PRD-INT-015`: MemorableDay must have a published Zapier app
- `PRD-INT-016`: Zapier app must support at least 3 triggers and 3 actions at launch
- `PRD-INT-017`: Zapier integration must use API key authentication

### 28.7 Make (Integromat) Integration

Make is an alternative to Zapier with more advanced workflow capabilities.

**Requirements:**
- `PRD-INT-018`: MemorableDay must have a published Make app (or use webhook-based integration)
- `PRD-INT-019`: Make integration must support the same triggers and actions as Zapier

### 28.8 Webhook Integration

For businesses with custom systems, MemorableDay supports generic webhook integration.

**Inbound webhooks (MemorableDay receives):**
- Any business event can trigger an automation via a webhook POST to MemorableDay
- Webhook payload must include: customer data, event type, and any relevant data
- Webhook authentication via HMAC signature or API key

**Outbound webhooks (MemorableDay sends):**
- MemorableDay can send webhook notifications to business systems when:
  - Experience is opened
  - Reward is claimed
  - CTA is clicked
  - Experience is completed

**Requirements:**
- `PRD-INT-020`: Inbound webhooks must be authenticated (HMAC or API key)
- `PRD-INT-021`: Outbound webhooks must be configurable per automation
- `PRD-INT-022`: Webhook failures must be retried (up to 3 times with exponential backoff)
- `PRD-INT-023`: Webhook logs must be viewable in the business dashboard

### 28.9 CRM Integrations

**Priority CRM integrations:**

| CRM | Integration Method | Priority |
|---|---|---|
| HubSpot | Native integration + webhooks | High |
| Salesforce | Native integration + webhooks | Medium |
| Klaviyo | Native integration + webhooks | High |
| Mailchimp | Native integration + webhooks | Medium |
| ActiveCampaign | Native integration + webhooks | Medium |
| Attentive | Native integration (SMS) | Medium |
| Gorgias | Native integration (support) | Medium |
| Zendesk | Native integration (support) | Low |

**CRM integration capabilities:**
- Sync customer data to MemorableDay for personalization
- Trigger MemorableDay automations from CRM events
- Send MemorableDay analytics back to CRM
- Create CRM contacts/deals from MemorableDay events

**Requirements:**
- `PRD-INT-024`: CRM integrations must be available on Growth plan and above
- `PRD-INT-025`: CRM data sync must be one-way (CRM → MemorableDay) initially
- `PRD-INT-026`: CRM integration must handle data mapping (CRM fields → MemorableDay variables)

### 28.10 Email Platform Integrations

MemorableDay is not an email marketing platform. It is an experience platform. Email platforms deliver the link; MemorableDay delivers the experience.

**Integration model:**
- MemorableDay generates the experience URL
- Email platform sends the email with the URL
- MemorableDay tracks opens and interactions

**Priority email platform integrations:**

| Platform | Integration Method |
|---|---|
| Klaviyo | API + webhook |
| Mailchimp | API + webhook |
| Postmark | API |
| SendGrid | API |
| ActiveCampaign | API + webhook |

**Requirements:**
- `PRD-INT-027`: Email platform integrations must allow MemorableDay to generate experience URLs for use in email campaigns
- `PRD-INT-028`: Email platform integrations must support passing customer data for personalization

### 28.11 SMS Platform Integrations

| Platform | Integration Method | Priority |
|---|---|---|
| Attentive | API + webhook | High |
| Klaviyo SMS | API + webhook | High |
| Twilio | API | Medium |
| Postscript | API + webhook | Medium |

### 28.12 Customer Support Integrations

When a customer contacts support about an order, the support agent can send a MemorableDay experience directly from the support tool.

| Platform | Integration Method | Priority |
|---|---|---|
| Gorgias | Native app | High |
| Zendesk | Native app | Medium |
| Freshdesk | Native app | Low |
| Intercom | Native app | Medium |

**Use case:**
- Customer contacts support about a delayed order
- Support agent opens MemorableDay within Gorgias
- Agent selects "Delay Apology" template
- Agent customizes with order details and coupon
- Agent sends experience directly from Gorgias
- Customer receives experience link via email/SMS

**Requirements:**
- `PRD-INT-029`: Support integrations must allow agents to create and send experiences without leaving the support tool
- `PRD-INT-030`: Support integrations must pre-populate customer data from the support ticket

### 28.13 Integration Management

**In the business dashboard:**

| Feature | Description |
|---|---|
| **Integration list** | All available integrations with status (connected/not connected) |
| **Connection wizard** | Step-by-step guide for each integration |
| **Test connection** | Verify integration is working with a test event |
| **Integration logs** | Recent events received from each integration |
| **Disconnect** | Remove an integration |
| **Data mapping** | Map integration fields to MemorableDay variables |

**Requirements:**
- `PRD-INT-031`: Integration setup must be completable without technical knowledge
- `PRD-INT-032`: Integration status must be visible at a glance (connected, error, disconnected)
- `PRD-INT-033`: Integration errors must show actionable error messages
- `PRD-INT-034`: Integration logs must show the last 100 events per integration

### 28.14 Integration Roadmap

| Phase | Integrations |
|---|---|
| **Launch** | Shopify, Zapier, Webhook |
| **Phase 2** | WooCommerce, Stripe, Klaviyo, Make |
| **Phase 3** | HubSpot, Attentive, Gorgias, Mailchimp |
| **Phase 4** | Salesforce, Zendesk, ActiveCampaign, Postscript |
| **Ongoing** | Based on customer demand |

---

*Next: [Dashboard & Analytics →](14-dashboard-analytics.md)*
