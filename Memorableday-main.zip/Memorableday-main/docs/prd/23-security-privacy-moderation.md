# 23 — Security, Privacy & Moderation

**Sections:** §52 Security · §53 Privacy · §54 Moderation  
**PRD Index:** [← Performance & Mobile](22-performance-mobile-accessibility.md) | [Next: Hosting & Cloudflare →](24-hosting-cloudflare-domains.md)

---

## §52 Security

### 52.1 Security Philosophy

MemorableDay handles personal moments, private photos, business customer data, and payment information. Security is not optional — it is a fundamental product requirement.

**Security principles:**
- Defense in depth (multiple layers of security)
- Least privilege (minimum access required)
- Secure by default (security is the default, not an opt-in)
- Fail securely (failures should not expose data)
- Transparency (security incidents are disclosed appropriately)

### 52.2 Authentication Security

| Requirement | Description |
|---|---|
| `PRD-SEC-030` | Passwords must be hashed with Argon2id or bcrypt (cost factor ≥ 12) |
| `PRD-SEC-031` | Password minimum length: 8 characters; recommended: 12+ |
| `PRD-SEC-032` | Password strength indicator must be shown during signup |
| `PRD-SEC-033` | Common passwords must be rejected (check against HaveIBeenPwned or similar) |
| `PRD-SEC-034` | Login attempts must be rate-limited: 5 attempts per 15 minutes per IP |
| `PRD-SEC-035` | Account lockout after 10 failed attempts (with unlock via email) |
| `PRD-SEC-036` | Session tokens must be cryptographically random (≥ 128 bits) |
| `PRD-SEC-037` | Session tokens must expire after 30 days of inactivity |
| `PRD-SEC-038` | Session tokens must be invalidated on logout |
| `PRD-SEC-039` | 2FA must be available (TOTP) and required for Agency/Enterprise |
| `PRD-SEC-040` | OAuth tokens must be stored securely and refreshed appropriately |
| `PRD-SEC-041` | Magic links must expire after 15 minutes and be single-use |

### 52.3 Authorization Security

| Requirement | Description |
|---|---|
| `PRD-SEC-042` | All API endpoints must verify authentication |
| `PRD-SEC-043` | All API endpoints must verify authorization (user can access this resource) |
| `PRD-SEC-044` | Authorization must be enforced server-side (not just client-side) |
| `PRD-SEC-045` | Users must not be able to access other users' experiences, data, or analytics |
| `PRD-SEC-046` | Business users must not be able to access other businesses' customer data |
| `PRD-SEC-047` | Team members must only access resources within their workspace |
| `PRD-SEC-048` | API keys must be scoped to specific permissions |

### 52.4 Data Security

| Requirement | Description |
|---|---|
| `PRD-SEC-049` | All data must be encrypted in transit (TLS 1.2+) |
| `PRD-SEC-050` | All data must be encrypted at rest (AES-256 or equivalent) |
| `PRD-SEC-051` | Database backups must be encrypted |
| `PRD-SEC-052` | Sensitive data (passwords, API keys, payment tokens) must never be logged |
| `PRD-SEC-053` | Personally identifiable information must be minimized |
| `PRD-SEC-054` | Customer data from business integrations must be isolated per workspace |
| `PRD-SEC-055` | Data deletion must be complete (no orphaned data) |

### 52.5 File Upload Security

Users can upload photos, videos, audio, and other files. This is a significant attack surface.

| Requirement | Description |
|---|---|
| `PRD-SEC-056` | All uploaded files must be validated for type (MIME type + magic bytes) |
| `PRD-SEC-057` | Uploaded files must be scanned for malware |
| `PRD-SEC-058` | Uploaded files must be stored in isolated storage (not served from the same domain as the app) |
| `PRD-SEC-059` | Uploaded files must be served with appropriate Content-Type headers |
| `PRD-SEC-060` | Uploaded files must be served with Content-Disposition: attachment for non-media types |
| `PRD-SEC-061` | File size limits must be enforced server-side |
| `PRD-SEC-062` | Uploaded images must be re-encoded (strip EXIF data, prevent polyglot files) |
| `PRD-SEC-063` | Uploaded videos must be transcoded (prevent malicious video files) |

### 52.6 API Security

| Requirement | Description |
|---|---|
| `PRD-SEC-064` | All API endpoints must be protected against SQL injection |
| `PRD-SEC-065` | All API endpoints must be protected against XSS |
| `PRD-SEC-066` | All API endpoints must be protected against CSRF |
| `PRD-SEC-067` | API rate limiting must be enforced per key and per IP |
| `PRD-SEC-068` | API responses must not include sensitive data (passwords, internal IDs) |
| `PRD-SEC-069` | Webhook signatures must be verified before processing |
| `PRD-SEC-070` | API keys must be stored hashed (not in plaintext) |

### 52.7 Infrastructure Security

| Requirement | Description |
|---|---|
| `PRD-SEC-071` | All infrastructure must be behind Cloudflare (DDoS protection) |
| `PRD-SEC-072` | Cloudflare WAF must be enabled with appropriate rules |
| `PRD-SEC-073` | Cloudflare Bot Management must be enabled |
| `PRD-SEC-074` | All services must use least-privilege IAM roles |
| `PRD-SEC-075` | Secrets must be stored in a secrets manager (not in code or environment files) |
| `PRD-SEC-076` | Security patches must be applied within 7 days of release |
| `PRD-SEC-077` | Dependency vulnerabilities must be monitored and addressed |

### 52.8 Security Monitoring

| Requirement | Description |
|---|---|
| `PRD-SEC-078` | Security events must be logged (login attempts, API errors, file uploads) |
| `PRD-SEC-079` | Anomalous activity must trigger alerts (unusual login location, bulk API calls) |
| `PRD-SEC-080` | Security logs must be retained for at least 90 days |
| `PRD-SEC-081` | Penetration testing must be performed annually |
| `PRD-SEC-082` | Vulnerability disclosure policy must be published |

### 52.9 Incident Response

| Requirement | Description |
|---|---|
| `PRD-SEC-083` | Incident response plan must be documented |
| `PRD-SEC-084` | Data breach notification must comply with applicable laws (GDPR: 72 hours; CCPA: expedient) |
| `PRD-SEC-085` | Affected users must be notified of security incidents |
| `PRD-SEC-086` | Post-incident review must be conducted for all significant incidents |

---

## §53 Privacy

### 53.1 Privacy Philosophy

MemorableDay handles deeply personal content — love letters, family photos, apology messages, business customer data. Privacy is not a legal requirement to comply with — it is a trust requirement to earn.

**Privacy principles:**
- Collect only what's necessary
- Use data only for stated purposes
- Give users control over their data
- Be transparent about data practices
- Default to privacy (not to data collection)

### 53.2 Data Collected

**Personal user data:**

| Data | Purpose | Retention |
|---|---|---|
| Email address | Authentication, notifications | Until account deletion |
| Name | Display, personalization | Until account deletion |
| Password (hashed) | Authentication | Until account deletion |
| Profile photo | Display | Until deleted by user |
| Important dates | Occasion reminders | Until deleted by user |
| Created experiences | Product functionality | Until deleted by user |
| Uploaded media | Experience content | Until deleted by user |
| Usage data | Product improvement, billing | 12 months |
| Payment data | Billing (via Lemon Squeezy) | Per Lemon Squeezy policy |

**Business user data:**

| Data | Purpose | Retention |
|---|---|---|
| Business name, website | Profile | Until account deletion |
| Team member emails | Authentication | Until removed |
| Customer data (from integrations) | Personalization, automation | Until disconnected or deleted |
| Experience analytics | Business intelligence | 24 months |
| Integration credentials | Integration functionality | Until disconnected |

**Recipient data:**

| Data | Purpose | Retention |
|---|---|---|
| Experience open event | Analytics | 24 months |
| Device type | Analytics | 24 months |
| Interaction events | Analytics | 24 months |
| IP address | Security, fraud prevention | 30 days |

**What MemorableDay does NOT collect:**
- Recipient email or phone (unless provided by creator)
- Recipient location (beyond country-level from IP)
- Recipient browsing history
- Third-party tracking data

### 53.3 Privacy Requirements

| Requirement | Description |
|---|---|
| `PRD-SEC-087` | Privacy policy must be published and accessible |
| `PRD-SEC-088` | Privacy policy must be written in plain language |
| `PRD-SEC-089` | Data collection must be disclosed in the privacy policy |
| `PRD-SEC-090` | Users must be able to export all their data (GDPR/CCPA) |
| `PRD-SEC-091` | Users must be able to delete their account and all data |
| `PRD-SEC-092` | Account deletion must complete within 30 days |
| `PRD-SEC-093` | Marketing emails must include an unsubscribe link |
| `PRD-SEC-094` | Analytics must not use third-party tracking pixels |
| `PRD-SEC-095` | Cookie consent must be implemented for EU visitors |
| `PRD-SEC-096` | GDPR data subject requests must be handled within 30 days |
| `PRD-SEC-097` | CCPA opt-out must be available for California residents |

### 53.4 Children's Privacy

| Requirement | Description |
|---|---|
| `PRD-SEC-098` | MemorableDay is not intended for users under 13 |
| `PRD-SEC-099` | Signup must require age confirmation (13+) |
| `PRD-SEC-100` | If a user under 13 is identified, their account must be deleted |
| `PRD-SEC-101` | COPPA compliance must be reviewed by legal counsel |

### 53.5 Business Customer Data

When businesses connect their stores and customer data flows into MemorableDay:

| Requirement | Description |
|---|---|
| `PRD-SEC-102` | Business customer data must be isolated per workspace |
| `PRD-SEC-103` | Business customer data must only be used for the business's automations |
| `PRD-SEC-104` | Business customer data must not be used for MemorableDay's own marketing |
| `PRD-SEC-105` | Business customer data must be deletable by the business |
| `PRD-SEC-106` | Data processing agreement (DPA) must be available for business customers |
| `PRD-SEC-107` | Business customers are data controllers; MemorableDay is a data processor |

### 53.6 Legal Review Requirements

The following items require professional legal review before launch:

| Item | Why |
|---|---|
| Privacy policy | Must comply with GDPR, CCPA, and other applicable laws |
| Terms of service | Must cover user content, IP, liability, etc. |
| Data processing agreement | Required for GDPR compliance with business customers |
| Cookie policy | Required for EU visitors |
| COPPA compliance | Children's privacy |
| Music licensing | Royalty-free music library licensing |
| AI content policy | AI-generated content ownership and liability |
| Gift card regulations | State-specific gift card laws |
| Coupon regulations | State-specific coupon laws |

*Note: This PRD does not provide legal advice. All legal items must be reviewed by qualified legal counsel.*

---

## §54 Moderation

### 54.1 Moderation Philosophy

MemorableDay is a platform for creating and sharing experiences. Like any platform, it can be misused. The moderation system must prevent abuse without creating friction for legitimate users.

**Moderation principles:**
- Proactive (detect before harm occurs) + reactive (respond to reports)
- Proportionate (response matches severity)
- Transparent (users understand what's allowed)
- Appealable (users can contest moderation decisions)

### 54.2 Acceptable Use Policy

The Acceptable Use Policy (AUP) must prohibit:

| Category | Examples |
|---|---|
| **Illegal content** | CSAM, illegal weapons, drug trafficking |
| **Harassment** | Targeted harassment, threats, doxxing |
| **Hate speech** | Content targeting protected characteristics |
| **Spam** | Bulk unsolicited experiences |
| **Phishing** | Experiences designed to steal credentials or data |
| **Malicious redirects** | CTAs linking to malware or phishing sites |
| **Copyright infringement** | Unauthorized use of copyrighted content |
| **Impersonation** | Impersonating brands, public figures, or individuals |
| **Fraud** | Fake rewards, deceptive business practices |
| **Adult content** | Explicit sexual content (unless age-verified platform, which MemorableDay is not) |

### 54.3 Automated Moderation

**Requirements:**
- `PRD-SEC-108`: All uploaded images must be scanned for CSAM using PhotoDNA or equivalent
- `PRD-SEC-109`: All uploaded images must be scanned for explicit content using AI moderation
- `PRD-SEC-110`: All AI-generated text must be filtered through a content safety layer
- `PRD-SEC-111`: All CTA URLs must be checked against known phishing/malware databases
- `PRD-SEC-112`: Experiences with flagged content must be automatically paused pending review
- `PRD-SEC-113`: Automated moderation must have a low false-positive rate (< 1%)

### 54.4 User Reporting

**Requirements:**
- `PRD-SEC-114`: Every experience must have a "Report" button accessible to recipients
- `PRD-SEC-115`: Report categories: Spam, Harassment, Inappropriate content, Phishing, Copyright, Other
- `PRD-SEC-116`: Reports must be reviewed within 24 hours (critical) or 72 hours (standard)
- `PRD-SEC-117`: Reporters must receive a notification when their report is resolved
- `PRD-SEC-118`: Repeat reporters must be tracked (to identify false reporters)

### 54.5 Moderation Actions

| Action | Description | When Used |
|---|---|---|
| **Warning** | Email warning to creator | First offense, minor violation |
| **Experience removal** | Experience taken down | Content violation |
| **Account suspension** | Temporary account suspension | Repeated violations |
| **Account termination** | Permanent account deletion | Severe violations |
| **IP ban** | Block IP from creating accounts | Severe/repeated violations |
| **Law enforcement referral** | Report to authorities | Illegal content (CSAM, threats) |

### 54.6 Appeal Process

**Requirements:**
- `PRD-SEC-119`: Users must be able to appeal moderation decisions
- `PRD-SEC-120`: Appeals must be reviewed by a human (not automated)
- `PRD-SEC-121`: Appeal decisions must be communicated within 7 days
- `PRD-SEC-122`: Appeal decisions are final (no further appeals)

### 54.7 Business Account Moderation

Business accounts have additional moderation considerations:

| Requirement | Description |
|---|---|
| `PRD-SEC-123` | Business accounts must verify their business identity (email domain, website) |
| `PRD-SEC-124` | Business experiences sent to customers must comply with CAN-SPAM and TCPA |
| `PRD-SEC-125` | Businesses must maintain opt-out lists for their customers |
| `PRD-SEC-126` | Businesses that violate spam laws must be suspended |

### 54.8 Abuse Prevention

**Rate limiting:**

| Action | Limit |
|---|---|
| Experience creation | 10 per hour per account |
| Experience sends | 1,000 per day per account (Business plan) |
| API requests | Per plan limits |
| File uploads | 50 per hour per account |
| AI generations | Per plan credit limits |

**Fraud prevention:**

| Requirement | Description |
|---|---|
| `PRD-SEC-127` | Multiple accounts from same IP/device must be detected |
| `PRD-SEC-128` | Reward harvesting (claiming rewards without genuine engagement) must be detected |
| `PRD-SEC-129` | Fake business accounts must be detected and reviewed |
| `PRD-SEC-130` | Suspicious automation patterns must trigger review |

---

*Next: [Hosting, Cloudflare, Domains & Custom Domains →](24-hosting-cloudflare-domains.md)*
