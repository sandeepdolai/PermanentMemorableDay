# 08 — Interaction System

**Section:** §20 Interaction System  
**PRD Index:** [← 3D System](07-3d-system.md) | [Next: AI System →](09-ai-system.md)

---

## §20 Interaction System

### 20.1 Why Interactivity Is Core

Static digital content is ignored. Interactive content is experienced.

The interaction system is what separates MemorableDay from every digital card, email, and notification. When a recipient taps a gift box and it opens to reveal a message, they are not reading content — they are participating in a moment. That participation creates memory.

**The interaction principle:**
> Every interaction should feel like unwrapping a gift — there is anticipation, a moment of action, and a satisfying reveal.

### 20.2 Interaction Categories

#### 20.2.1 Navigation Interactions

These interactions move the recipient through the experience:

| Interaction | Description | Platform |
|---|---|---|
| **Tap to advance** | Tap anywhere to go to next scene | Mobile + Desktop |
| **Swipe to advance** | Swipe left to go to next scene | Mobile |
| **Click to advance** | Click anywhere to go to next scene | Desktop |
| **Auto-advance** | Scene advances automatically after X seconds | All |
| **Button navigation** | Explicit "Next" / "Back" buttons | All |
| **Scroll navigation** | Scroll down to reveal content within a scene | All |

#### 20.2.2 Reveal Interactions

These interactions reveal hidden content:

| Interaction | Description | Emotional Effect |
|---|---|---|
| **Tap to reveal** | Tap an object to reveal content beneath | Surprise, anticipation |
| **Gift box opening** | Tap gift box → it opens → content revealed | Unwrapping joy |
| **Envelope opening** | Tap envelope → it opens → letter emerges | Intimacy, anticipation |
| **Scratch to reveal** | Scratch a surface to reveal content | Lottery excitement |
| **Password reveal** | Enter a word/phrase to unlock content | Intimacy, shared secret |
| **Countdown reveal** | Content revealed when countdown reaches zero | Anticipation |
| **Shake to reveal** | Shake device to reveal content | Playfulness |
| **Pinch to reveal** | Pinch gesture reveals content | Discovery |

#### 20.2.3 Engagement Interactions

These interactions increase engagement and time-on-experience:

| Interaction | Description | Use Case |
|---|---|---|
| **Photo gallery swipe** | Swipe through photos | Memory sharing |
| **Quiz / Question** | Answer a question, see result | Fun, engagement |
| **Choice selection** | Choose between options | Branching experiences |
| **Treasure hunt** | Multiple clues leading to a final reveal | Playful, memorable |
| **Memory timeline** | Scroll through a timeline of memories | Anniversary, milestone |
| **Star collection** | Tap stars to collect them | Playful, gamification |
| **Balloon pop** | Tap balloons to pop them | Celebration, fun |
| **Candle blow-out** | Blow into microphone (or tap) to blow out candles | Birthday, magical |

#### 20.2.4 Action Interactions

These interactions drive specific outcomes:

| Interaction | Description | Business Value |
|---|---|---|
| **CTA button** | Click to visit URL | Conversion, traffic |
| **Reward claim** | Tap to reveal and copy coupon code | Redemption |
| **Track order** | Tap to open tracking page | Customer service |
| **Leave review** | Tap to open review platform | Social proof |
| **Share experience** | Tap to share the experience | Viral growth |
| **Create own** | Tap to create their own experience | Acquisition |
| **Contact support** | Tap to open support channel | Customer service |
| **Add to calendar** | Tap to add an event to calendar | Engagement |
| **Save to photos** | Tap to save a moment as an image | Sharing, memory |

### 20.3 Interaction Design Requirements

#### 20.3.1 Visual Affordances

Recipients must always know what to do. Every interactive element must communicate its interactivity:

| Affordance Type | Implementation |
|---|---|
| **Pulse animation** | Interactive objects gently pulse to indicate they can be tapped |
| **Glow effect** | Subtle glow around interactive elements |
| **Hint text** | "Tap to open" or "Tap to reveal" text (fades after first interaction) |
| **Arrow indicator** | Subtle arrow indicating swipe direction |
| **Progress indicator** | Dots or bar showing position in experience |
| **Cursor change** | Pointer cursor on desktop for interactive elements |

**Requirements:**
- `PRD-CORE-069`: Every interactive element must have at least one visual affordance
- `PRD-CORE-070`: Hint text must appear on first view and fade after the first interaction
- `PRD-CORE-071`: Progress indicator must be visible but not distracting
- `PRD-CORE-072`: Affordances must work in both light and dark backgrounds

#### 20.3.2 Interaction Feedback

Every interaction must have immediate, satisfying feedback:

| Feedback Type | Description |
|---|---|
| **Visual feedback** | Animation plays immediately on interaction |
| **Haptic feedback** | Vibration on mobile (where supported) |
| **Sound feedback** | Optional sound effect on interaction |
| **State change** | Element visually changes state after interaction |

**Requirements:**
- `PRD-CORE-073`: Visual feedback must begin within 100ms of interaction
- `PRD-CORE-074`: Haptic feedback must use appropriate intensity (light for navigation, medium for reveals)
- `PRD-CORE-075`: Sound feedback must be optional and respect device mute settings
- `PRD-CORE-076`: Interactions must be idempotent — tapping twice should not cause unexpected behavior

#### 20.3.3 Accessibility for Interactions

- `PRD-CORE-077`: All interactions must be achievable via keyboard (Tab + Enter/Space)
- `PRD-CORE-078`: Screen readers must announce interactive elements and their purpose
- `PRD-CORE-079`: Reduced motion preference must disable or simplify all animations
- `PRD-CORE-080`: Scratch-to-reveal must have a tap-to-reveal alternative for accessibility
- `PRD-CORE-081`: Shake-to-reveal must have a tap-to-reveal alternative

### 20.4 Specific Interaction Specifications

#### 20.4.1 Gift Box Opening

The gift box is one of the most important interactions on the platform.

**Flow:**
1. Gift box appears in scene (with subtle pulse animation)
2. Hint: "Tap to open" appears briefly
3. Recipient taps the box
4. Box shakes slightly (anticipation)
5. Lid lifts with animation
6. Contents emerge (confetti, flowers, message, reward, etc.)
7. Scene transitions to next content

**Requirements:**
- `PRD-3D-015`: Gift box animation must be smooth at 60fps on mid-range mobile
- `PRD-3D-016`: Box contents must be configurable by creator (confetti, flowers, message, reward)
- `PRD-3D-017`: Box style, color, and ribbon must be configurable
- `PRD-3D-018`: Box opening sound effect must be available (optional)

#### 20.4.2 Envelope Opening

**Flow:**
1. Envelope appears (with subtle pulse)
2. Hint: "Tap to open"
3. Recipient taps
4. Envelope flap lifts
5. Letter/card slides out
6. Letter unfolds to reveal message
7. Scene continues

**Requirements:**
- `PRD-3D-019`: Envelope style must be configurable (classic, modern, wax seal, etc.)
- `PRD-3D-020`: Letter content must be the creator's message (rendered in 3D)
- `PRD-3D-021`: Envelope color and pattern must be configurable

#### 20.4.3 Scratch to Reveal

**Flow:**
1. Scratch card appears with a surface (gold, silver, or custom)
2. Hint: "Scratch to reveal"
3. Recipient scratches with finger/mouse
4. Surface reveals content beneath (reward, message, image)
5. When 70% scratched, full reveal triggers automatically

**Requirements:**
- `PRD-CORE-082`: Scratch interaction must work with both touch and mouse
- `PRD-CORE-083`: Scratch surface must have a satisfying visual effect (particles, texture removal)
- `PRD-CORE-084`: Auto-reveal at 70% scratch must be smooth and satisfying
- `PRD-CORE-085`: Scratch card must have a tap-to-reveal accessibility alternative

#### 20.4.4 Password Reveal

**Flow:**
1. Locked content appears with a password field
2. Hint: "Enter the secret word"
3. Recipient types the password
4. If correct: content reveals with animation
5. If incorrect: gentle shake animation, try again

**Requirements:**
- `PRD-CORE-086`: Password must be set by creator in builder
- `PRD-CORE-087`: Password must be case-insensitive by default (configurable)
- `PRD-CORE-088`: No limit on password attempts (this is not a security mechanism, it's a fun interaction)
- `PRD-CORE-089`: Password hint must be optionally configurable by creator

#### 20.4.5 Countdown Timer

**Flow:**
1. Countdown timer appears in scene
2. Timer counts down to a specific date/time
3. When countdown reaches zero: reveal animation plays
4. Content is revealed (message, reward, etc.)

**Requirements:**
- `PRD-CORE-090`: Countdown must be accurate to the second
- `PRD-CORE-091`: Countdown must respect the recipient's time zone
- `PRD-CORE-092`: Countdown must handle the case where the recipient opens the experience after the countdown has ended (show the reveal immediately)
- `PRD-CORE-093`: Countdown display must be beautiful and customizable (style, size, color)

#### 20.4.6 Treasure Hunt / Multi-Clue Experience

**Flow:**
1. Experience begins with a clue
2. Clue leads to a location, word, or action
3. Recipient enters the answer or performs the action
4. Next clue is revealed
5. Final clue leads to the main reveal

**Requirements:**
- `PRD-CORE-094`: Treasure hunt is an Advanced feature (Pro plan and above)
- `PRD-CORE-095`: Creator can define up to 10 clues
- `PRD-CORE-096`: Each clue can be text, image, or video
- `PRD-CORE-097`: Answers can be text input or location-based (future)

### 20.5 Interaction Analytics

Every interaction is tracked for analytics:

| Event | Data Captured |
|---|---|
| **Experience opened** | Timestamp, device type, referrer |
| **Scene viewed** | Scene number, time spent |
| **Interaction performed** | Interaction type, scene, timestamp |
| **CTA clicked** | Button label, URL, timestamp |
| **Reward claimed** | Reward type, timestamp |
| **Experience completed** | Completion rate, total time |
| **Share clicked** | Share method, timestamp |
| **Create own clicked** | Timestamp (viral conversion) |

**Requirements:**
- `PRD-CORE-098`: Analytics must be collected without requiring recipient login
- `PRD-CORE-099`: Analytics must not collect PII beyond what the creator provided
- `PRD-CORE-100`: Analytics must be available to creators in real-time (or near real-time)
- `PRD-CORE-101`: Analytics must respect recipient privacy preferences (where applicable)

### 20.6 Interaction Builder UX

In the Experience Builder, creators configure interactions through a simple interface:

**For each interactive block:**
1. Select the interaction type from a dropdown
2. Configure the trigger (auto, tap, scroll)
3. Configure the reveal content
4. Preview the interaction in the builder
5. Test on mobile preview

**Requirements:**
- `PRD-UX-018`: Interactions must be previewable in the builder without publishing
- `PRD-UX-019`: Builder must show a "Test Interaction" button for each interactive block
- `PRD-UX-020`: Interaction configuration must use plain language, not technical terms

### 20.7 Future Interactions (Experimental)

| Interaction | Description | Feasibility |
|---|---|---|
| **AR reveal** | Point camera at a surface to reveal 3D content | Medium (WebXR) |
| **Voice activation** | Say a word to trigger reveal | Medium (Web Speech API) |
| **Geolocation reveal** | Content revealed at a specific location | Medium |
| **Time-based reveal** | Content revealed at a specific time of day | High |
| **Collaborative experience** | Multiple recipients interact together | Low (complex) |
| **Mini-game** | Simple game within the experience | Medium |
| **Music creation** | Recipient creates a melody | Low (complex) |

---

*Next: [AI System →](09-ai-system.md)*
