# 14 — Dashboard & Analytics

**Sections:** §29 Dashboard · §30 Analytics  
**PRD Index:** [← E-commerce Integrations](13-ecommerce-integrations.md) | [Next: Account & Team →](15-account-team-agency-white-label.md)

---

## §29 Dashboard

### 29.1 Dashboard Philosophy

The dashboard is the command center. It must answer the most important questions immediately:

- **Personal users:** "What have I created? What's been opened? What should I create next?"
- **Business users:** "How are my automations performing? What's my open rate? What needs attention?"

Dashboards must be fast, clear, and actionable. Data without action is noise.

### 29.2 Personal User Dashboard

See [§13 Personal User Experience](05-personal-business-recipient-experience.md) for the full personal dashboard specification.

**Key dashboard widgets:**

| Widget | Description |
|---|---|
| **Recent Experiences** | Last 5 experiences with status and open indicator |
| **Quick Create** | Prominent button to start a new experience |
| **Upcoming Occasions** | Dates added by user with "Create Experience" CTA |
| **Drafts** | Unfinished experiences with "Continue" CTA |
| **Scheduled** | Upcoming scheduled experiences |
| **Account Status** | Plan, AI credits remaining, storage used |

### 29.3 Business Dashboard — Overview

The business dashboard overview is the first screen after login. It must show the most important information at a glance.

**Overview widgets:**

| Widget | Description | Timeframe |
|---|---|---|
| **Experiences Sent** | Total experiences sent | Last 30 days |
| **Open Rate** | Percentage of sent experiences opened | Last 30 days |
| **Active Automations** | Number of active automations | Current |
| **Rewards Claimed** | Total rewards claimed | Last 30 days |
| **Revenue Attributed** | Revenue from reward redemptions | Last 30 days |
| **Top Experience** | Best-performing experience by open rate | Last 30 days |
| **Recent Activity** | Last 10 automation events | Real-time |
| **Automation Health** | Status of all automations (active/paused/error) | Current |

**Requirements:**
- `PRD-BIZ-018`: Overview must load in under 2 seconds
- `PRD-BIZ-019`: Overview must be customizable (widgets can be rearranged or hidden)
- `PRD-BIZ-020`: Overview must show alerts for automations with errors

### 29.4 Business Dashboard — Experiences

**Experiences list view:**

| Column | Description |
|---|---|
| **Name** | Experience name |
| **Type** | Manual / Automated |
| **Status** | Draft / Active / Paused / Archived |
| **Sent** | Total sends |
| **Open Rate** | Percentage opened |
| **Completion Rate** | Percentage completed |
| **Rewards Claimed** | Total rewards claimed |
| **Last Sent** | Date of last send |
| **Actions** | Edit / Duplicate / Archive / Delete |

**Requirements:**
- `PRD-BIZ-021`: Experiences list must be filterable by status, type, and date range
- `PRD-BIZ-022`: Experiences list must be sortable by any column
- `PRD-BIZ-023`: Clicking an experience must open its detailed analytics view

### 29.5 Business Dashboard — Automations

**Automations list view:**

| Column | Description |
|---|---|
| **Name** | Automation name |
| **Trigger** | What triggers this automation |
| **Status** | Active / Paused / Error |
| **Sent (30d)** | Sends in last 30 days |
| **Open Rate** | Percentage opened |
| **Last Triggered** | Date of last trigger |
| **Actions** | Edit / Pause / Duplicate / Delete |

**Requirements:**
- `PRD-BIZ-024`: Automation status must be changeable from the list view (toggle active/paused)
- `PRD-BIZ-025`: Automation errors must show a clear error message and suggested fix
- `PRD-BIZ-026`: Clicking an automation must open its detailed analytics view

### 29.6 Business Dashboard — Customers

**Customer list view (if CRM integration active):**

| Column | Description |
|---|---|
| **Name** | Customer name |
| **Email** | Customer email |
| **Experiences Received** | Total experiences received |
| **Last Experience** | Date of last experience |
| **Open Rate** | Percentage of experiences opened |
| **Rewards Claimed** | Total rewards claimed |
| **Orders** | Total orders (from integration) |
| **Actions** | View history / Send experience |

**Requirements:**
- `PRD-BIZ-027`: Customer list is available on Business plan and above
- `PRD-BIZ-028`: Customer list must be searchable by name and email
- `PRD-BIZ-029`: Clicking a customer must show their full experience history

### 29.7 Business Dashboard — Campaigns

**Campaign management:**

| Feature | Description |
|---|---|
| **Create Campaign** | Create a manual campaign for a customer list |
| **Campaign List** | All campaigns with status and performance |
| **Audience Builder** | Define the audience for a campaign |
| **Schedule** | Set campaign send date/time |
| **Preview** | Preview the experience before sending |
| **Analytics** | Campaign performance after sending |

---

## §30 Analytics

### 30.1 Analytics Philosophy

Analytics must answer real business questions, not just display numbers. Every metric must be actionable.

**The analytics hierarchy:**
1. **Delivery** — Did the experience reach the recipient?
2. **Engagement** — Did the recipient open and interact with it?
3. **Completion** — Did the recipient complete the full experience?
4. **Action** — Did the recipient take the desired action (CTA, reward)?
5. **Outcome** — Did the experience drive a business outcome (purchase, review, referral)?

### 30.2 Experience-Level Analytics

**For every experience:**

| Metric | Description | Calculation |
|---|---|---|
| **Sent** | Total times the experience link was sent | Count |
| **Unique Opens** | Unique recipients who opened | Count |
| **Open Rate** | Unique opens / Sent | Percentage |
| **Total Views** | Total views (including repeat views) | Count |
| **Completion Rate** | Recipients who reached the last scene | Percentage |
| **Average Time Spent** | Average time from open to close | Seconds |
| **Scene Drop-off** | Where recipients stop engaging | Per-scene percentage |
| **Interaction Rate** | Recipients who performed at least one interaction | Percentage |
| **CTA Click Rate** | Recipients who clicked a CTA button | Percentage |
| **Reward Claim Rate** | Recipients who claimed a reward | Percentage |
| **Share Rate** | Recipients who shared the experience | Percentage |
| **Create Own Rate** | Recipients who clicked "Create your own" | Percentage |

### 30.3 Scene-Level Analytics

**For each scene within an experience:**

| Metric | Description |
|---|---|
| **Views** | Recipients who reached this scene |
| **Drop-off Rate** | Recipients who left at this scene |
| **Interaction Rate** | Recipients who interacted with this scene |
| **Time Spent** | Average time spent on this scene |
| **Interaction Type** | What interactions were performed |

**Requirements:**
- `PRD-BIZ-030`: Scene-level analytics must be visualized as a funnel
- `PRD-BIZ-031`: Drop-off points must be highlighted to help businesses optimize experiences

### 30.4 Automation Analytics

**For each automation:**

| Metric | Description |
|---|---|
| **Triggered** | Total trigger events |
| **Sent** | Total experiences sent |
| **Delivery Rate** | Sent / Triggered |
| **Open Rate** | Opened / Sent |
| **Completion Rate** | Completed / Opened |
| **CTA Click Rate** | CTA clicks / Opened |
| **Reward Claim Rate** | Rewards claimed / Sent |
| **Revenue Attributed** | Revenue from reward redemptions |
| **Errors** | Failed sends with error details |

### 30.5 Business-Level Analytics

**Aggregate analytics across all experiences and automations:**

| Metric | Description |
|---|---|
| **Total Experiences Sent** | All-time and period |
| **Total Unique Recipients** | All-time and period |
| **Average Open Rate** | Across all experiences |
| **Average Completion Rate** | Across all experiences |
| **Total Rewards Issued** | All-time and period |
| **Total Rewards Claimed** | All-time and period |
| **Total Revenue Attributed** | All-time and period |
| **Top Performing Experiences** | By open rate, completion rate, revenue |
| **Best Performing Automations** | By open rate, revenue |
| **Customer Engagement Score** | Composite score (proprietary) |

### 30.6 Analytics Timeframes

| Timeframe | Description |
|---|---|
| **Real-time** | Last 24 hours (updated every 5 minutes) |
| **7 days** | Last 7 days |
| **30 days** | Last 30 days |
| **90 days** | Last 90 days |
| **Custom** | Any date range |
| **All time** | Since account creation |

### 30.7 Analytics Visualization

**Chart types:**

| Chart | Use Case |
|---|---|
| **Line chart** | Trends over time (sends, opens, revenue) |
| **Bar chart** | Comparison (experience performance) |
| **Funnel chart** | Scene drop-off, conversion funnel |
| **Pie/donut chart** | Distribution (device type, share method) |
| **Heatmap** | Interaction patterns within a scene |
| **Table** | Detailed data with sorting and filtering |

**Requirements:**
- `PRD-BIZ-032`: Analytics charts must be interactive (hover for details, click to drill down)
- `PRD-BIZ-033`: Analytics must be exportable as CSV and PDF
- `PRD-BIZ-034`: Analytics must be available via API for business intelligence tools

### 30.8 Analytics Privacy

**Requirements:**
- `PRD-SEC-008`: Analytics must not collect recipient PII beyond what the creator provided
- `PRD-SEC-009`: Analytics must not use third-party tracking pixels or cookies
- `PRD-SEC-010`: Analytics data must be stored in compliance with applicable privacy laws
- `PRD-SEC-011`: Recipients must not be individually identifiable in aggregate analytics
- `PRD-SEC-012`: Analytics data must be deleted when an experience is deleted

### 30.9 Analytics Availability by Plan

| Feature | Free | Personal | Pro | Business | Growth | Agency |
|---|---|---|---|---|---|---|
| Basic open tracking | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Scene-level analytics | — | — | ✓ | ✓ | ✓ | ✓ |
| Interaction analytics | — | — | ✓ | ✓ | ✓ | ✓ |
| Automation analytics | — | — | — | ✓ | ✓ | ✓ |
| Revenue attribution | — | — | — | ✓ | ✓ | ✓ |
| Custom date ranges | — | — | ✓ | ✓ | ✓ | ✓ |
| CSV export | — | — | ✓ | ✓ | ✓ | ✓ |
| API access | — | — | — | — | ✓ | ✓ |

### 30.10 North Star Metric

**Recommended North Star Metric:**

> **Memorable Moments Delivered (MMD)** — the total number of Experiences opened by a recipient in a given period (weekly/monthly).

**Why this metric:**
- Captures both creator activity (someone created an experience) and recipient engagement (someone opened it)
- Reflects genuine product value (a created but unopened experience has no value)
- Correlates with viral growth (recipients who become creators)
- Works for both personal and business use cases
- Is not gameable by low-quality activity

**Supporting metrics:**
- **Creator activation rate** — percentage of signups who publish their first experience
- **Recipient-to-creator conversion rate** — percentage of recipients who create their own experience
- **Business automation open rate** — average open rate across all business automations
- **Monthly Recurring Revenue (MRR)** — primary revenue metric

---

*Next: [Account, Team, Agency & White Label →](15-account-team-agency-white-label.md)*
