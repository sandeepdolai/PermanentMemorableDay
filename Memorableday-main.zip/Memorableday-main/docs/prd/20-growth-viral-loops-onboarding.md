# 20 — Growth Strategy, Viral Loops & Onboarding

**Sections:** §44 Growth Strategy · §45 Viral Loops · §46 Onboarding  
**PRD Index:** [← SEO](19-seo-content-programmatic-seo.md) | [Next: UX & Design →](21-ux-design-requirements.md)

---

## §44 Growth Strategy

### 44.1 Growth Philosophy

MemorableDay's growth strategy is built on three compounding loops:

1. **SEO loop** — content attracts searchers → searchers become creators → creators create experiences → experiences attract recipients → recipients become creators
2. **Viral loop** — every experience sent is a product demo → recipients become creators → creators send more experiences
3. **Business loop** — businesses send experiences to customers → customers become personal users → personal users recommend MemorableDay to businesses

These loops compound. A business sending 1,000 experiences/month creates 1,000 potential personal users. A personal user creating 10 experiences/year creates 10 potential new users.

### 44.2 Growth Channels

| Channel | Priority | Timeline | Cost |
|---|---|---|---|
| **SEO / Organic search** | Primary | Long-term | Low (content investment) |
| **Viral / Product-led** | Primary | Immediate | Zero (built into product) |
| **Shopify App Store** | High | Phase 2 | Low (listing fee) |
| **Content marketing** | High | Medium-term | Low-Medium |
| **Social media (organic)** | Medium | Medium-term | Low |
| **Referral program** | Medium | Phase 2 | Low-Medium |
| **Paid search (Google)** | Medium | Phase 2 | Medium-High |
| **Influencer / Creator** | Medium | Phase 2 | Medium |
| **Partnership** | Medium | Phase 3 | Variable |
| **Paid social** | Low | Phase 3 | High |
| **Direct sales (Enterprise)** | Low | Phase 3 | High |

### 44.3 Product-Led Growth (PLG)

MemorableDay is fundamentally a PLG product. The product itself is the primary growth mechanism.

**PLG mechanisms:**

| Mechanism | Description | Impact |
|---|---|---|
| **Recipient-to-creator** | Every recipient sees the product; some become creators | Very High |
| **MemorableDay attribution** | "Created with MemorableDay" on every free experience | High |
| **QR code sharing** | QR codes on experiences drive offline-to-online discovery | Medium |
| **Social sharing** | Recipients share experiences on social media | Medium |
| **Occasion reminders** | Reminders bring creators back for every occasion | High |
| **Business viral** | Business experiences reach thousands of customers | Very High |

### 44.4 Referral Program

**Personal referral program:**
- Creator refers a friend → friend signs up → creator gets 1 month free
- Referred friend gets 14-day trial of Personal plan
- Referral tracked via unique referral link

**Business referral program:**
- Business refers another business → both get 1 month free
- Referral tracked via unique referral link
- Agency referral: agency refers a client → agency gets commission

**Requirements:**
- `PRD-CORE-168`: Referral links must be unique per user
- `PRD-CORE-169`: Referral rewards must be applied automatically via Lemon Squeezy
- `PRD-CORE-170`: Referral tracking must be fraud-resistant (no self-referral, no fake accounts)
- `PRD-CORE-171`: Referral dashboard must show: referrals sent, referrals converted, rewards earned

### 44.5 Social Media Strategy

**Platform priorities:**

| Platform | Content Type | Audience |
|---|---|---|
| **TikTok** | Experience demos, "how I made this" videos | Personal users (18–35) |
| **Instagram** | Beautiful experience screenshots, Reels | Personal users (25–45) |
| **Pinterest** | Occasion inspiration, template showcases | Personal users (25–55) |
| **LinkedIn** | Business use cases, customer experience content | Business users |
| **YouTube** | Tutorials, case studies, experience demos | Both |
| **Twitter/X** | Product updates, industry commentary | Business users |

**Content strategy:**
- Show, don't tell — demonstrate experiences in action
- User-generated content — share experiences created by users (with permission)
- Behind-the-scenes — show how experiences are made
- Occasion-based content — post around major occasions (Valentine's Day, etc.)

### 44.6 Partnership Strategy

**Priority partnerships:**

| Partner Type | Examples | Value |
|---|---|---|
| **E-commerce platforms** | Shopify, WooCommerce | Distribution to merchants |
| **Email platforms** | Klaviyo, Mailchimp | Integration + co-marketing |
| **Loyalty platforms** | Smile.io, LoyaltyLion | Integration + co-marketing |
| **Shipping platforms** | ShipBob, EasyPost | Integration + co-marketing |
| **Digital agencies** | E-commerce agencies | White-label revenue |
| **Gift card platforms** | Giftly, Prezzee | Integration + co-marketing |
| **Occasion platforms** | Zola (weddings), The Knot | Co-marketing |

---

## §45 Viral Loops

### 45.1 The Primary Viral Loop

```
Creator creates experience
        ↓
Creator shares experience URL
        ↓
Recipient opens experience
        ↓
Recipient sees "Created with MemorableDay"
        ↓
Recipient clicks "Create your own"
        ↓
Recipient lands on conversion page
        ↓
Recipient signs up and creates their own experience
        ↓
New creator shares experience URL
        ↓
[Loop repeats]
```

**Viral coefficient target:** K > 0.3 (every 10 creators bring in 3+ new creators)

### 45.2 Optimizing the Viral Loop

**Step 1: Creator shares experience**
- Make sharing frictionless (one tap)
- Make the experience URL shareable on all channels
- Generate beautiful social previews

**Step 2: Recipient opens experience**
- Make the experience load fast (< 3 seconds)
- Make the first scene immediately impressive
- Create genuine surprise and delight

**Step 3: Recipient sees attribution**
- Attribution must be beautiful, not intrusive
- Attribution must appear at the right moment (end of experience)
- Attribution must be contextually relevant ("Want to create something like this?")

**Step 4: Recipient clicks "Create your own"**
- CTA must be compelling and specific ("Create a birthday experience for someone you love")
- CTA must be one tap
- Landing page must be optimized for conversion

**Step 5: Recipient signs up**
- Signup must be frictionless (Google OAuth, magic link)
- Signup must immediately show value (pre-selected template based on context)
- Signup must not require credit card

**Requirements:**
- `PRD-CORE-172`: Attribution CTA must be A/B tested for optimal conversion
- `PRD-CORE-173`: Recipient-to-creator conversion rate must be tracked as a key metric
- `PRD-CORE-174`: The landing page for recipient-to-creator conversion must be distinct from the main homepage

### 45.3 Business Viral Loop

```
Business sends experience to 1,000 customers
        ↓
500 customers open the experience
        ↓
50 customers click "Created with MemorableDay"
        ↓
25 customers sign up as personal users
        ↓
25 personal users create experiences for their networks
        ↓
[Personal viral loop activates]
```

**Business viral loop amplification:**
- Businesses with large customer bases are high-value viral nodes
- A single business sending 10,000 experiences/month can generate 100+ new personal users
- This makes business acquisition doubly valuable (direct revenue + viral amplification)

### 45.4 Social Sharing Loop

Recipients can share experiences they received on social media:

```
Recipient receives experience
        ↓
Recipient shares on Instagram/TikTok/Twitter
        ↓
Followers see the experience
        ↓
Followers click the link
        ↓
Followers see the experience
        ↓
Followers see "Created with MemorableDay"
        ↓
[Primary viral loop activates]
```

**Requirements:**
- `PRD-CORE-175`: Experiences must be shareable by recipients (unless creator disables sharing)
- `PRD-CORE-176`: Sharing must generate a beautiful social preview image
- `PRD-CORE-177`: Shared experiences must track the share source (who shared it)

### 45.5 Occasion Reminder Loop

```
User creates birthday experience for friend
        ↓
MemorableDay records: "User has a friend with a birthday"
        ↓
Next year: MemorableDay sends reminder
        ↓
User creates another experience
        ↓
[Retention loop activates]
```

**Requirements:**
- `PRD-CORE-178`: Occasion reminders must be opt-in
- `PRD-CORE-179`: Reminders must be sent at the right time (7 days, 3 days, 1 day before)
- `PRD-CORE-180`: Reminder emails must include a direct link to create a new experience for that occasion

---

## §46 Onboarding

### 46.1 Onboarding Philosophy

The goal of onboarding is to get users to their first "aha moment" as quickly as possible.

**Personal user aha moment:** "I just created something beautiful in 3 minutes and I can't wait to send it."

**Business user aha moment:** "My first automation is live and I can see it working."

Every onboarding step that doesn't move toward the aha moment is a step that should be removed.

### 46.2 Personal User Onboarding

**Onboarding flow:**

```
Step 1: Signup (30 seconds)
  → Email + password or Google OAuth
  → Email verification (magic link)
  → Account type: Personal

Step 2: Quick profile (30 seconds)
  → Name
  → Time zone
  → Skip option available

Step 3: Create your first experience (3–5 minutes)
  → "Let's create your first experience"
  → Occasion picker (or "I'll explore on my own")
  → Template selection (3 recommended)
  → AI assistance offer ("Tell me about the person")
  → Quick customization (name, message, photo)
  → Preview
  → Publish and share

Step 4: Success state
  → "Your experience is ready!"
  → Share options
  → "Add to your calendar for next year" (occasion reminder)
  → "Explore more templates"
```

**Onboarding requirements:**
- `PRD-UX-038`: Personal onboarding must be completable in under 5 minutes
- `PRD-UX-039`: Onboarding must not require credit card
- `PRD-UX-040`: Onboarding must offer a "skip" option at every step
- `PRD-UX-041`: Onboarding must end with a published experience (not just a draft)
- `PRD-UX-042`: Onboarding progress must be saved (user can resume if they leave)

### 46.3 Business User Onboarding

**Onboarding flow:**

```
Step 1: Signup (30 seconds)
  → Email + password or Google OAuth
  → Account type: Business
  → Business name

Step 2: Business profile (2 minutes)
  → Industry
  → Primary use case (post-purchase, retention, etc.)
  → Website URL (for brand color detection)

Step 3: Brand setup (2 minutes)
  → Upload logo
  → Confirm brand colors (auto-detected or manual)
  → Choose brand font

Step 4: Connect store (optional, 3 minutes)
  → "Connect your Shopify store" (or skip)
  → OAuth connection
  → Test event verification

Step 5: Create first automation (5 minutes)
  → Recommended: "Post-Purchase Thank You"
  → Select template (pre-filtered for use case)
  → Customize message and reward
  → Test experience (send to own email)
  → Activate automation

Step 6: Success state
  → "Your first automation is live!"
  → "Here's what happens next" (explanation of the flow)
  → "Explore more automations"
  → "Invite team members"
```

**Onboarding requirements:**
- `PRD-BIZ-059`: Business onboarding must be completable in under 15 minutes
- `PRD-BIZ-060`: Store connection must be optional (manual trigger available)
- `PRD-BIZ-061`: Test experience must be sendable to own email without affecting live automations
- `PRD-BIZ-062`: Onboarding must end with at least one active automation (or a clear next step)
- `PRD-BIZ-063`: Onboarding checklist must be visible in the dashboard until all steps are complete

### 46.4 Onboarding Email Sequence

**Personal user email sequence:**

| Email | Timing | Subject | Goal |
|---|---|---|---|
| Welcome | Immediately | "Welcome to MemorableDay 🎉" | Confirm signup, link to dashboard |
| First experience | Day 1 (if not created) | "Create your first experience in 3 minutes" | Drive first experience creation |
| Tips | Day 3 | "3 ways to make your experiences more memorable" | Educate, drive engagement |
| Upgrade prompt | Day 7 (if on free) | "You're running low on experiences" | Drive upgrade |
| Occasion reminder | Day 14 | "Add important dates to never miss a moment" | Drive retention feature adoption |

**Business user email sequence:**

| Email | Timing | Subject | Goal |
|---|---|---|---|
| Welcome | Immediately | "Welcome to MemorableDay for Business" | Confirm signup, link to dashboard |
| Onboarding | Day 1 (if not complete) | "Set up your first automation in 15 minutes" | Drive onboarding completion |
| Case study | Day 3 | "How [Brand] increased repeat purchases by 23%" | Build confidence |
| Integration guide | Day 5 | "Connect your Shopify store in 2 minutes" | Drive integration |
| Analytics | Day 7 | "Your first week: here's what's happening" | Show value |
| Upgrade prompt | Day 14 (if on trial) | "Your trial ends in 7 days" | Drive conversion |

### 46.5 In-App Onboarding

**Tooltips and guided tours:**
- First-time builder visit: guided tour of key features
- First automation: step-by-step guide
- First integration: connection wizard
- New features: contextual tooltips

**Requirements:**
- `PRD-UX-043`: Tooltips must be dismissible and not reappear after dismissal
- `PRD-UX-044`: Guided tours must be skippable
- `PRD-UX-045`: Onboarding checklist must show progress and celebrate completion

### 46.6 Demo Experiences

**Requirements:**
- `PRD-CORE-181`: A demo experience must be available at `memorableday.online/demo` (no login required)
- `PRD-CORE-182`: Demo experience must showcase the best of the platform (3D, AI, interactivity)
- `PRD-CORE-183`: Demo experience must end with a CTA to create an account
- `PRD-CORE-184`: Multiple demo experiences must be available (personal and business)

---

*Next: [UX & Design Requirements →](21-ux-design-requirements.md)*
