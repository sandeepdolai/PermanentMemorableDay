# 21 — UX & Design Requirements

**Sections:** §47 UX Requirements · §48 Design Requirements  
**PRD Index:** [← Growth & Onboarding](20-growth-viral-loops-onboarding.md) | [Next: Performance & Mobile →](22-performance-mobile-accessibility.md)

---

## §47 UX Requirements

### 47.1 UX Philosophy

MemorableDay's UX must serve two very different users — the personal user who wants simplicity and the business user who needs power — without making either feel like they're using the wrong product.

**UX principles:**
1. **Emotion first** — every UX decision must serve the emotional goal of the product
2. **Progressive disclosure** — show simple by default; reveal complexity when needed
3. **Delight in the details** — micro-interactions, transitions, and animations must feel premium
4. **Consistency** — same patterns, same language, same behavior across the product
5. **Accessibility** — the product must work for everyone (see §51)
6. **Speed** — every interaction must feel instant

### 47.2 Information Architecture

**Public website IA:**

```
memorableday.online
├── Home
├── Personal
│   ├── Occasions (hub)
│   │   ├── Birthday
│   │   ├── Anniversary
│   │   └── [All occasions]
│   ├── For [Recipient] (hub)
│   └── Templates
├── Business
│   ├── Use Cases (hub)
│   │   ├── Post-Purchase
│   │   ├── Shipping
│   │   └── [All use cases]
│   ├── Integrations
│   └── Pricing
├── Features
├── Pricing
├── Blog
├── Guides
├── Compare
├── About
├── Contact
└── Legal (Privacy, Terms, etc.)
```

**Personal app IA:**

```
app.memorableday.online (personal)
├── Home / Dashboard
├── Create (experience builder)
├── My Experiences
│   ├── Drafts
│   ├── Scheduled
│   └── Sent
├── Templates
├── Favorites
└── Account
    ├── Profile
    ├── Billing
    ├── Notifications
    └── Privacy
```

**Business app IA:**

```
app.memorableday.online (business)
├── Overview / Dashboard
├── Experiences
├── Templates
├── Builder
├── Automations
├── Customers
├── Campaigns
├── Rewards
├── Analytics
├── Integrations
├── Brand Settings
├── Team
├── API
├── Billing
└── Settings
```

### 47.3 Navigation Requirements

**Requirements:**
- `PRD-UX-046`: Primary navigation must be visible on all pages without scrolling
- `PRD-UX-047`: Current page must be clearly indicated in navigation
- `PRD-UX-048`: Navigation must collapse to a hamburger menu on mobile
- `PRD-UX-049`: Business dashboard navigation must support keyboard navigation
- `PRD-UX-050`: Navigation must not exceed 2 levels of depth (no mega-menus)

### 47.4 Forms and Input

**Requirements:**
- `PRD-UX-051`: All form fields must have visible labels (not just placeholder text)
- `PRD-UX-052`: Form validation must be inline (not just on submit)
- `PRD-UX-053`: Error messages must be specific and actionable ("Email is already in use" not "Invalid input")
- `PRD-UX-054`: Required fields must be clearly marked
- `PRD-UX-055`: Forms must support autofill
- `PRD-UX-056`: Long forms must show progress (step 1 of 3)
- `PRD-UX-057`: Form submission must show a loading state

### 47.5 Empty States

Every empty state must be helpful and encouraging:

| Empty State | Message | CTA |
|---|---|---|
| No experiences | "You haven't created any experiences yet" | "Create your first experience" |
| No automations | "No automations yet" | "Create your first automation" |
| No analytics | "No data yet — send your first experience to see analytics" | "Create an experience" |
| No templates | "No templates found" | "Browse all templates" |
| No customers | "No customers yet — connect your store to see customers" | "Connect store" |

**Requirements:**
- `PRD-UX-058`: Every empty state must have an illustration or icon
- `PRD-UX-059`: Every empty state must have a clear CTA
- `PRD-UX-060`: Empty states must not show error-like styling

### 47.6 Loading States

**Requirements:**
- `PRD-UX-061`: All loading states must use skeleton screens (not spinners) for content areas
- `PRD-UX-062`: Spinners are acceptable for button loading states
- `PRD-UX-063`: Loading states must appear within 100ms of action
- `PRD-UX-064`: Long operations (> 3 seconds) must show progress indication

### 47.7 Error States

**Requirements:**
- `PRD-UX-065`: All error states must explain what went wrong in plain language
- `PRD-UX-066`: All error states must suggest a next action
- `PRD-UX-067`: 404 pages must be branded and helpful (not generic)
- `PRD-UX-068`: 500 errors must be branded and include a way to contact support
- `PRD-UX-069`: Network errors must be handled gracefully (offline state)

### 47.8 Notifications and Feedback

**Toast notifications:**
- Success: green, appears for 3 seconds
- Error: red, appears until dismissed
- Warning: yellow, appears for 5 seconds
- Info: blue, appears for 3 seconds

**Requirements:**
- `PRD-UX-070`: Toast notifications must not block content
- `PRD-UX-071`: Toast notifications must be dismissible
- `PRD-UX-072`: Multiple toasts must stack, not overlap
- `PRD-UX-073`: Critical errors must use a modal, not a toast

### 47.9 Confirmation Dialogs

**Requirements:**
- `PRD-UX-074`: Destructive actions (delete, cancel subscription) must require confirmation
- `PRD-UX-075`: Confirmation dialogs must clearly state what will happen
- `PRD-UX-076`: Confirmation dialogs must have a clear cancel option
- `PRD-UX-077`: Destructive action buttons must be red

### 47.10 Keyboard Shortcuts

**Builder keyboard shortcuts:**

| Shortcut | Action |
|---|---|
| `Cmd/Ctrl + Z` | Undo |
| `Cmd/Ctrl + Shift + Z` | Redo |
| `Cmd/Ctrl + S` | Save |
| `Cmd/Ctrl + P` | Preview |
| `Cmd/Ctrl + D` | Duplicate scene |
| `Delete/Backspace` | Delete selected block |
| `Escape` | Deselect / Close panel |
| `Arrow keys` | Move selected block |

---

## §48 Design Requirements

### 48.1 Design Direction

MemorableDay must feel:

| Quality | Description |
|---|---|
| **Premium** | High-quality visuals, refined typography, thoughtful spacing |
| **Emotional** | Warm, human, capable of conveying genuine feeling |
| **Magical** | 3D, animation, and interaction create moments of delight |
| **Modern** | Contemporary design language, not dated or generic |
| **Trustworthy** | Clean, professional, consistent — inspires confidence |
| **Accessible** | Beautiful and usable for everyone |

MemorableDay must NOT feel like:
- A generic SaaS dashboard (cold, corporate, utilitarian)
- A greeting card website (cheesy, dated, low-quality)
- A Canva clone (template-heavy, design-tool aesthetic)
- An email marketing platform (data-heavy, conversion-focused)

### 48.2 Color System

**Primary palette:**

| Color | Role | Usage |
|---|---|---|
| **Deep Violet** (#4A1D96) | Primary brand color | CTAs, key UI elements |
| **Warm Rose** (#F43F5E) | Accent, emotional moments | Hearts, love, celebration |
| **Golden Amber** (#F59E0B) | Reward, achievement | Rewards, VIP, stars |
| **Soft Cream** (#FFF8F0) | Background | Page backgrounds |
| **Deep Charcoal** (#1A1A2E) | Text | Primary text |

**Semantic colors:**

| Color | Role |
|---|---|
| **Success Green** (#10B981) | Success states, confirmations |
| **Warning Amber** (#F59E0B) | Warnings, cautions |
| **Error Red** (#EF4444) | Errors, destructive actions |
| **Info Blue** (#3B82F6) | Information, links |

**Requirements:**
- `PRD-UX-078`: All color combinations must meet WCAG 2.1 AA contrast requirements
- `PRD-UX-079`: Color must not be the only way to convey information (icons + color)
- `PRD-UX-080`: Dark mode must be supported (Phase 2)

### 48.3 Typography

**Font system:**

| Role | Font | Weight | Size |
|---|---|---|---|
| **Display** | Playfair Display or similar serif | 700 | 48–72px |
| **Heading** | Inter or similar sans-serif | 600–700 | 24–40px |
| **Body** | Inter | 400 | 16px |
| **Caption** | Inter | 400 | 14px |
| **Label** | Inter | 500 | 12–14px |
| **Code** | JetBrains Mono | 400 | 14px |

**Requirements:**
- `PRD-UX-081`: Fonts must be loaded with `font-display: swap` to prevent FOIT
- `PRD-UX-082`: Font files must be self-hosted (not loaded from Google Fonts) for performance and privacy
- `PRD-UX-083`: Minimum body text size must be 16px
- `PRD-UX-084`: Line height must be at least 1.5 for body text

### 48.4 Spacing System

**8px base grid:**

| Token | Value | Usage |
|---|---|---|
| `space-1` | 4px | Micro spacing |
| `space-2` | 8px | Tight spacing |
| `space-3` | 12px | Small spacing |
| `space-4` | 16px | Default spacing |
| `space-6` | 24px | Medium spacing |
| `space-8` | 32px | Large spacing |
| `space-12` | 48px | Section spacing |
| `space-16` | 64px | Page section spacing |

### 48.5 Component Library

**Core components:**

| Component | Description |
|---|---|
| **Button** | Primary, secondary, ghost, destructive, icon |
| **Input** | Text, email, password, textarea, select |
| **Card** | Content card with optional image, title, body, actions |
| **Modal** | Overlay dialog for confirmations and forms |
| **Toast** | Notification messages |
| **Badge** | Status indicators, labels |
| **Avatar** | User/brand avatar with fallback |
| **Dropdown** | Select menus and action menus |
| **Tabs** | Content switching |
| **Toggle** | Boolean settings |
| **Slider** | Range inputs |
| **Progress** | Progress bars and rings |
| **Skeleton** | Loading placeholders |
| **Tooltip** | Contextual help |
| **Breadcrumb** | Navigation hierarchy |
| **Pagination** | List navigation |
| **Table** | Data tables with sorting and filtering |
| **Chart** | Analytics visualizations |

**Requirements:**
- `PRD-UX-085`: All components must be documented in a design system
- `PRD-UX-086`: All components must have defined states (default, hover, active, disabled, error)
- `PRD-UX-087`: All components must be accessible (ARIA labels, keyboard navigation)
- `PRD-UX-088`: Component library must be shared between design and engineering

### 48.6 Animation and Motion

**Motion principles:**
- Animations must feel natural and purposeful (not decorative)
- Animations must be fast (< 300ms for UI transitions)
- Animations must respect `prefers-reduced-motion`
- 3D animations are the exception — they can be longer and more elaborate

**UI animation guidelines:**

| Animation | Duration | Easing |
|---|---|---|
| Button hover | 150ms | ease-out |
| Modal open/close | 200ms | ease-in-out |
| Toast appear/disappear | 200ms | ease-in-out |
| Page transition | 300ms | ease-in-out |
| Dropdown open/close | 150ms | ease-out |
| Skeleton shimmer | 1500ms | linear (loop) |

**Requirements:**
- `PRD-UX-089`: All UI animations must respect `prefers-reduced-motion: reduce`
- `PRD-UX-090`: Animation duration must not exceed 500ms for UI elements
- `PRD-UX-091`: Animations must not cause layout shifts (CLS)

### 48.7 Iconography

**Requirements:**
- `PRD-UX-092`: Icons must be from a consistent icon library (e.g., Lucide, Heroicons)
- `PRD-UX-093`: Icons must be SVG (not icon fonts)
- `PRD-UX-094`: Icons must have accessible labels (aria-label or title)
- `PRD-UX-095`: Icon size must be consistent (16px, 20px, 24px)

### 48.8 Illustration Style

**Requirements:**
- `PRD-UX-096`: Illustrations must be consistent in style across the product
- `PRD-UX-097`: Illustrations must be used for empty states, onboarding, and marketing
- `PRD-UX-098`: Illustrations must be SVG for scalability and performance
- `PRD-UX-099`: Illustrations must be inclusive (diverse representation)

### 48.9 Responsive Design

**Breakpoints:**

| Breakpoint | Width | Target |
|---|---|---|
| Mobile | < 640px | Phones |
| Tablet | 640px–1024px | Tablets, small laptops |
| Desktop | 1024px–1440px | Laptops, desktops |
| Wide | > 1440px | Large monitors |

**Requirements:**
- `PRD-UX-100`: All pages must be fully functional at all breakpoints
- `PRD-UX-101`: Mobile layout must be designed first (mobile-first approach)
- `PRD-UX-102`: Touch targets must be at least 44×44px on mobile
- `PRD-UX-103`: Text must not be smaller than 16px on mobile

---

*Next: [Performance, Mobile & Accessibility →](22-performance-mobile-accessibility.md)*
