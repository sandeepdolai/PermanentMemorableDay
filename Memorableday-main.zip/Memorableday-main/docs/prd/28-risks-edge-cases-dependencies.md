# 28 — Risks, Edge Cases & Dependencies

**Sections:** §64 Risks · §65 Edge Cases · §66 Dependencies  
**PRD Index:** [← Business Model & KPIs](27-business-model-kpis.md) | [Next: Product Roadmap →](29-product-roadmap.md)

---

## §64 Risks

### 64.1 Product Risks

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| **3D performance on low-end devices** | High | High | Graceful degradation; 2D fallback; device detection |
| **AI costs exceed revenue** | Medium | High | Credit system; model selection; caching; usage limits |
| **Low recipient-to-creator conversion** | Medium | High | Optimize attribution CTA; A/B test; improve landing page |
| **3D assets feel generic or low-quality** | Medium | High | Invest in design quality; curate library carefully |
| **Builder too complex for non-technical users** | Medium | High | User testing; progressive disclosure; AI assistance |
| **Business automation reliability** | Medium | High | Robust retry logic; monitoring; alerts |
| **Shopify App Store rejection** | Low | High | Follow Shopify guidelines; prepare for review |
| **AI generates inappropriate content** | Medium | Medium | Content safety layer; moderation; user reporting |
| **Viral loop doesn't activate** | Medium | High | A/B test attribution; optimize conversion page |

### 64.2 Business Risks

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| **Slow SEO growth** | Medium | High | Invest in content; build backlinks; programmatic SEO |
| **High churn from personal users** | Medium | Medium | Improve retention features; occasion reminders; engagement |
| **Business users don't see ROI** | Medium | High | Better analytics; case studies; ROI calculator |
| **Competitor copies 3D experience** | Medium | Medium | Build moat through content, SEO, and network effects |
| **Lemon Squeezy pricing changes** | Low | Medium | Maintain billing abstraction; evaluate alternatives |
| **Cloudflare pricing changes** | Low | Medium | Monitor costs; maintain portability |
| **Shopify changes App Store policies** | Low | High | Diversify acquisition channels |
| **Economic downturn reduces SaaS spending** | Low | Medium | Focus on ROI-positive use cases; flexible pricing |

### 64.3 Technical Risks

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| **Cloudflare D1 limitations at scale** | High | Medium | Plan migration to external database early |
| **3D library deprecation or breaking changes** | Low | High | Abstract 3D layer; maintain upgrade path |
| **AI API provider outage** | Medium | Medium | Graceful degradation; fallback to manual |
| **Media storage costs spike** | Medium | Medium | Storage limits; compression; monitoring |
| **Security breach** | Low | Very High | Security-first architecture; penetration testing |
| **GDPR/CCPA compliance failure** | Low | High | Legal review; privacy by design |
| **Webhook reliability issues** | Medium | High | Retry logic; monitoring; dead letter queues |

### 64.4 Market Risks

| Risk | Probability | Impact | Mitigation |
|---|---|---|---|
| **Digital gifting market doesn't grow as expected** | Low | Medium | Focus on business use cases (more predictable) |
| **AI commoditizes the experience** | Medium | Medium | Differentiate on 3D, interactivity, and business automation |
| **Large platform (Meta, Google) enters space** | Low | Very High | Build moat through SEO, content, and network effects |
| **E-commerce slowdown reduces business demand** | Low | Medium | Diversify to personal use cases |

---

## §65 Edge Cases

### 65.1 Experience Edge Cases

| Edge Case | Behavior |
|---|---|
| **Expired experience** | Show branded expiration page: "This experience has expired. Create your own at MemorableDay." |
| **Deleted experience** | Show branded 404 page: "This experience is no longer available." |
| **Deleted account** | Show branded 404 page (same as deleted experience) |
| **Private experience accessed without password** | Show password entry form |
| **One-time view already viewed** | Show: "This experience has already been opened." |
| **Experience not yet published (scheduled)** | Show: "This experience isn't available yet. Check back soon." |
| **Experience with no scenes** | Should not be publishable; builder validates before publish |
| **Experience with broken media** | Show placeholder for broken media; log error |
| **Experience with very long text** | Truncate with "read more" or scroll within scene |
| **Experience with 100+ scenes** | Enforce scene limits per plan; builder prevents exceeding limit |

### 65.2 Media Edge Cases

| Edge Case | Behavior |
|---|---|
| **Failed photo upload** | Show error message; allow retry; do not lose other progress |
| **Huge file upload (> limit)** | Reject before upload completes; show clear size limit message |
| **Unsupported file type** | Reject with clear message listing supported types |
| **Corrupted file** | Reject with error message; log for monitoring |
| **HEIC photo (iPhone)** | Convert to JPEG/WebP on upload |
| **Video too long** | Reject with duration limit message |
| **Audio too long** | Reject with duration limit message |
| **Image with EXIF location data** | Strip EXIF data on upload (privacy) |
| **Duplicate file upload** | Allow (user may want the same photo in multiple scenes) |

### 65.3 3D Edge Cases

| Edge Case | Behavior |
|---|---|
| **WebGL not supported** | Automatically show 2D fallback |
| **Low GPU performance** | Automatically reduce 3D quality |
| **3D asset fails to load** | Show 2D fallback; log error |
| **3D animation stutters** | Reduce quality; log performance data |
| **Very slow connection** | Show static image; load 3D progressively |
| **Reduced motion preference** | Show static 3D image or 2D illustration |
| **3D asset deprecated** | Show replacement asset or 2D fallback |

### 65.4 AI Edge Cases

| Edge Case | Behavior |
|---|---|
| **AI generation fails** | Show error; allow retry; do not lose other progress |
| **AI generates inappropriate content** | Filter through safety layer; show error if filtered |
| **AI credits exhausted** | Show upgrade prompt; allow manual content creation |
| **AI takes too long (> 10s)** | Show timeout error; allow retry |
| **User provides minimal context** | AI generates generic but appropriate content; prompts for more context |
| **User provides contradictory context** | AI uses best judgment; shows what it assumed |
| **AI generates duplicate options** | Regenerate; log for model improvement |

### 65.5 Automation Edge Cases

| Edge Case | Behavior |
|---|---|
| **Duplicate trigger event** | Deduplication window prevents duplicate sends |
| **Trigger with missing customer data** | Use fallback values; log missing data |
| **Trigger with invalid email** | Skip send; log error; alert business |
| **Trigger with invalid phone** | Skip SMS; attempt email; log error |
| **Customer opted out** | Skip send; log opt-out |
| **Business disconnects store mid-automation** | Pause automation; alert business |
| **Experience deleted while automation active** | Pause automation; alert business |
| **Automation sends to wrong customer** | Log; alert; provide correction mechanism |
| **High volume trigger (flash sale)** | Queue and process; rate limit to prevent spam |
| **Automation loop (trigger creates trigger)** | Detect and break loop; alert business |

### 65.6 Payment Edge Cases

| Edge Case | Behavior |
|---|---|
| **Failed payment** | Grace period (3 days); dunning emails; restrict access after grace period |
| **Subscription cancelled mid-period** | Maintain access until period end; downgrade at period end |
| **Downgrade with data over new limit** | Maintain data; restrict access to over-limit data; prompt to delete |
| **Upgrade during trial** | Apply upgrade immediately; adjust billing |
| **Refund requested** | Evaluate per policy; process via Lemon Squeezy |
| **Duplicate payment** | Detect and refund duplicate; log |
| **Webhook not received** | Retry mechanism; manual reconciliation if needed |
| **Lemon Squeezy outage** | Maintain current entitlements; queue webhook processing |

### 65.7 Sharing Edge Cases

| Edge Case | Behavior |
|---|---|
| **Experience URL shared on social media** | Open Graph metadata generates preview |
| **Experience URL in SMS** | URL is short enough to not be truncated |
| **Experience URL in email** | URL is not broken by email clients |
| **QR code scanned from screen** | QR code is high-contrast and scannable |
| **Experience shared by recipient** | Sharing is allowed unless creator disabled it |
| **Experience link guessed** | IDs are non-sequential and non-guessable |
| **Experience link scraped** | Rate limiting prevents bulk scraping |

### 65.8 Scheduling Edge Cases

| Edge Case | Behavior |
|---|---|
| **Scheduled experience in wrong time zone** | Creator can preview in recipient's time zone; warning if ambiguous |
| **Daylight saving time transition** | System accounts for DST; scheduled time is in local time |
| **Scheduled experience deleted before publish** | Experience is not published; creator is not notified (they deleted it) |
| **Scheduled experience edited after scheduling** | Changes apply to the scheduled version |
| **Scheduling system failure** | Alert; retry; notify creator of delay |
| **Recipient opens experience before scheduled time** | Show "not yet available" message |

### 65.9 High Traffic Edge Cases

| Edge Case | Behavior |
|---|---|
| **Viral experience (100K+ views in 24h)** | Cloudflare CDN handles; auto-scale Workers |
| **Business sends to 1M customers at once** | Queue and rate-limit sends; prevent spam |
| **DDoS attack on experience URL** | Cloudflare DDoS protection activates |
| **Sudden traffic spike** | Cloudflare handles; Workers auto-scale |

### 65.10 Device and Browser Edge Cases

| Edge Case | Behavior |
|---|---|
| **Very old browser (IE11)** | Show upgrade browser message |
| **Browser with JavaScript disabled** | Show "JavaScript required" message |
| **Browser with cookies disabled** | Authentication may fail; show instructions |
| **Very small screen (< 320px)** | Experience still functional; may be cramped |
| **Very large screen (4K)** | Experience scales appropriately |
| **Screen reader** | Full accessibility support |
| **Keyboard-only navigation** | Full keyboard support |
| **High-contrast mode** | Experience respects system high-contrast |

---

## §66 Dependencies

### 66.1 External Service Dependencies

| Service | Purpose | Risk Level | Mitigation |
|---|---|---|---|
| **Cloudflare** | Infrastructure, CDN, DNS, storage | High | No easy alternative; monitor status; have contingency plan |
| **Lemon Squeezy** | Billing and subscriptions | High | Maintain billing abstraction layer; evaluate alternatives |
| **AI API provider** | AI features | Medium | Graceful degradation; multiple provider support |
| **Email provider (Postmark/Resend)** | Transactional email | Medium | Multiple provider support; fallback |
| **SMS provider (Twilio)** | SMS delivery | Medium | Multiple provider support; fallback |
| **Shopify** | E-commerce integration | Medium | Shopify App Store policies; maintain compliance |

### 66.2 Internal Dependencies

| Dependency | Blocks | Notes |
|---|---|---|
| **3D asset library** | Experience builder, templates | Must have core library at launch |
| **Template library** | Onboarding, SEO pages | Must have 50+ templates at launch |
| **AI integration** | AI features | Must be functional at launch |
| **Shopify integration** | Business automation | Required for business launch |
| **Email delivery** | Automation, notifications | Required at launch |
| **Analytics system** | Business dashboard | Required for business launch |
| **Billing system** | Paid plans | Required at launch |

### 66.3 Regulatory Dependencies

| Dependency | Impact | Action Required |
|---|---|---|
| **GDPR compliance** | EU users | Legal review; privacy policy; DPA |
| **CCPA compliance** | California users | Legal review; opt-out mechanism |
| **CAN-SPAM compliance** | Email delivery | Unsubscribe mechanism; sender identification |
| **TCPA compliance** | SMS delivery | Opt-in required; opt-out mechanism |
| **COPPA compliance** | Under-13 users | Age verification; legal review |
| **Music licensing** | Music library | License all tracks before launch |
| **Shopify Partner Agreement** | Shopify App Store | Compliance required |

### 66.4 Team Dependencies

| Dependency | Impact | Notes |
|---|---|---|
| **3D designer** | 3D asset quality | Required before launch |
| **UX/UI designer** | Product quality | Required before launch |
| **AI/ML expertise** | AI feature quality | Required before launch |
| **Legal counsel** | Compliance | Required before launch |
| **Customer support** | User satisfaction | Required at launch |

---

*Next: [Product Roadmap →](29-product-roadmap.md)*
