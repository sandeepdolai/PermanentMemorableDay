# 07 — 3D System

**Section:** §19 3D System  
**PRD Index:** [← Experience Architecture](06-experience-architecture-builder-scenes.md) | [Next: Interaction System →](08-interaction-system.md)

---

## §19 3D System

### 19.1 Why 3D Is Core, Not Optional

The 3D experience system is MemorableDay's primary visual differentiator. It is what makes a recipient say "how did they make this?" It is what makes a business experience feel premium rather than transactional. It is what makes MemorableDay a new category rather than another digital card.

3D is not a feature to be added later. It is the foundation of the product's emotional impact.

**The 3D promise:**
- Beautiful enough to create genuine surprise
- Fast enough to work on mobile networks
- Simple enough for non-technical creators to use
- Flexible enough to serve both personal and business use cases

### 19.2 3D Technical Philosophy

The 3D system must be designed with these constraints in mind:

| Constraint | Requirement |
|---|---|
| **Mobile-first** | 3D must work on mid-range Android and iPhone devices |
| **No app required** | 3D must run in the browser (WebGL/WebGPU) |
| **Performance budget** | 3D scenes must not exceed defined performance budgets |
| **Graceful degradation** | Non-3D devices must receive a beautiful 2D fallback |
| **Creator simplicity** | Creators select and configure 3D objects; they do not model them |
| **Asset management** | 3D assets are managed by MemorableDay; creators choose from a library |

The PRD does not prescribe a specific 3D library or rendering engine. The engineering team selects the appropriate technology. The requirements define what the system must achieve.

### 19.3 3D Asset Library

The 3D asset library is the collection of pre-built 3D objects available to creators. It must be:

- **Curated**: Every asset is beautiful and appropriate for the platform
- **Expandable**: New assets can be added without platform changes
- **Categorized**: Assets are organized by category and occasion
- **Optimized**: Every asset meets the performance budget
- **Accessible**: Every asset has a 2D fallback

#### 19.3.1 Core Asset Categories

**Nature & Romance:**

| Asset | Animations | Occasions |
|---|---|---|
| Single Rose | Bloom, grow, appear from particles, appear from envelope | Romance, apology, anniversary |
| Rose Bouquet | Bloom together, appear one by one | Romance, birthday, anniversary |
| Flower (generic) | Bloom, grow, sway | Any occasion |
| Wildflower Meadow | Grow, sway in wind | Nature, celebration |
| Cherry Blossom | Petals fall, tree blooms | Spring, romance, Japanese aesthetic |
| Sunflower | Grow, turn toward light | Friendship, happiness |
| Lotus | Open, float on water | Calm, spiritual, wellness |

**Celebration:**

| Asset | Animations | Occasions |
|---|---|---|
| Gift Box | Appear, shake, open, reveal contents | Birthday, any celebration |
| Balloon Cluster | Float up, pop, drift | Birthday, celebration |
| Confetti Burst | Explode, fall, swirl | Celebration, graduation |
| Fireworks | Launch, explode, sparkle | New Year, celebration |
| Birthday Cake | Appear, candles light, blow out | Birthday |
| Champagne Bottle | Appear, cork pop, bubbles | New Year, celebration, wedding |
| Trophy | Appear, shine, rotate | Achievement, graduation |
| Graduation Cap | Appear, toss, fall | Graduation |
| Star Burst | Explode, sparkle, orbit | Achievement, celebration |

**Communication & Delivery:**

| Asset | Animations | Occasions |
|---|---|---|
| Envelope | Appear, open, letter emerges | Any message, love letter |
| Letter / Scroll | Unroll, text appears | Personal message |
| Package / Box | Appear, travel, arrive, open | Shipping, delivery, business |
| Delivery Truck | Drive in, stop, deliver | Shipping experience |
| Airplane | Fly in, land | Travel, long-distance |
| Hot Air Balloon | Float up, drift | Adventure, romance |

**Love & Emotion:**

| Asset | Animations | Occasions |
|---|---|---|
| Heart | Beat, float up, burst | Love, romance, Valentine's |
| Heart Burst | Explode into many hearts | Love, celebration |
| Infinity Symbol | Draw, glow, rotate | Anniversary, eternal love |
| Lock & Key | Key turns, lock opens | Trust, commitment |
| Two Hands | Reach toward each other, hold | Connection, support |

**Seasonal & Holiday:**

| Asset | Animations | Occasions |
|---|---|---|
| Snowflakes | Fall, swirl, accumulate | Winter, Christmas |
| Christmas Tree | Appear, lights turn on, star appears | Christmas |
| Pumpkin | Appear, glow | Halloween, Thanksgiving |
| Autumn Leaves | Fall, swirl | Autumn, Thanksgiving |
| Spring Flowers | Bloom, grow | Spring, Easter |
| Fireworks (4th of July) | Red/white/blue | Independence Day |

**Business & Professional:**

| Asset | Animations | Occasions |
|---|---|---|
| Package (branded) | Appear with brand logo, open | Post-purchase, delivery |
| Shopping Bag | Appear, items emerge | Purchase thank-you |
| Checkmark | Draw, glow | Order confirmed, success |
| Clock | Tick, hands move | Delay, timing |
| Shield | Appear, glow | Trust, security, apology |
| Handshake | Reach, shake | Partnership, appreciation |
| Star Rating | Stars appear one by one | Review request |

**Luxury & Premium:**

| Asset | Animations | Occasions |
|---|---|---|
| Diamond Ring | Appear, sparkle, rotate | Engagement, anniversary |
| Diamond | Rotate, refract light | Luxury, premium |
| Gold Coins | Fall, stack | Reward, achievement |
| Luxury Box | Appear, open with ribbon | Premium gift |
| Crown | Descend, settle | VIP, achievement |
| Champagne Flutes | Clink, bubbles rise | Celebration, wedding |

**Abstract & Ambient:**

| Asset | Animations | Occasions |
|---|---|---|
| Particle Cloud | Form shape, disperse | Any (ambient) |
| Light Rays | Appear, sweep | Any (ambient) |
| Stars / Galaxy | Appear, twinkle, rotate | Night, romance, wonder |
| Geometric Shapes | Rotate, morph | Modern, minimal |
| Waves | Flow, ripple | Calm, ocean, relaxation |
| Aurora | Shimmer, shift colors | Wonder, beauty |

### 19.4 3D Object Configuration

Creators configure 3D objects through a simple interface. They do not need to understand 3D development.

**Configuration options per object:**

| Option | Description | Complexity |
|---|---|---|
| **Object selection** | Choose from library | Simple |
| **Animation selection** | Choose from available animations for this object | Simple |
| **Color / Theme** | Primary color, secondary color, or preset theme | Simple |
| **Size** | Small, Medium, Large, Full-screen | Simple |
| **Position** | Center, Left, Right, Top, Bottom | Simple |
| **Animation speed** | Slow, Normal, Fast | Simple |
| **Loop** | Whether animation loops | Simple |
| **Interaction trigger** | What triggers the animation (auto, tap, scroll) | Simple |
| **Camera angle** | Front, Side, Top, Dramatic (preset angles) | Medium |
| **Lighting preset** | Warm, Cool, Dramatic, Soft, Natural | Medium |
| **Background integration** | How the 3D object interacts with the scene background | Medium |
| **Particle effects** | Add particles (petals, sparkles, snow) around the object | Medium |
| **Sound effect** | Attach a sound to the animation | Simple |

**Advanced options (Pro/Business plans):**

| Option | Description |
|---|---|
| **Custom color** | Full color picker instead of presets |
| **Animation timing** | Fine-tune animation duration and easing |
| **Multi-object scenes** | Multiple 3D objects in one scene |
| **Camera movement** | Animated camera pan/zoom during scene |
| **Environment** | Full 3D environment (room, garden, space, etc.) |

### 19.5 3D Performance Requirements

Performance is a product requirement, not an engineering preference.

| Metric | Target | Maximum |
|---|---|---|
| `PRD-3D-001` | 3D scene initial load time (4G mobile) | < 3 seconds | 5 seconds |
| `PRD-3D-002` | 3D animation frame rate (mobile) | 60 fps | 30 fps minimum |
| `PRD-3D-003` | 3D asset file size (per object) | < 500KB | 1MB |
| `PRD-3D-004` | Total 3D assets loaded per scene | < 2MB | 3MB |
| `PRD-3D-005` | GPU memory usage (mobile) | < 100MB | 150MB |
| `PRD-3D-006` | Time to first meaningful 3D frame | < 2 seconds | 3 seconds |

**Performance strategies:**
- Assets are pre-optimized and compressed (Draco compression for geometry, KTX2 for textures)
- Assets are served from Cloudflare CDN with aggressive caching
- Progressive loading: low-resolution placeholder loads first, high-resolution loads in background
- Level-of-detail (LOD): simpler geometry on lower-end devices
- Asset preloading: next scene's assets load while current scene is displayed

### 19.6 3D Fallback System

When 3D is not supported or performance is insufficient:

| Fallback Level | Trigger | Fallback |
|---|---|---|
| **Level 1** | WebGL not supported | 2D animated illustration |
| **Level 2** | Low GPU performance detected | Simplified 3D (fewer polygons, no particles) |
| **Level 3** | Very slow connection | Static image with CSS animation |
| **Level 4** | Reduced motion preference | Static image, no animation |

**Requirements:**
- `PRD-3D-007`: Fallback detection must be automatic and transparent to the recipient
- `PRD-3D-008`: Every 3D asset must have a corresponding 2D illustration fallback
- `PRD-3D-009`: Fallback quality must be high — it should still feel premium
- `PRD-3D-010`: Creators must be able to preview the fallback experience in the builder

### 19.7 3D Asset Management

**For MemorableDay (internal):**
- 3D assets are created by MemorableDay's design team or licensed from 3D asset providers
- Assets are reviewed for quality, performance, and appropriateness before publishing
- Assets are versioned; updates do not break existing experiences
- New assets are added on a regular cadence (monthly or quarterly)

**For creators:**
- Creators select from the library; they cannot upload custom 3D assets (initially)
- Premium asset packs are available for purchase (Advanced/Premium feature)
- Business plans may have access to branded 3D assets (e.g., branded package with logo)

**Future: Custom 3D Assets (Enterprise):**
- Enterprise customers can request custom 3D assets
- Custom assets are reviewed and optimized by MemorableDay before use
- Custom assets are private to the enterprise account

### 19.8 3D Scene Compositions

Beyond individual objects, the 3D system supports full scene compositions:

**Scene composition examples:**

| Composition | Description | Occasion |
|---|---|---|
| **Rose Garden** | Multiple roses in a garden environment | Romance, anniversary |
| **Starry Night** | Stars, moon, ambient particles | Romance, wonder |
| **Celebration Room** | Balloons, confetti, streamers | Birthday, graduation |
| **Winter Wonderland** | Snow, snowflakes, pine trees | Christmas, winter |
| **Ocean Sunset** | Waves, sun, horizon | Relaxation, romance |
| **Space Journey** | Stars, planets, nebula | Wonder, achievement |
| **Autumn Forest** | Falling leaves, trees | Thanksgiving, autumn |
| **Delivery Journey** | Package traveling through scenes | Shipping experience |

### 19.9 Interactive 3D Objects

Some 3D objects support direct recipient interaction:

| Object | Interaction | Result |
|---|---|---|
| **Gift Box** | Tap to open | Box opens, contents revealed |
| **Envelope** | Tap to open | Envelope opens, letter emerges |
| **Rose** | Tap to bloom | Rose blooms in response to tap |
| **Balloon** | Tap to pop | Balloon pops with confetti |
| **Cake** | Tap to blow out candles | Candles blow out |
| **Lock** | Tap to unlock | Lock opens, content revealed |
| **Scratch Card** | Scratch to reveal | Reward or message revealed |
| **Star** | Tap to collect | Stars collected, counter increases |

**Requirements:**
- `PRD-3D-011`: Interactive 3D objects must have clear visual affordances (glow, pulse, "tap me" indicator)
- `PRD-3D-012`: Interaction feedback must be immediate (< 100ms response to tap)
- `PRD-3D-013`: Interactive objects must work with both touch and mouse/keyboard
- `PRD-3D-014`: Interaction state must be tracked for analytics

### 19.10 3D Asset Roadmap

| Phase | Assets Added |
|---|---|
| **Launch** | Core library: rose, gift box, envelope, package, heart, confetti, balloons, birthday cake, stars |
| **Phase 2** | Seasonal: Christmas tree, snowflakes, autumn leaves, fireworks |
| **Phase 3** | Luxury: diamond ring, champagne, crown, luxury box |
| **Phase 4** | Business: branded package, delivery truck, shopping bag |
| **Phase 5** | Compositions: full scene environments |
| **Ongoing** | New assets based on user demand and occasions |

### 19.11 3D Asset Licensing and IP

- All 3D assets used on the platform must be either created by MemorableDay or properly licensed
- Assets must not infringe on third-party IP (no branded characters, logos, or trademarked designs)
- User-uploaded 3D assets (future Enterprise feature) must be reviewed for IP compliance
- The platform must have a clear DMCA process for 3D asset takedowns

---

*Next: [Interaction System →](08-interaction-system.md)*
