# 06 — Experience Architecture, Experience Builder & Scene System

**Sections:** §16 Experience Architecture · §17 Experience Builder · §18 Scene System  
**PRD Index:** [← User Experience](05-personal-business-recipient-experience.md) | [Next: 3D System →](07-3d-system.md)

---

## §16 Experience Architecture

### 16.1 The Experience Data Model

An **Experience** is the top-level unit of content on MemorableDay. It is a complete interactive digital moment that a creator builds and a recipient views.

**Experience hierarchy:**

```
Experience
├── Metadata (title, occasion, creator, recipient, status, settings)
├── Brand Settings (logo, colors, fonts — for business experiences)
├── Scene 1
│   ├── Block 1 (3D Object)
│   ├── Block 2 (Text)
│   └── Block 3 (Button)
├── Scene 2
│   ├── Block 1 (Image Gallery)
│   └── Block 2 (Text)
├── Scene N
│   └── ...
├── Reward (optional)
└── Attribution (MemorableDay or white-label)
```

### 16.2 Experience States

| State | Description |
|---|---|
| **Draft** | Being created; not accessible to recipients |
| **Scheduled** | Complete; will be published at a future time |
| **Published** | Live and accessible via URL |
| **Expired** | Past expiration date; shows graceful expiration message |
| **Archived** | Manually archived by creator; not accessible |
| **Deleted** | Soft-deleted; data retained for 30 days then purged |

### 16.3 Experience Settings

Each experience has configurable settings:

| Setting | Options | Default |
|---|---|---|
| **Visibility** | Public (anyone with link), Private (password), Unlisted | Unlisted |
| **Password** | Optional password string | None |
| **Expiration** | Date/time or never | Never |
| **Scheduled publish** | Date/time or immediate | Immediate |
| **One-time view** | Yes/No (experience expires after first view) | No |
| **Allow sharing** | Yes/No (recipient can share the link) | Yes |
| **Notify on open** | Yes/No (creator gets notification when recipient opens) | Yes |
| **Analytics** | Enabled/Disabled | Enabled |
| **Attribution** | Show/Hide MemorableDay branding | Show (unless white-label plan) |

### 16.4 Experience Types

| Type | Description | Primary Audience |
|---|---|---|
| **Personal** | Created by an individual for another person | Personal users |
| **Business Manual** | Created by a business for a specific customer or campaign | Business users |
| **Business Automated** | Triggered automatically by a business event | Business users |
| **Template Preview** | Public preview of a template (SEO/marketing) | Visitors |

### 16.5 Experience URL Architecture

```
memorableday.online/e/[experience-id]     — Standard experience URL
memorableday.online/e/[experience-id]/preview  — Creator preview (authenticated)
gift.brand.com/e/[experience-id]          — Custom domain experience (business)
```

**Requirements:**
- `PRD-CORE-055`: Experience IDs must be at least 8 characters, URL-safe, and non-sequential
- `PRD-CORE-056`: Experience IDs must be generated using a cryptographically secure random function
- `PRD-CORE-057`: Custom domain experiences must serve from the business's domain with correct SSL

---

## §17 Experience Builder

### 17.1 Builder Philosophy

The Experience Builder is the core creation tool. It must serve two very different users:

1. **The personal user** who wants to create something beautiful in 5 minutes
2. **The business user** who wants to create a branded, data-driven experience with precision

The builder must accommodate both without making either feel like they're using the wrong tool.

**Builder design principles:**
- **Progressive disclosure**: Simple by default, powerful when needed
- **What-you-see-is-what-they-get**: The builder preview matches the recipient experience exactly
- **Mobile-aware**: The builder shows how the experience looks on mobile at all times
- **Undo/redo**: All actions are reversible
- **Auto-save**: Work is never lost

### 17.2 Builder Layout

**Recommended layout (desktop):**

```
┌─────────────────────────────────────────────────────────────┐
│  [← Back]  Experience Title  [Preview] [Share] [Publish]   │
├──────────┬──────────────────────────────┬───────────────────┤
│          │                              │                   │
│  Scene   │      Canvas / Preview        │   Block Editor    │
│  Panel   │                              │   (right panel)   │
│  (left)  │   [Mobile] [Desktop] toggle  │                   │
│          │                              │   Selected block  │
│  Scene 1 │                              │   properties      │
│  Scene 2 │                              │                   │
│  Scene 3 │                              │   [Add Block]     │
│  + Add   │                              │                   │
│          │                              │                   │
└──────────┴──────────────────────────────┴───────────────────┘
```

**Mobile builder layout:**
- Simplified: scene list collapses to a bottom strip
- Block editor appears as a bottom sheet
- Canvas takes full screen

### 17.3 Builder Requirements

**Core builder requirements:**

| ID | Requirement |
|---|---|
| `PRD-UX-001` | Builder must auto-save every 30 seconds and on every significant action |
| `PRD-UX-002` | Builder must support unlimited undo/redo within a session |
| `PRD-UX-003` | Builder must show a real-time preview that matches the recipient experience |
| `PRD-UX-004` | Builder must allow toggling between mobile and desktop preview |
| `PRD-UX-005` | Builder must support drag-and-drop scene reordering |
| `PRD-UX-006` | Builder must support drag-and-drop block reordering within a scene |
| `PRD-UX-007` | Builder must show a "Publish" button that is always accessible |
| `PRD-UX-008` | Builder must warn before leaving with unsaved changes |
| `PRD-UX-009` | Builder must support keyboard shortcuts for common actions |
| `PRD-UX-010` | Builder must be accessible (keyboard navigation, screen reader labels) |

**AI integration in builder:**

| ID | Requirement |
|---|---|
| `PRD-UX-011` | AI assistant must be accessible from within the builder at any time |
| `PRD-UX-012` | AI can suggest: next scene, message text, tone adjustment, visual theme |
| `PRD-UX-013` | AI suggestions must be one-click to apply, with ability to edit before applying |
| `PRD-UX-014` | AI must not overwrite existing content without explicit confirmation |

### 17.4 Block Types

Blocks are the content elements within a scene. The following block types must be supported:

**Content Blocks:**

| Block Type | Description | Priority |
|---|---|---|
| **Text** | Heading, body, caption with rich formatting | Core |
| **Image** | Single image with optional caption | Core |
| **Image Gallery** | Multiple images in a swipeable gallery | Core |
| **Video** | Uploaded video or YouTube/Vimeo embed | Core |
| **Audio / Voice Message** | Uploaded audio with player | Important |
| **Music** | Background music for the scene | Important |
| **GIF** | Animated GIF | Important |
| **3D Object** | Interactive 3D object (see 3D System) | Core |
| **Countdown Timer** | Countdown to a date/time | Important |
| **Map** | Location map (Google Maps embed) | Advanced |

**Interactive Blocks:**

| Block Type | Description | Priority |
|---|---|---|
| **Button / CTA** | Clickable button with URL or action | Core |
| **Reward Block** | Coupon, gift card, or reward reveal | Core |
| **Scratch Reveal** | Scratch-to-reveal interaction | Advanced |
| **Quiz / Question** | Single question with reveal | Advanced |
| **Password Reveal** | Content revealed after entering a word/phrase | Advanced |
| **Choice** | Recipient chooses a path (branching) | Advanced |

**Business Blocks:**

| Block Type | Description | Priority |
|---|---|---|
| **Order Information** | Dynamic order data (number, items, total) | Core (Business) |
| **Tracking Button** | Link to order tracking | Core (Business) |
| **Product Showcase** | Product image, name, description | Important (Business) |
| **Review Request** | Link to review platform | Important (Business) |
| **Referral Block** | Referral link with sharing | Important (Business) |
| **Social Links** | Brand social media links | Important (Business) |
| **Support Button** | Link to customer support | Core (Business) |
| **QR Code** | Generated QR code | Advanced |

### 17.5 Block Editor Properties

Each block type has configurable properties. Common properties:

| Property | Applies To | Options |
|---|---|---|
| **Alignment** | Text, Image | Left, Center, Right |
| **Size** | Image, Video, 3D | Small, Medium, Large, Full |
| **Animation** | All blocks | Fade in, Slide up, Zoom in, None |
| **Animation timing** | All blocks | Immediate, Delayed (0.5s, 1s, 2s) |
| **Background** | Scene level | Color, Gradient, Image, Video, None |
| **Padding** | All blocks | None, Small, Medium, Large |
| **Border radius** | Image, Video | None, Small, Medium, Large, Circle |

### 17.6 Scene Transitions

Between scenes, the experience transitions. Supported transitions:

| Transition | Description | Priority |
|---|---|---|
| **Fade** | Smooth fade between scenes | Core |
| **Slide** | Slide left/right/up/down | Core |
| **Zoom** | Zoom in/out | Important |
| **Flip** | 3D flip effect | Advanced |
| **Dissolve** | Particle dissolve | Advanced |
| **None** | Instant cut | Core |

### 17.7 Template Application

When a creator selects a template:

1. Template scenes and blocks are loaded into the builder
2. Placeholder content is highlighted for replacement
3. AI can pre-fill placeholders based on creator's context
4. Creator can modify any element
5. Template structure is a starting point, not a constraint

**Requirements:**
- `PRD-UX-015`: Templates must be fully editable — no locked elements (except brand-locked elements for business plans)
- `PRD-UX-016`: Applying a template to an existing experience must warn about overwriting
- `PRD-UX-017`: Creators must be able to save their customized experience as a new template

---

## §18 Scene System

### 18.1 What Is a Scene?

A **Scene** is a single step or moment within an Experience. Scenes are the fundamental unit of narrative structure in MemorableDay.

Think of scenes like:
- Slides in a presentation (but interactive and animated)
- Pages in a book (but with 3D and sound)
- Moments in a film (but the recipient controls the pace)

### 18.2 Scene Structure

```
Scene
├── Background (color, gradient, image, video, or 3D environment)
├── Blocks (ordered list of content elements)
├── Transition (how this scene enters)
├── Exit Transition (how this scene leaves)
├── Advance Trigger (tap, auto-advance after X seconds, or interaction-required)
├── Audio (background music or sound effect for this scene)
└── Metadata (scene name for builder, hidden from recipient)
```

### 18.3 Scene Types

| Scene Type | Description | Example |
|---|---|---|
| **Intro** | Opening scene; sets the tone | "Someone special sent you something" |
| **3D Reveal** | A 3D object appears and animates | Rose blooms, gift box opens |
| **Message** | Personal message text | "Happy Birthday, Sarah!" |
| **Photo Gallery** | Collection of photos | Shared memories |
| **Video** | Full-screen video | Personal video message |
| **Reward Reveal** | Reward is revealed | "Here's a gift for you: 20% off" |
| **CTA** | Call to action | "Shop Now," "Track Your Order" |
| **Outro** | Closing scene | "With love, Alex" |
| **Custom** | Any combination of blocks | Flexible |

### 18.4 Scene Navigation

Recipients navigate between scenes through:

| Navigation Method | Description | When Used |
|---|---|---|
| **Tap/Click** | Tap anywhere to advance | Default for most scenes |
| **Swipe** | Swipe left to advance (mobile) | Alternative to tap |
| **Auto-advance** | Scene advances after X seconds | Intro scenes, ambient scenes |
| **Interaction-required** | Must interact with a block to advance | 3D reveals, scratch reveals |
| **Button** | Explicit "Next" button | Long content scenes |

### 18.5 Scene Limits

| Plan | Max Scenes per Experience |
|---|---|
| Free | 5 |
| Personal | 10 |
| Pro | 20 |
| Business | 20 |
| Growth | 30 |
| Agency/Enterprise | Unlimited |

### 18.6 Scene Templates

Pre-built scene templates for common moments:

**Personal scene templates:**
- Rose bloom reveal
- Gift box opening
- Photo memory wall
- Heartfelt message
- Countdown to occasion
- Voice message reveal
- Confetti celebration
- Starry night message

**Business scene templates:**
- Order confirmation
- Package shipping journey
- Delivery celebration
- Delay apology
- VIP welcome
- Loyalty milestone
- Win-back offer
- Review request

### 18.7 Scene Background System

Each scene can have a distinct background:

| Background Type | Description | Performance Impact |
|---|---|---|
| **Solid color** | Single color | None |
| **Gradient** | Two or more colors | Minimal |
| **Image** | Static image (optimized) | Low |
| **Video loop** | Short looping video | Medium |
| **3D Environment** | Full 3D scene background | High (managed) |
| **Particle system** | Animated particles (snow, confetti, stars) | Medium |
| **Animated gradient** | Slowly shifting gradient | Minimal |

**Requirements:**
- `PRD-CORE-058`: Background images must be automatically optimized and served via CDN
- `PRD-CORE-059`: Video backgrounds must be muted by default and loop seamlessly
- `PRD-CORE-060`: 3D environment backgrounds must respect the performance budget (see Performance section)
- `PRD-CORE-061`: All backgrounds must have a reduced-motion fallback

### 18.8 Scene Audio System

Each scene can have associated audio:

| Audio Type | Description |
|---|---|
| **Background music** | Ambient music for the scene (fades between scenes) |
| **Sound effect** | Triggered by scene entry or interaction |
| **Voice message** | Recorded voice from creator |
| **Narration** | AI-generated narration (future) |

**Requirements:**
- `PRD-CORE-062`: Audio must be opt-in for recipients (not auto-play without interaction)
- `PRD-CORE-063`: Audio controls must be visible and accessible
- `PRD-CORE-064`: Music must fade smoothly between scenes
- `PRD-CORE-065`: Voice messages must be playable independently of scene progression

### 18.9 Branching Experiences (Advanced)

Advanced experiences can support branching — where the recipient's choice determines the next scene.

**Example:**
```
Scene 3: "Which memory do you want to relive?"
  → Option A: "Our first date" → Scene 4A
  → Option B: "Our vacation" → Scene 4B
Both paths → Scene 5: "I love you"
```

**Requirements:**
- `PRD-CORE-066`: Branching must be supported in the builder with a visual flow diagram
- `PRD-CORE-067`: Branching is an Advanced feature (Pro plan and above)
- `PRD-CORE-068`: Analytics must track which paths recipients choose

---

*Next: [3D System →](07-3d-system.md)*
