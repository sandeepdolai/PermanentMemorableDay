# 26 — Competitive Analysis

**Section:** §61 Competitive Analysis  
**PRD Index:** [← Customer Support & Admin](25-customer-support-admin-panel.md) | [Next: Business Model & KPIs →](27-business-model-kpis.md)

---

## §61 Competitive Analysis

### 61.1 Competitive Landscape Overview

MemorableDay operates at the intersection of several markets. No single competitor occupies the same space. The competitive threat comes from adjacent categories, not direct competitors.

**Competitive categories:**

| Category | Key Players | Threat Level |
|---|---|---|
| Digital greeting cards | Hallmark, Moonpig, Greenvelope, Paperless Post | Medium (different category) |
| Interactive invitations | Evite, Paperless Post, Zola | Low (different use case) |
| Video messages | Loom, Cameo, Bonjoro | Low (different format) |
| Post-purchase platforms | Wonderment, AfterShip, Malomo | High (business overlap) |
| Customer experience | Medallia, Qualtrics, Zendesk | Low (enterprise, different) |
| Digital gifting | Giftly, Prezzee, Tremendous | Medium (personal overlap) |
| Interactive content | Ceros, Ion Interactive | Low (B2B, different) |
| Email marketing | Klaviyo, Mailchimp | Low (different category) |
| Shopify apps | Many | Medium (business overlap) |

### 61.2 Direct Competitor Analysis

#### 61.2.1 Hallmark (Digital Cards)

**Product:** Digital greeting cards with some animation  
**Audience:** General consumers  
**Pricing:** $3–$5 per card; subscription available  
**Positioning:** "The greeting card company"

| Dimension | Hallmark | MemorableDay |
|---|---|---|
| **3D experiences** | None | Core feature |
| **AI personalization** | None | Core feature |
| **Business automation** | None | Core feature |
| **Interactivity** | Minimal (some animations) | Full interactive system |
| **Personalization** | Name insertion | Deep AI personalization |
| **Business use cases** | None | Full business platform |
| **SEO** | Strong (brand authority) | Growing |
| **Brand recognition** | Very high | New |

**MemorableDay advantage:** Everything except brand recognition. Hallmark is a legacy brand in a declining category. MemorableDay is a new category.

**Hallmark weakness:** No 3D, no AI, no business features, no interactivity. Feels dated.

---

#### 61.2.2 Moonpig (Digital + Physical Cards)

**Product:** Digital and physical greeting cards  
**Audience:** UK-focused; some U.S. presence  
**Pricing:** $5–$15 per card  
**Positioning:** "Personalized cards and gifts"

| Dimension | Moonpig | MemorableDay |
|---|---|---|
| **3D experiences** | None | Core feature |
| **AI personalization** | Basic (text generation) | Deep AI |
| **Business automation** | None | Core feature |
| **Interactivity** | None | Full interactive system |
| **Physical delivery** | Yes | No (digital only) |
| **U.S. market** | Limited | Primary focus |

**MemorableDay advantage:** Digital-first, interactive, AI-powered, business features.

**Moonpig advantage:** Physical card delivery (different use case).

---

#### 61.2.3 Greenvelope (Digital Invitations)

**Product:** Premium digital invitations and cards  
**Audience:** Consumers, event planners  
**Pricing:** $2–$4 per card; subscription available  
**Positioning:** "Beautiful digital invitations"

| Dimension | Greenvelope | MemorableDay |
|---|---|---|
| **3D experiences** | None | Core feature |
| **AI personalization** | None | Core feature |
| **Business automation** | None | Core feature |
| **Interactivity** | Minimal | Full interactive system |
| **Design quality** | High | High |
| **Occasion focus** | Events/invitations | All occasions |

**MemorableDay advantage:** 3D, AI, business features, broader occasion coverage.

**Greenvelope advantage:** Established in the invitation space; RSVP management.

---

#### 61.2.4 Wonderment (Post-Purchase Experience)

**Product:** Post-purchase tracking and experience platform for e-commerce  
**Audience:** Shopify merchants, DTC brands  
**Pricing:** $99–$499/month  
**Positioning:** "Post-purchase experience platform"

| Dimension | Wonderment | MemorableDay |
|---|---|---|
| **3D experiences** | None | Core feature |
| **AI personalization** | Limited | Core feature |
| **Personal use cases** | None | Full personal platform |
| **Tracking integration** | Deep (carrier tracking) | Basic |
| **Shopify integration** | Deep | Strong |
| **Pricing** | $99–$499/month | $49–$249/month |
| **Visual experience** | Email-based | Interactive 3D experience |

**MemorableDay advantage:** 3D experiences, AI, personal use cases, lower pricing, more emotional impact.

**Wonderment advantage:** Deep carrier tracking integration; established in the Shopify ecosystem.

**Strategic note:** Wonderment is the closest business competitor. MemorableDay should differentiate on emotional impact and visual experience, not on tracking features.

---

#### 61.2.5 AfterShip (Shipping Tracking)

**Product:** Shipment tracking and post-purchase platform  
**Audience:** E-commerce businesses  
**Pricing:** $11–$239/month  
**Positioning:** "Post-purchase experience platform"

| Dimension | AfterShip | MemorableDay |
|---|---|---|
| **3D experiences** | None | Core feature |
| **AI personalization** | Limited | Core feature |
| **Personal use cases** | None | Full personal platform |
| **Tracking integration** | Very deep (900+ carriers) | Basic |
| **Visual experience** | Tracking page | Interactive 3D experience |
| **Pricing** | $11–$239/month | $49–$249/month |

**MemorableDay advantage:** Emotional impact, 3D, AI, personal use cases.

**AfterShip advantage:** Carrier tracking depth; established brand; lower entry price.

**Strategic note:** AfterShip is a tracking tool; MemorableDay is an experience tool. They can coexist — AfterShip provides the tracking data; MemorableDay creates the experience around it.

---

#### 61.2.6 Bonjoro (Video Messages for Business)

**Product:** Personalized video messages for customer onboarding and retention  
**Audience:** SaaS companies, e-commerce businesses  
**Pricing:** $25–$75/month  
**Positioning:** "Personal video messages at scale"

| Dimension | Bonjoro | MemorableDay |
|---|---|---|
| **3D experiences** | None | Core feature |
| **AI personalization** | None | Core feature |
| **Personal use cases** | None | Full personal platform |
| **Video messages** | Core feature | Supported (not core) |
| **Automation** | Limited | Full automation engine |
| **Visual experience** | Video | Interactive 3D + video |

**MemorableDay advantage:** 3D, AI, automation, personal use cases, more visual impact.

**Bonjoro advantage:** Personal video from a real person (human touch); established in SaaS onboarding.

---

#### 61.2.7 Cameo (Celebrity Video Messages)

**Product:** Personalized video messages from celebrities  
**Audience:** Consumers  
**Pricing:** $10–$10,000+ per video  
**Positioning:** "Personalized videos from your favorite stars"

| Dimension | Cameo | MemorableDay |
|---|---|---|
| **3D experiences** | None | Core feature |
| **AI personalization** | None | Core feature |
| **Business use cases** | None | Full business platform |
| **Celebrity content** | Core feature | None |
| **Price** | $10–$10,000+ | $0–$19/month |
| **Accessibility** | Limited (celebrity availability) | Unlimited |

**MemorableDay advantage:** Accessible, affordable, AI-powered, 3D, business features.

**Cameo advantage:** Celebrity factor (unique, cannot be replicated).

**Strategic note:** Cameo serves a different need (celebrity access). MemorableDay serves the need for personal, meaningful experiences — which Cameo cannot provide.

---

### 61.3 Adjacent Competitive Threats

#### AI Writing Tools (ChatGPT, Claude)

**Threat:** Users use AI writing tools to generate messages, then send via text/email.

**MemorableDay response:** AI writing is a commodity. The experience (3D, interactivity, scheduling, sharing) is the differentiator. MemorableDay's AI is purpose-built for moments, not general writing.

#### Canva (Design Tool)

**Threat:** Canva has digital card templates and some animation features.

**MemorableDay response:** Canva is a design tool; MemorableDay is an experience platform. Canva requires design skills; MemorableDay requires none. Canva has no 3D, no AI for moments, no business automation.

#### Instagram / TikTok (Social Media)

**Threat:** People share moments on social media instead of creating private experiences.

**MemorableDay response:** Social media is public and performative. MemorableDay is private and intimate. Different emotional need.

### 61.4 Competitive Positioning Summary

| Competitor | Primary Threat | MemorableDay Advantage |
|---|---|---|
| Hallmark/Moonpig | Brand recognition | 3D, AI, interactivity, business features |
| Wonderment | Shopify ecosystem | Emotional impact, 3D, AI, personal use cases |
| AfterShip | Tracking depth | Experience quality, 3D, AI |
| Bonjoro | Human video touch | Scale, 3D, AI, automation |
| Canva | Design tool familiarity | No design skills needed, 3D, AI, moments focus |
| ChatGPT | AI writing | Complete experience (not just text) |

### 61.5 Differentiation Strategy

MemorableDay's sustainable differentiation comes from:

1. **3D experience system** — no competitor has this; high barrier to replicate
2. **AI moment intelligence** — purpose-built for emotional moments, not general AI
3. **Business automation** — complete automation engine for e-commerce
4. **Personal + business in one platform** — unique combination
5. **SEO authority** — becoming the destination for digital gifting searches
6. **Viral loop** — recipient-to-creator conversion built into the product

The combination of these five factors creates a moat that is difficult for any single competitor to replicate.

---

*Next: [Business Model & KPIs →](27-business-model-kpis.md)*
