# 27 — Business Model & KPIs

**Sections:** §62 Business Model · §63 KPIs  
**PRD Index:** [← Competitive Analysis](26-competitive-analysis.md) | [Next: Risks & Edge Cases →](28-risks-edge-cases-dependencies.md)

---

## §62 Business Model

### 62.1 Revenue Streams

MemorableDay has four revenue streams, ordered by priority:

| Stream | Description | Priority | Timeline |
|---|---|---|---|
| **Subscription (Business)** | Monthly/annual plans for business users | Primary | Launch |
| **Subscription (Personal)** | Monthly/annual plans for personal users | Primary | Launch |
| **AI Credit Top-ups** | Additional AI credits beyond plan limits | Secondary | Launch |
| **Premium Asset Packs** | Additional 3D assets and templates | Secondary | Phase 2 |
| **White Label Licensing** | Agency white-label fees | Secondary | Phase 2 |
| **Enterprise Contracts** | Custom enterprise agreements | Tertiary | Phase 3 |

### 62.2 Unit Economics

**Personal users:**

| Metric | Estimate |
|---|---|
| Average Revenue Per User (ARPU) | $10/month |
| Customer Acquisition Cost (CAC) | $15–$30 (SEO/viral) |
| Churn rate | 5–8%/month |
| Average LTV | $125–$200 |
| LTV:CAC ratio | 4:1–8:1 |

**Business users:**

| Metric | Estimate |
|---|---|
| Average Revenue Per User (ARPU) | $79/month |
| Customer Acquisition Cost (CAC) | $100–$300 (content/SEO) |
| Churn rate | 2–4%/month |
| Average LTV | $2,000–$4,000 |
| LTV:CAC ratio | 7:1–20:1 |

**Key insight:** Business users have 8x higher ARPU and 2x lower churn than personal users. Business acquisition should be prioritized as the platform scales.

### 62.3 Revenue Projections

**Conservative scenario (Year 1–3):**

| Year | Personal Users | Business Users | MRR | ARR |
|---|---|---|---|---|
| Year 1 | 2,000 | 200 | $35,800 | $430K |
| Year 2 | 15,000 | 1,500 | $268,500 | $3.2M |
| Year 3 | 50,000 | 5,000 | $895,000 | $10.7M |

**Optimistic scenario (Year 1–3):**

| Year | Personal Users | Business Users | MRR | ARR |
|---|---|---|---|---|
| Year 1 | 5,000 | 500 | $89,500 | $1.1M |
| Year 2 | 40,000 | 4,000 | $716,000 | $8.6M |
| Year 3 | 150,000 | 15,000 | $2.7M | $32M |

### 62.4 Cost Structure

**Fixed costs (monthly):**

| Cost | Early Stage | Growth Stage |
|---|---|---|
| Infrastructure (Cloudflare) | $0–$100 | $500–$5,000 |
| AI API costs | $100–$500 | $2,000–$20,000 |
| Email/SMS sending | $50–$200 | $500–$5,000 |
| Lemon Squeezy fees | 5% + $0.50/transaction | Same |
| Team (founder only initially) | $0 | Growing |
| Tools and software | $200–$500 | $1,000–$3,000 |

**Variable costs (per user):**

| Cost | Personal User | Business User |
|---|---|---|
| Infrastructure | ~$0.11/month | ~$0.50/month |
| AI credits | ~$0.05–$0.50/month | ~$0.50–$5/month |
| Email/SMS | ~$0.01/month | ~$0.10–$1/month |
| Support | ~$0.50/month | ~$2/month |

### 62.5 Gross Margin

**Target gross margin:** 70–80%

This is achievable because:
- Infrastructure costs are low (Cloudflare)
- AI costs are managed via credit system
- No physical goods
- No sales team initially (PLG + SEO)

**Gross margin by plan:**

| Plan | Revenue | Variable Cost | Gross Margin |
|---|---|---|---|
| Personal ($9) | $9 | $1.50 | 83% |
| Pro ($19) | $19 | $3 | 84% |
| Business ($49) | $49 | $8 | 84% |
| Growth ($99) | $99 | $15 | 85% |
| Agency ($249) | $249 | $35 | 86% |

### 62.6 Path to Profitability

**Break-even analysis:**

Assuming $5,000/month in fixed costs (founder + tools + infrastructure):

- Break-even at: ~500 paying users at $10 ARPU average
- Or: ~100 business users at $49/month average

This is achievable within 6–12 months of launch with focused execution.

### 62.7 Business Model Risks

| Risk | Mitigation |
|---|---|
| High AI costs | Credit system; model selection; caching |
| High video storage costs | Storage limits; video compression; plan pricing |
| Low conversion from free | Optimize conversion triggers; improve onboarding |
| High churn | Improve product value; better onboarding; retention features |
| Shopify App Store dependency | Diversify acquisition channels |
| Lemon Squeezy dependency | Maintain clean billing abstraction layer |

---

## §63 KPIs

### 63.1 North Star Metric

**Memorable Moments Delivered (MMD)**

> The total number of Experiences opened by a recipient in a given period (weekly/monthly).

**Why this is the right North Star:**
- Captures both creator activity and recipient engagement
- Reflects genuine product value (created but unopened = no value)
- Correlates with viral growth
- Works for both personal and business use cases
- Not gameable by low-quality activity

**MMD target:**
- Month 3: 10,000 MMD/month
- Month 6: 50,000 MMD/month
- Month 12: 200,000 MMD/month
- Year 3: 5,000,000 MMD/month

### 63.2 Acquisition KPIs

| KPI | Description | Target (Month 12) |
|---|---|---|
| **Organic traffic** | Monthly visitors from search | 50,000+ |
| **Signup rate** | Visitors who sign up | 3–5% |
| **New signups/month** | Total new accounts | 1,500+ |
| **Personal signups** | New personal accounts | 1,200+ |
| **Business signups** | New business accounts | 300+ |
| **Shopify App installs** | Monthly installs | 100+ |
| **Referral signups** | Signups from referral | 15%+ of total |
| **Recipient-to-creator conversion** | Recipients who sign up | 5–10% |

### 63.3 Activation KPIs

| KPI | Description | Target |
|---|---|---|
| **First experience created** | % of signups who create an experience | > 60% |
| **First experience published** | % of signups who publish an experience | > 40% |
| **First experience shared** | % of signups who share an experience | > 30% |
| **Business: first automation live** | % of business signups with active automation | > 50% |
| **Business: store connected** | % of business signups with connected store | > 40% |
| **Time to first experience** | Median time from signup to first published experience | < 10 minutes |

### 63.4 Engagement KPIs

| KPI | Description | Target |
|---|---|---|
| **Monthly Active Creators** | Creators who publish at least 1 experience/month | > 30% of paid users |
| **Experiences per creator/month** | Average experiences created per active creator | > 2 |
| **Recipient open rate** | % of sent experiences opened | > 60% |
| **Recipient completion rate** | % of opened experiences completed | > 50% |
| **Recipient interaction rate** | % of opened experiences with at least 1 interaction | > 70% |
| **Recipient-to-creator rate** | % of recipients who create their own experience | > 5% |
| **Business automation open rate** | Average open rate for business automations | > 50% |

### 63.5 Revenue KPIs

| KPI | Description | Target (Month 12) |
|---|---|---|
| **MRR** | Monthly Recurring Revenue | $100K+ |
| **ARR** | Annual Recurring Revenue | $1.2M+ |
| **ARPU (Personal)** | Average Revenue Per Personal User | $10/month |
| **ARPU (Business)** | Average Revenue Per Business User | $79/month |
| **Free-to-paid conversion** | % of free users who upgrade | > 5% |
| **Trial-to-paid conversion** | % of trial users who convert | > 30% |
| **Monthly churn (Personal)** | % of personal subscribers who cancel | < 6% |
| **Monthly churn (Business)** | % of business subscribers who cancel | < 3% |
| **Net Revenue Retention** | Revenue retained + expansion from existing customers | > 110% |
| **LTV:CAC ratio** | Lifetime value vs. acquisition cost | > 5:1 |

### 63.6 Business-Specific KPIs

| KPI | Description | Target |
|---|---|---|
| **Active stores** | Business accounts with connected store | Growing |
| **Active automations** | Total active automations | Growing |
| **Experiences sent/month** | Total business experiences sent | Growing |
| **Automation open rate** | Average open rate across all automations | > 50% |
| **Reward redemption rate** | % of rewards claimed | > 30% |
| **Revenue attributed** | Revenue from reward redemptions | Tracked |
| **Integration health** | % of integrations with no errors | > 99% |

### 63.7 SEO KPIs

| KPI | Description | Target (Month 12) |
|---|---|---|
| **Organic sessions/month** | Monthly organic search traffic | 50,000+ |
| **Keyword rankings** | Priority keywords in top 10 | 20+ |
| **Domain Authority** | Moz/Ahrefs domain authority | 30+ |
| **Backlinks** | Total referring domains | 200+ |
| **Core Web Vitals** | LCP, INP, CLS scores | All "Good" |
| **Indexed pages** | Total pages indexed by Google | 500+ |

### 63.8 Support KPIs

| KPI | Description | Target |
|---|---|---|
| **CSAT** | Customer satisfaction score | > 90% |
| **First response time** | Average first response time | < 24h (Standard) |
| **Resolution time** | Average resolution time | < 72h (Standard) |
| **Help center deflection** | % of issues resolved via help center | > 60% |
| **Ticket volume/user** | Support tickets per 100 users | < 5/month |

### 63.9 KPI Dashboard

**Requirements:**
- `PRD-CORE-240`: Internal KPI dashboard must be updated daily
- `PRD-CORE-241`: KPI dashboard must be accessible to all team members
- `PRD-CORE-242`: KPI alerts must be configured for significant deviations (> 20% from target)
- `PRD-CORE-243`: Weekly KPI review must be a standing team meeting

---

*Next: [Risks, Edge Cases & Dependencies →](28-risks-edge-cases-dependencies.md)*
