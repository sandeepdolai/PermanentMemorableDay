# 17 — Payments, Lemon Squeezy Integration & Subscription Entitlements

**Sections:** §36 Payments · §37 Lemon Squeezy Integration Requirements · §38 Subscription Entitlements  
**PRD Index:** [← API](16-api.md) | [Next: Pricing Strategy →](18-pricing-strategy-free-plan.md)

---

## §36 Payments

### 36.1 Payment Philosophy

Billing must be transparent, reliable, and frictionless. Users should never be surprised by a charge, confused about their plan, or unable to manage their subscription.

**Payment principles:**
- Transparent pricing (no hidden fees)
- Easy upgrade/downgrade
- Reliable billing (no failed payment surprises)
- Clear invoices and receipts
- Easy cancellation (no dark patterns)

### 36.2 Payment Provider

**Primary payment provider:** Lemon Squeezy

Lemon Squeezy is selected because:
- It is a Merchant of Record (MoR) — handles sales tax, VAT, and compliance globally
- It supports subscription billing with all required lifecycle events
- It provides a hosted checkout that is PCI-compliant
- It has a developer-friendly API and webhook system
- It is cost-effective for early-stage SaaS

**What Lemon Squeezy handles:**
- Payment processing (credit card, PayPal, etc.)
- Subscription management (create, upgrade, downgrade, cancel)
- Tax calculation and remittance (as Merchant of Record)
- Invoice generation
- Failed payment handling and dunning
- Refund processing
- Customer billing portal

**What MemorableDay handles:**
- Entitlement enforcement (what features each plan can access)
- Usage tracking (AI credits, storage, experiences)
- Subscription status synchronization (via webhooks)
- Plan display and upgrade prompts in the UI

### 36.3 Supported Payment Methods

Lemon Squeezy supports:
- Credit/debit cards (Visa, Mastercard, American Express, Discover)
- PayPal
- Apple Pay (where supported)
- Google Pay (where supported)

**Requirements:**
- `PRD-PAY-001`: All payment processing must go through Lemon Squeezy
- `PRD-PAY-002`: MemorableDay must never store raw payment card data
- `PRD-PAY-003`: Payment forms must be hosted by Lemon Squeezy (not embedded in MemorableDay)

### 36.4 Subscription Types

| Type | Description |
|---|---|
| **Monthly** | Billed monthly, cancel anytime |
| **Annual** | Billed annually, typically 15–20% discount |
| **Free** | No payment required, limited features |

### 36.5 Billing Currency

**Primary currency:** USD (United States Dollar)

All prices are displayed and charged in USD. Lemon Squeezy handles currency conversion for international customers.

---

## §37 Lemon Squeezy Integration Requirements

### 37.1 Lemon Squeezy Concepts

Understanding Lemon Squeezy's data model is essential for correct integration:

| Concept | Description |
|---|---|
| **Store** | The MemorableDay Lemon Squeezy store |
| **Product** | A plan (e.g., "Personal Plan") |
| **Variant** | A billing period for a product (e.g., "Personal Monthly", "Personal Annual") |
| **Customer** | A Lemon Squeezy customer record (linked to MemorableDay user) |
| **Subscription** | An active subscription to a variant |
| **Order** | A completed purchase (subscription or one-time) |
| **Checkout** | The hosted checkout page for a variant |
| **Webhook** | Event notification from Lemon Squeezy to MemorableDay |

### 37.2 Product and Variant Structure

Each MemorableDay plan is a Lemon Squeezy Product with two Variants (monthly and annual):

| Plan | Product | Variants |
|---|---|---|
| Personal | Personal Plan | Personal Monthly, Personal Annual |
| Pro | Pro Plan | Pro Monthly, Pro Annual |
| Business | Business Plan | Business Monthly, Business Annual |
| Growth | Growth Plan | Growth Monthly, Growth Annual |
| Agency | Agency Plan | Agency Monthly, Agency Annual |
| Enterprise | Enterprise Plan | Enterprise Annual (custom) |

**Requirements:**
- `PRD-PAY-004`: Each plan must have a corresponding Lemon Squeezy Product
- `PRD-PAY-005`: Each billing period must be a separate Lemon Squeezy Variant
- `PRD-PAY-006`: Variant IDs must be stored in MemorableDay's configuration for entitlement mapping

### 37.3 Checkout Flow

**Checkout flow:**

1. User selects a plan in MemorableDay
2. MemorableDay generates a Lemon Squeezy checkout URL for the selected variant
3. User is redirected to Lemon Squeezy's hosted checkout
4. User completes payment on Lemon Squeezy
5. Lemon Squeezy sends `order_created` and `subscription_created` webhooks to MemorableDay
6. MemorableDay updates the user's subscription status and entitlements
7. User is redirected back to MemorableDay with a success message

**Requirements:**
- `PRD-PAY-007`: Checkout URL must include the user's email (pre-filled) and a custom redirect URL
- `PRD-PAY-008`: Checkout must include a `custom_data` parameter with the MemorableDay user ID for webhook correlation
- `PRD-PAY-009`: Checkout redirect must return the user to the correct page after payment
- `PRD-PAY-010`: Checkout must support discount codes (for promotions)

### 37.4 Webhook Events

MemorableDay must handle the following Lemon Squeezy webhook events:

| Event | Description | MemorableDay Action |
|---|---|---|
| `order_created` | New order placed | Record order, update subscription status |
| `subscription_created` | New subscription created | Activate plan, grant entitlements |
| `subscription_updated` | Subscription changed (upgrade/downgrade) | Update plan, adjust entitlements |
| `subscription_cancelled` | Subscription cancelled | Schedule plan downgrade at period end |
| `subscription_resumed` | Cancelled subscription resumed | Reactivate plan |
| `subscription_expired` | Subscription expired (after cancellation) | Downgrade to free plan |
| `subscription_paused` | Subscription paused | Restrict access (maintain data) |
| `subscription_unpaused` | Subscription unpaused | Restore access |
| `subscription_payment_success` | Renewal payment succeeded | Update renewal date |
| `subscription_payment_failed` | Renewal payment failed | Send dunning email, restrict access after grace period |
| `subscription_payment_recovered` | Failed payment recovered | Restore full access |
| `subscription_payment_refunded` | Payment refunded | Adjust subscription status |

**Requirements:**
- `PRD-PAY-011`: All Lemon Squeezy webhooks must be verified using the webhook signature
- `PRD-PAY-012`: Webhook processing must be idempotent (duplicate events must not cause duplicate actions)
- `PRD-PAY-013`: Webhook processing must be asynchronous (respond 200 immediately, process in background)
- `PRD-PAY-014`: Failed webhook processing must be retried with exponential backoff
- `PRD-PAY-015`: Webhook events must be logged for debugging and audit

### 37.5 Subscription Lifecycle Management

**Upgrade flow:**
1. User selects a higher plan
2. MemorableDay redirects to Lemon Squeezy checkout for the new variant
3. Lemon Squeezy handles proration (charges the difference)
4. `subscription_updated` webhook received
5. MemorableDay immediately grants new entitlements

**Downgrade flow:**
1. User selects a lower plan
2. MemorableDay redirects to Lemon Squeezy checkout or customer portal
3. Lemon Squeezy schedules the downgrade at the end of the current period
4. `subscription_updated` webhook received (with `ends_at` date)
5. MemorableDay maintains current entitlements until `ends_at`
6. At `ends_at`: `subscription_expired` or `subscription_updated` webhook received
7. MemorableDay applies new (lower) entitlements

**Cancellation flow:**
1. User cancels via Lemon Squeezy customer portal or MemorableDay UI
2. `subscription_cancelled` webhook received
3. MemorableDay maintains current entitlements until end of billing period
4. At period end: `subscription_expired` webhook received
5. MemorableDay downgrades to free plan

**Failed payment flow:**
1. Renewal payment fails
2. `subscription_payment_failed` webhook received
3. MemorableDay sends dunning email to user
4. Lemon Squeezy retries payment (per its dunning schedule)
5. If payment recovered: `subscription_payment_recovered` webhook → restore access
6. If payment not recovered after grace period: `subscription_expired` webhook → downgrade to free

**Requirements:**
- `PRD-PAY-016`: Users must not lose access immediately on payment failure (grace period of at least 3 days)
- `PRD-PAY-017`: Users must receive email notifications for: payment failure, upcoming renewal, cancellation confirmation
- `PRD-PAY-018`: Users must be able to update payment method via Lemon Squeezy customer portal

### 37.6 Customer Portal

Lemon Squeezy provides a hosted customer portal where users can:
- View subscription details
- Update payment method
- Download invoices
- Cancel subscription
- Resume cancelled subscription

**Requirements:**
- `PRD-PAY-019`: Customer portal link must be accessible from the MemorableDay billing settings
- `PRD-PAY-020`: Customer portal must be accessible without re-entering payment details

### 37.7 Free Trials

**Requirements:**
- `PRD-PAY-021`: Free trials must be supported via Lemon Squeezy's trial period feature
- `PRD-PAY-022`: Trial period must be configurable per plan (recommended: 14 days for Business plans)
- `PRD-PAY-023`: Trial users must have full access to plan features during trial
- `PRD-PAY-024`: Trial expiration must trigger `subscription_expired` webhook → downgrade to free
- `PRD-PAY-025`: Credit card must be required at trial start (Lemon Squeezy standard behavior)

### 37.8 Promotional Pricing and Coupons

**Requirements:**
- `PRD-PAY-026`: Promotional discount codes must be created in Lemon Squeezy
- `PRD-PAY-027`: Discount codes must be applicable at checkout
- `PRD-PAY-028`: Discount codes must support: percentage off, fixed amount off, one-time or recurring
- `PRD-PAY-029`: Discount codes must have configurable expiration and usage limits

### 37.9 One-Time Purchases

In addition to subscriptions, MemorableDay may offer one-time purchases:
- AI credit top-ups
- Premium 3D asset packs
- Additional storage

**Requirements:**
- `PRD-PAY-030`: One-time purchases must use Lemon Squeezy's one-time product type
- `PRD-PAY-031`: One-time purchase fulfillment must be triggered by `order_created` webhook
- `PRD-PAY-032`: One-time purchases must be reflected in the user's account immediately after payment

---

## §38 Subscription Entitlements

### 38.1 Entitlement Architecture

The entitlement system enforces what each plan can access. It must be:
- **Accurate** — entitlements must match the user's current plan
- **Real-time** — entitlement changes must take effect immediately
- **Enforceable** — the system must prevent access to features beyond the plan
- **Graceful** — users must be informed when they hit a limit, not just blocked

**Entitlement data model:**

```
User
└── Workspace
    └── Subscription
        ├── Plan (Free / Personal / Pro / Business / Growth / Agency / Enterprise)
        ├── Status (active / trialing / cancelled / expired / paused)
        ├── Period end date
        └── Entitlements
            ├── Feature flags (what features are enabled)
            └── Usage limits (how much of each resource is allowed)
```

### 38.2 Feature Entitlements

| Feature | Free | Personal | Pro | Business | Growth | Agency | Enterprise |
|---|---|---|---|---|---|---|---|
| Experience creation | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| 3D experiences | Limited | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| AI message generator | 5/mo | 30/mo | 100/mo | 200/mo | 500/mo | 1000/mo | Custom |
| AI experience creator | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Template library | 10 | 50+ | All | All | All | All | All |
| Custom templates | — | — | ✓ | ✓ | ✓ | ✓ | ✓ |
| Photo upload | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Video upload | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Voice messages | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Custom music upload | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Scheduling | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Password protection | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Analytics (basic) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Analytics (advanced) | — | — | ✓ | ✓ | ✓ | ✓ | ✓ |
| Rewards | — | Personal | Basic | All | All | All | All |
| Business automations | — | — | — | ✓ | ✓ | ✓ | ✓ |
| E-commerce integrations | — | — | — | ✓ | ✓ | ✓ | ✓ |
| Team members | 1 | 1 | 1 | 3 | 10 | 25 | Unlimited |
| Multiple brands | — | — | — | — | — | ✓ | ✓ |
| White label | — | — | — | — | ✓ | ✓ | ✓ |
| Custom domain | — | — | — | — | ✓ | ✓ | ✓ |
| API access | — | — | — | ✓ | ✓ | ✓ | ✓ |
| Priority support | — | — | — | — | ✓ | ✓ | ✓ |
| Dedicated support | — | — | — | — | — | — | ✓ |
| SSO | — | — | — | — | — | — | ✓ |
| SLA | — | — | — | — | — | — | ✓ |

### 38.3 Usage Limits

| Limit | Free | Personal | Pro | Business | Growth | Agency | Enterprise |
|---|---|---|---|---|---|---|---|
| Published experiences | 3 | 20 | Unlimited | Unlimited | Unlimited | Unlimited | Unlimited |
| Experience views/month | 500 | 5,000 | 25,000 | 50,000 | 200,000 | 500,000 | Custom |
| AI credits/month | 5 | 30 | 100 | 200 | 500 | 1,000 | Custom |
| Storage (total) | 100MB | 1.5GB | 7GB | 15GB | 35GB | 70GB | Custom |
| Video storage | 0 | 500MB | 2GB | 5GB | 10GB | 20GB | Custom |
| Active automations | 0 | 0 | 0 | 3 | 10 | 25/brand | Unlimited |
| Connected stores | 0 | 0 | 0 | 1 | 3 | 10 | Unlimited |
| Custom domains | 0 | 0 | 0 | 0 | 1 | 5 | Unlimited |
| Team members | 1 | 1 | 1 | 3 | 10 | 25 | Unlimited |
| Brands | 1 | 1 | 1 | 1 | 1 | 10 | Unlimited |
| API requests/minute | 0 | 0 | 0 | 60 | 120 | 300 | Custom |

### 38.4 Entitlement Enforcement

**Requirements:**
- `PRD-PAY-033`: Entitlement checks must be performed server-side (not just client-side)
- `PRD-PAY-034`: When a user hits a limit, they must see a clear message explaining the limit and how to upgrade
- `PRD-PAY-035`: Upgrade prompts must be contextual (shown at the point of limit, not just in billing settings)
- `PRD-PAY-036`: Entitlement changes must take effect within 60 seconds of subscription update
- `PRD-PAY-037`: Downgrade must not delete data — data is preserved but access is restricted

### 38.5 Usage Tracking

**Requirements:**
- `PRD-PAY-038`: Usage must be tracked in real-time (or near real-time)
- `PRD-PAY-039`: Usage must be visible to users in their account settings
- `PRD-PAY-040`: Usage warnings must be sent when user reaches 80% of any limit
- `PRD-PAY-041`: Usage resets on the billing cycle date (not calendar month)
- `PRD-PAY-042`: Usage history must be retained for at least 12 months

### 38.6 Overage Handling

| Resource | Overage Behavior |
|---|---|
| Published experiences | Block creation; prompt to upgrade or archive |
| Experience views | Throttle (slow down) or block; prompt to upgrade |
| AI credits | Block AI features; prompt to purchase more credits |
| Storage | Block uploads; prompt to upgrade or delete files |
| Automations | Block new automations; prompt to upgrade |

**Requirements:**
- `PRD-PAY-043`: Overage must never result in data loss
- `PRD-PAY-044`: Overage must never result in a surprise charge (no automatic overage billing)
- `PRD-PAY-045`: Overage handling must be graceful — users are informed, not just blocked

---

*Next: [Pricing Strategy & Free Plan →](18-pricing-strategy-free-plan.md)*
