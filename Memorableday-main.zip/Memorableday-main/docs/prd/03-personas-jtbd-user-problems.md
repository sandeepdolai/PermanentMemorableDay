# 03 — Personas, Jobs to Be Done & User Problems

**Sections:** §7 Personas · §8 Jobs to Be Done · §9 User Problems  
**PRD Index:** [← Problem & Market](02-problem-opportunity-market.md) | [Next: Positioning →](04-positioning-value-principles.md)

---

## §7 Personas

### 7.1 Personal User Personas

---

#### Persona P1: The Romantic Partner — "Alex"

**Demographics:** 28–38, urban/suburban, college-educated, $60K–$120K income  
**Relationship:** In a committed relationship (dating, engaged, or married)  
**Tech comfort:** High — uses apps daily, comfortable with digital payments  

**Context:**
Alex wants to do something genuinely special for their partner's birthday, anniversary, or Valentine's Day. They've sent texts, bought physical gifts, and tried digital cards — but nothing feels quite right. They want something that shows real effort and creativity without requiring design skills.

**Goals:**
- Make their partner feel genuinely surprised and loved
- Create something that feels personal, not generic
- Do it quickly (often last-minute)
- Share it easily via text or WhatsApp

**Frustrations:**
- Digital cards feel cheap and impersonal
- Physical gifts take planning and shipping time
- They're not creative/artistic enough to make something from scratch
- AI tools give generic results that don't feel personal

**MemorableDay Use Cases:**
- Anniversary experience with shared photos, a 3D rose bloom, and a personal message
- Valentine's Day surprise with a 3D gift box reveal
- "I'm sorry" experience after an argument
- Long-distance "I miss you" experience

**Willingness to Pay:** $8–$15/month or $5–$15 per experience  
**Acquisition:** Google search ("digital anniversary gift"), social media, word of mouth

---

#### Persona P2: The Long-Distance Connector — "Maya"

**Demographics:** 22–32, college student or young professional, $30K–$70K income  
**Relationship:** Long-distance relationship or close friendship across distance  
**Tech comfort:** Very high — digital native  

**Context:**
Maya is in a long-distance relationship or has close friends/family in different cities or countries. Physical gifts are expensive and slow. Video calls are great but don't create lasting moments. She wants to create something that the other person can open, interact with, and keep.

**Goals:**
- Bridge the physical distance with something that feels tangible
- Create a moment that the recipient can experience at a specific time (birthday midnight)
- Make the other person feel like she's "there" even when she's not

**Frustrations:**
- Nothing digital feels as meaningful as being there in person
- Existing digital gifts (Amazon gift cards, etc.) feel transactional
- She can't afford to send physical gifts frequently

**MemorableDay Use Cases:**
- Scheduled birthday experience that arrives at midnight in the recipient's time zone
- "Thinking of you" experience with voice message and photos
- Holiday experience with a 3D scene and personal message
- "Congratulations on your new job" experience

**Willingness to Pay:** $5–$10/month  
**Acquisition:** Social media, TikTok, Instagram, word of mouth from recipients

---

#### Persona P3: The Occasion Celebrator — "David"

**Demographics:** 35–55, parent, suburban, $80K–$150K income  
**Relationship:** Parent, sibling, extended family  
**Tech comfort:** Medium — uses smartphone, comfortable with apps but not power user  

**Context:**
David wants to celebrate his daughter's graduation, his parents' anniversary, or his son's first job. He's not particularly tech-savvy but wants to do something more meaningful than a text. He's willing to pay for something that looks impressive.

**Goals:**
- Create something that looks professionally made
- Include family photos and a heartfelt message
- Share it easily with the whole family
- Not spend hours figuring out how to use the tool

**Frustrations:**
- Complex design tools are overwhelming
- Generic templates don't feel personal enough
- He doesn't know how to make something look good

**MemorableDay Use Cases:**
- Graduation experience with photos, a 3D confetti scene, and a family message
- Parents' anniversary experience with a photo timeline and personal message
- "Welcome home" experience for a family member returning from abroad

**Willingness to Pay:** $10–$20 per experience or $8/month  
**Acquisition:** Google search, Facebook, word of mouth

---

#### Persona P4: The Apologizer — "Jordan"

**Demographics:** 25–45, any background  
**Context:** Needs to apologize sincerely — to a partner, friend, or family member  
**Tech comfort:** Medium-High  

**Context:**
Jordan has done something wrong and wants to apologize in a way that feels genuine, not just a text. They want something that shows they put real thought and effort into it.

**Goals:**
- Communicate genuine remorse
- Show that they made an effort
- Create something the recipient will actually open and engage with

**Frustrations:**
- A text apology feels insufficient
- They don't know how to express themselves in writing
- They're afraid the apology will be ignored

**MemorableDay Use Cases:**
- Apology experience with a 3D rose, heartfelt AI-assisted message, and personal photos
- "I'm sorry" experience with a voice message

**Willingness to Pay:** $5–$15 per experience  
**Acquisition:** Google search ("how to apologize to girlfriend digitally"), social media

---

#### Persona P5: The Gift Shopper — "Sarah"

**Demographics:** 30–50, any background, moderate income  
**Context:** Needs a gift for someone but doesn't know what to get  
**Tech comfort:** Medium  

**Context:**
Sarah needs a birthday gift for a friend but doesn't know what to buy. She wants something that feels thoughtful but doesn't require knowing the person's exact preferences. A beautiful digital experience with a gift card or coupon attached could be perfect.

**Goals:**
- Give something that feels personal and thoughtful
- Not have to guess what the person wants
- Easy to send, easy to receive

**MemorableDay Use Cases:**
- Birthday experience with a digital gift card attached
- "Congratulations" experience with a reward

**Willingness to Pay:** $10–$30 per experience (including gift value)  
**Acquisition:** Google search, social media

---

### 7.2 Business User Personas

---

#### Persona B1: The Shopify Merchant — "Carlos"

**Demographics:** 30–45, e-commerce entrepreneur, $500K–$5M annual revenue  
**Business:** DTC brand on Shopify, 500–5,000 orders/month  
**Tech comfort:** High — uses multiple Shopify apps, comfortable with integrations  

**Context:**
Carlos runs a successful Shopify store selling premium products. He knows customer retention is cheaper than acquisition but his post-purchase experience is just automated emails. He's seen competitors differentiate on experience and wants to do the same.

**Goals:**
- Increase repeat purchase rate
- Reduce negative reviews from delayed orders
- Make his brand feel premium and memorable
- Automate customer appreciation without it feeling automated

**Frustrations:**
- His post-purchase emails look like every other brand's
- When orders are delayed, he has no good way to communicate
- He doesn't have a designer on staff
- Existing tools (Klaviyo, etc.) are powerful but don't create visual experiences

**MemorableDay Use Cases:**
- Automated post-purchase thank-you experience
- Shipping experience with 3D package animation
- Delay apology experience with coupon
- VIP milestone experience for 5th order customers

**Willingness to Pay:** $49–$149/month  
**Acquisition:** Shopify App Store, Google search, e-commerce communities

---

#### Persona B2: The DTC Brand Marketing Manager — "Priya"

**Demographics:** 28–40, marketing professional, works at a DTC brand with $5M–$50M revenue  
**Role:** Marketing Manager or Customer Experience Manager  
**Tech comfort:** Very high — uses Klaviyo, Attentive, Gorgias, etc.  

**Context:**
Priya manages customer communications for a growing DTC brand. She has a budget, a team, and sophisticated tools — but she's looking for something that creates genuine differentiation. She's measured on customer LTV, NPS, and repeat purchase rate.

**Goals:**
- Create experiences that measurably improve customer retention
- Differentiate the brand's post-purchase experience
- Integrate with existing tools (Klaviyo, Gorgias)
- Prove ROI to her CMO

**Frustrations:**
- Every brand's post-purchase emails look the same
- She can't justify the cost of custom development for every campaign
- Her team doesn't have 3D design skills
- She needs analytics to prove the value of experience investments

**MemorableDay Use Cases:**
- Branded post-purchase experience with product education
- VIP customer appreciation campaign
- Holiday customer experience campaign
- Win-back experience for lapsed customers

**Willingness to Pay:** $149–$499/month  
**Acquisition:** Content marketing, LinkedIn, industry events, direct sales

---

#### Persona B3: The Digital Agency — "The Agency"

**Demographics:** Agency with 5–50 employees, manages 10–100 e-commerce clients  
**Role:** Agency owner or account manager  
**Tech comfort:** Very high  

**Context:**
The agency manages customer experience for multiple e-commerce brands. They need a white-label platform they can offer as a service to clients, with the ability to manage multiple brands from one dashboard.

**Goals:**
- Offer a differentiated service to clients
- Manage multiple brands efficiently
- White-label the platform under their own brand
- Charge clients a premium for the service

**Frustrations:**
- No existing platform supports true multi-brand management for agencies
- White-label options are expensive or limited
- They need approval workflows for client sign-off

**MemorableDay Use Cases:**
- Agency workspace with multiple client brands
- White-label platform for client-facing experiences
- Shared template library across clients
- Client reporting and analytics

**Willingness to Pay:** $299–$999/month  
**Acquisition:** Direct outreach, agency communities, partnerships

---

#### Persona B4: The Small Business Owner — "Maria"

**Demographics:** 35–55, small business owner, $100K–$500K annual revenue  
**Business:** Local or online small business (boutique, salon, restaurant, etc.)  
**Tech comfort:** Medium  

**Context:**
Maria runs a small business and wants to send something special to her best customers for the holidays or their birthdays. She doesn't have a marketing team and needs something simple.

**Goals:**
- Appreciate loyal customers without a big budget
- Create something that feels personal
- Easy to use without technical knowledge

**MemorableDay Use Cases:**
- Holiday appreciation experience for top customers
- Birthday experience for loyal customers
- "Thank you for your 10th visit" experience

**Willingness to Pay:** $19–$49/month  
**Acquisition:** Google search, social media, word of mouth

---

## §8 Jobs to Be Done

### 8.1 Personal User JTBD

Using the JTBD framework: *"When [situation], I want to [motivation], so I can [outcome]."*

| # | Situation | Motivation | Outcome |
|---|---|---|---|
| JTBD-P-01 | When it's someone's birthday and I'm far away | I want to create something that feels like a real gift | So they feel genuinely celebrated, not just remembered |
| JTBD-P-02 | When I want to apologize sincerely | I want to express genuine remorse in a way that shows effort | So the other person knows I really mean it |
| JTBD-P-03 | When I want to surprise my partner | I want to create a moment of genuine surprise and delight | So they feel loved and special |
| JTBD-P-04 | When I'm not creative or artistic | I want AI to help me create something beautiful | So I can express myself without design skills |
| JTBD-P-05 | When I want to celebrate a milestone | I want to create something that captures the significance of the moment | So the memory is preserved and shared |
| JTBD-P-06 | When I'm in a long-distance relationship | I want to send something that feels tangible and interactive | So the distance feels smaller |
| JTBD-P-07 | When I need a last-minute gift | I want to create something meaningful quickly | So I don't miss the moment |
| JTBD-P-08 | When I want to include photos and memories | I want to weave them into an experience, not just a slideshow | So the recipient relives the memories |

### 8.2 Business User JTBD

| # | Situation | Motivation | Outcome |
|---|---|---|---|
| JTBD-B-01 | When a customer places their first order | I want to welcome them in a way that feels personal | So they feel like a valued customer, not a transaction |
| JTBD-B-02 | When an order is delayed | I want to communicate the delay in a way that preserves trust | So the customer doesn't leave a negative review or churn |
| JTBD-B-03 | When a customer reaches their 5th order | I want to recognize their loyalty in a meaningful way | So they feel appreciated and continue buying |
| JTBD-B-04 | When a customer hasn't bought in 90 days | I want to re-engage them with something compelling | So they return and make another purchase |
| JTBD-B-05 | When I want to differentiate my brand | I want to create post-purchase experiences no competitor offers | So customers remember and recommend my brand |
| JTBD-B-06 | When I manage multiple brands | I want a single platform to manage all client experiences | So I can scale my agency efficiently |
| JTBD-B-07 | When I need to prove ROI | I want analytics that show the impact of experiences on retention | So I can justify the investment to leadership |
| JTBD-B-08 | When I want to automate customer appreciation | I want it to feel personal, not automated | So customers feel genuinely valued |

### 8.3 Recipient JTBD

| # | Situation | Motivation | Outcome |
|---|---|---|---|
| JTBD-R-01 | When I receive a MemorableDay link | I want to experience something genuinely surprising | So I feel the sender's care and effort |
| JTBD-R-02 | When I see "Created with MemorableDay" | I want to create something similar for someone I care about | So I can make them feel the same way |
| JTBD-R-03 | When I receive a business experience | I want to feel like the brand actually cares about me | So I trust and continue buying from them |
| JTBD-R-04 | When I receive a reward in an experience | I want to redeem it easily | So the reward feels like a genuine gift, not a marketing trick |

---

## §9 User Problems

### 9.1 Personal User Problems (Ranked by Severity)

| # | Problem | Severity | Current Workaround | MemorableDay Solution |
|---|---|---|---|---|
| UP-P-01 | No way to create a genuinely impressive digital gift without design skills | Critical | Text + emoji, or generic e-card | AI-assisted experience builder with templates |
| UP-P-02 | Digital cards feel cheap and impersonal | Critical | Physical cards (slow, expensive) | Interactive 3D experiences that feel premium |
| UP-P-03 | Can't schedule a digital gift for the exact right moment | High | Send early and hope | Scheduled delivery with time-zone awareness |
| UP-P-04 | No way to include photos in a meaningful, interactive way | High | Photo album apps, slideshows | Photo blocks within scenes, interactive galleries |
| UP-P-05 | Don't know what to write | High | Generic messages, copy-paste | AI message generation with context |
| UP-P-06 | Long-distance gifting is expensive and slow | High | Amazon gift cards (impersonal) | Instant digital experiences with personal touch |
| UP-P-07 | No way to create a multi-step surprise experience | Medium | Multiple texts/emails | Scene-based experience builder |
| UP-P-08 | Apology communications have no good digital format | Medium | Long text, phone call | Dedicated apology experience templates |
| UP-P-09 | Can't attach a real gift to a digital experience | Medium | Separate gift card purchase | Integrated reward/gift card system |
| UP-P-10 | Experiences can't be private or password-protected | Medium | Nothing | Password protection, private links |

### 9.2 Business User Problems (Ranked by Severity)

| # | Problem | Severity | Current Workaround | MemorableDay Solution |
|---|---|---|---|---|
| UP-B-01 | Post-purchase experience is generic and forgettable | Critical | Klaviyo/Mailchimp templates | Branded interactive experiences |
| UP-B-02 | Delay communications damage brand trust | Critical | Cold automated email | Empathetic apology experience with reward |
| UP-B-03 | No scalable way to make customers feel individually appreciated | Critical | Batch emails | Personalized automated experiences |
| UP-B-04 | Can't measure the impact of customer experience on retention | High | Anecdotal, NPS surveys | Experience analytics with conversion tracking |
| UP-B-05 | No integration between order data and customer experience | High | Manual campaigns | Shopify/WooCommerce integration with triggers |
| UP-B-06 | Brand experience is inconsistent across touchpoints | High | Style guides (often ignored) | Brand settings applied to all experiences |
| UP-B-07 | Agencies can't manage multiple client brands efficiently | High | Separate accounts per client | Multi-brand workspace with agency features |
| UP-B-08 | Win-back campaigns have low engagement | Medium | Discount emails | Interactive win-back experiences |
| UP-B-09 | No way to attach rewards to customer communications | Medium | Separate coupon emails | Integrated reward system within experiences |
| UP-B-10 | Custom domain for experiences requires developer | Medium | Generic links | No-code custom domain setup |

### 9.3 Recipient Problems

| # | Problem | Severity | MemorableDay Solution |
|---|---|---|---|
| UP-R-01 | Digital communications are boring and forgettable | Critical | Interactive 3D experiences that demand attention |
| UP-R-02 | Links from brands feel like marketing, not appreciation | High | Genuinely beautiful, personalized experiences |
| UP-R-03 | Rewards are buried in emails and hard to redeem | High | Rewards revealed within the experience, easy redemption |
| UP-R-04 | Experiences don't work well on mobile | High | Mobile-first design, touch-optimized interactions |
| UP-R-05 | No way to share the experience with others | Medium | Built-in sharing, social preview |

---

*Next: [Positioning, Value Proposition & Principles →](04-positioning-value-principles.md)*
