# 16 — API

**Section:** §35 API  
**PRD Index:** [← Account & Team](15-account-team-agency-white-label.md) | [Next: Payments →](17-payments-lemon-squeezy-entitlements.md)

---

## §35 API

### 35.1 API Philosophy

The MemorableDay API enables businesses to integrate experience creation and delivery into their own systems — without using the MemorableDay dashboard. It is the foundation for deep integrations, custom workflows, and enterprise use cases.

**API principles:**
- RESTful design with predictable, consistent endpoints
- Comprehensive documentation with examples
- Versioned to prevent breaking changes
- Secure by default (API key authentication, rate limiting)
- Developer-friendly (clear error messages, sandbox environment)

### 35.2 API Use Cases

| Use Case | Description |
|---|---|
| **Create experience** | Programmatically create an experience from a template |
| **Trigger experience** | Send an experience to a specific customer |
| **Pass customer data** | Provide customer data for personalization |
| **Pass order data** | Provide order data for business experiences |
| **Retrieve analytics** | Get performance data for experiences |
| **Manage campaigns** | Create and manage campaigns |
| **Generate links** | Generate experience URLs for use in other systems |
| **Manage rewards** | Create and track rewards |
| **Webhook management** | Register and manage outbound webhooks |

### 35.3 API Authentication

**Authentication method:** API Key (Bearer token)

```
Authorization: Bearer sk_live_xxxxxxxxxxxxxxxxxxxx
```

**API key types:**

| Key Type | Description | Permissions |
|---|---|---|
| **Live key** | Production API key | Full access |
| **Test key** | Sandbox API key | Full access (no real sends) |
| **Read-only key** | Analytics and data retrieval only | Read only |
| **Restricted key** | Custom permission set | Configurable |

**Requirements:**
- `PRD-API-001`: API keys must be generated in the business dashboard
- `PRD-API-002`: API keys must be revocable at any time
- `PRD-API-003`: API keys must never be exposed in client-side code
- `PRD-API-004`: API key usage must be logged and viewable in the dashboard
- `PRD-API-005`: Multiple API keys must be supported per workspace

### 35.4 API Endpoints

#### 35.4.1 Experiences

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/v1/experiences` | List all experiences |
| `POST` | `/v1/experiences` | Create a new experience |
| `GET` | `/v1/experiences/{id}` | Get experience details |
| `PUT` | `/v1/experiences/{id}` | Update an experience |
| `DELETE` | `/v1/experiences/{id}` | Delete an experience |
| `POST` | `/v1/experiences/{id}/publish` | Publish an experience |
| `POST` | `/v1/experiences/{id}/send` | Send an experience to a recipient |
| `GET` | `/v1/experiences/{id}/analytics` | Get experience analytics |

#### 35.4.2 Templates

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/v1/templates` | List available templates |
| `GET` | `/v1/templates/{id}` | Get template details |
| `POST` | `/v1/experiences/from-template` | Create experience from template |

#### 35.4.3 Automations

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/v1/automations` | List all automations |
| `POST` | `/v1/automations` | Create a new automation |
| `GET` | `/v1/automations/{id}` | Get automation details |
| `PUT` | `/v1/automations/{id}` | Update an automation |
| `DELETE` | `/v1/automations/{id}` | Delete an automation |
| `POST` | `/v1/automations/{id}/trigger` | Manually trigger an automation |
| `GET` | `/v1/automations/{id}/analytics` | Get automation analytics |

#### 35.4.4 Customers

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/v1/customers` | List customers |
| `POST` | `/v1/customers` | Create a customer record |
| `GET` | `/v1/customers/{id}` | Get customer details |
| `PUT` | `/v1/customers/{id}` | Update customer data |
| `DELETE` | `/v1/customers/{id}` | Delete customer data |
| `GET` | `/v1/customers/{id}/experiences` | Get customer's experience history |

#### 35.4.5 Rewards

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/v1/rewards` | List rewards |
| `POST` | `/v1/rewards` | Create a reward |
| `GET` | `/v1/rewards/{id}` | Get reward details |
| `GET` | `/v1/rewards/{id}/redemptions` | Get reward redemptions |

#### 35.4.6 Analytics

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/v1/analytics/overview` | Get account-level analytics |
| `GET` | `/v1/analytics/experiences` | Get experience analytics |
| `GET` | `/v1/analytics/automations` | Get automation analytics |
| `GET` | `/v1/analytics/rewards` | Get reward analytics |

#### 35.4.7 Webhooks

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/v1/webhooks` | List registered webhooks |
| `POST` | `/v1/webhooks` | Register a new webhook |
| `GET` | `/v1/webhooks/{id}` | Get webhook details |
| `DELETE` | `/v1/webhooks/{id}` | Delete a webhook |
| `GET` | `/v1/webhooks/{id}/logs` | Get webhook delivery logs |

### 35.5 API Request/Response Format

**Request format:** JSON

**Response format:** JSON

**Standard response structure:**

```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 150
  }
}
```

**Error response structure:**

```json
{
  "success": false,
  "error": {
    "code": "EXPERIENCE_NOT_FOUND",
    "message": "The requested experience does not exist",
    "details": { ... }
  }
}
```

**Requirements:**
- `PRD-API-006`: All API responses must use consistent JSON structure
- `PRD-API-007`: Error codes must be documented and consistent
- `PRD-API-008`: Error messages must be human-readable and actionable
- `PRD-API-009`: Pagination must be supported for all list endpoints

### 35.6 API Rate Limiting

| Plan | Requests per minute | Requests per day |
|---|---|---|
| Business | 60 | 10,000 |
| Growth | 120 | 50,000 |
| Agency | 300 | 200,000 |
| Enterprise | Custom | Custom |

**Rate limit headers:**

```
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1234567890
```

**Requirements:**
- `PRD-API-010`: Rate limit headers must be included in every API response
- `PRD-API-011`: Rate limit exceeded must return HTTP 429 with retry-after header
- `PRD-API-012`: Rate limits must be per API key, not per IP

### 35.7 API Versioning

**Versioning strategy:** URL versioning (`/v1/`, `/v2/`)

**Requirements:**
- `PRD-API-013`: API versions must be maintained for at least 12 months after a new version is released
- `PRD-API-014`: Breaking changes must only be introduced in new API versions
- `PRD-API-015`: Deprecation notices must be sent via email and API response headers at least 90 days before removal

### 35.8 Sandbox Environment

**Requirements:**
- `PRD-API-016`: A sandbox environment must be available for testing
- `PRD-API-017`: Sandbox must use test API keys (prefixed `sk_test_`)
- `PRD-API-018`: Sandbox sends must not deliver real emails or SMS
- `PRD-API-019`: Sandbox must have the same API surface as production

### 35.9 API Documentation

**Requirements:**
- `PRD-API-020`: API documentation must be publicly available at `memorableday.online/docs/api`
- `PRD-API-021`: Documentation must include: endpoint reference, authentication guide, code examples, error reference
- `PRD-API-022`: Documentation must include interactive API explorer (e.g., Swagger UI or Redoc)
- `PRD-API-023`: Code examples must be available in at least: JavaScript, Python, PHP, Ruby
- `PRD-API-024`: Documentation must be kept up-to-date with every API change

### 35.10 API Availability by Plan

| Feature | Business | Growth | Agency | Enterprise |
|---|---|---|---|---|
| API access | ✓ | ✓ | ✓ | ✓ |
| Read-only API | ✓ | ✓ | ✓ | ✓ |
| Write API | ✓ | ✓ | ✓ | ✓ |
| Webhook management | ✓ | ✓ | ✓ | ✓ |
| Higher rate limits | — | ✓ | ✓ | ✓ |
| Custom rate limits | — | — | — | ✓ |
| Dedicated API support | — | — | — | ✓ |

### 35.11 Outbound Webhooks

MemorableDay sends webhook notifications to registered endpoints when events occur.

**Webhook events:**

| Event | Description |
|---|---|
| `experience.opened` | Recipient opened an experience |
| `experience.completed` | Recipient completed an experience |
| `experience.cta_clicked` | Recipient clicked a CTA |
| `reward.claimed` | Recipient claimed a reward |
| `automation.triggered` | Automation was triggered |
| `automation.sent` | Experience was sent via automation |
| `automation.failed` | Automation failed to send |

**Webhook payload:**

```json
{
  "event": "experience.opened",
  "timestamp": "2026-09-16T10:30:00Z",
  "data": {
    "experience_id": "exp_abc123",
    "experience_name": "Post-Purchase Thank You",
    "recipient_id": "cust_xyz789",
    "device_type": "mobile",
    "referrer": "sms"
  }
}
```

**Requirements:**
- `PRD-API-025`: Webhooks must be signed with HMAC-SHA256 using the webhook secret
- `PRD-API-026`: Webhook signature must be included in the `X-MemorableDay-Signature` header
- `PRD-API-027`: Webhooks must be retried on failure (up to 3 times with exponential backoff)
- `PRD-API-028`: Webhook delivery logs must be viewable in the dashboard

---

*Next: [Payments, Lemon Squeezy & Entitlements →](17-payments-lemon-squeezy-entitlements.md)*
