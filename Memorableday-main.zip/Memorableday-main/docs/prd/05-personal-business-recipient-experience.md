# 05 — Personal User Experience, Business User Experience & Recipient Experience

**Sections:** §13 Personal UX · §14 Business UX · §15 Recipient Experience  
**PRD Index:** [← Positioning](04-positioning-value-principles.md) | [Next: Experience Architecture →](06-experience-architecture-builder-scenes.md)

---

## §13 Personal User Experience

### 13.1 Design Philosophy for Personal Users

Personal users are not power users. They are people with something meaningful to say and no design skills to say it with. The personal experience must feel like a creative assistant, not a design tool.

**Core UX principles for personal users:**
- Maximum 3 clicks to start creating
- AI handles the hard parts (writing, structure, design)
- Templates provide the starting point
- Customization is optional, not required
- The result should look impressive even with minimal effort

### 13.2 Personal User Dashboard

The personal dashboard is intentionally simple. It should feel like a personal creative space, not enterprise software.

**Dashboard sections:**

| Section | Description |
|---|---|
| **Home / Overview** | Recent experiences, quick-create button, occasion reminders |
| **Create** | Start a new experience (occasion picker → template → builder) |
| **My Experiences** | All created experiences with status (draft, scheduled, sent, expired) |
| **Drafts** | Unfinished experiences |
| **Scheduled** | Experiences queued for future delivery |
| **Sent** | Delivered experiences with open/view status |
| **Templates** | Browse and favorite templates |
| **Favorites** | Saved templates and experiences |
| **Account** | Profile, billing, notifications, privacy |

**Dashboard requirements:**
- `PRD-CORE-001`: Dashboard must load in under 2 seconds on a 4G connection
- `PRD-CORE-002`: Quick-create button must be visible without scrolling on all screen sizes
- `PRD-CORE-003`: Occasion reminders should surface upcoming dates (birthdays, anniversaries) if the user has added them
- `PRD-CORE-004`: Experience status must be clearly visible (draft, scheduled, sent, viewed)

### 13.3 Personal Creation Flow

The creation flow is the most critical UX in the product. It must be fast, guided, and emotionally engaging.

**Recommended flow:**

```
Step 1: Occasion Selection
  → What's the occasion? (Birthday, Anniversary, Apology, etc.)
  → Or: "Something else" → custom occasion

Step 2: Recipient Information
  → Recipient's name (required)
  → Your relationship (optional, helps AI)
  → Any context (optional, helps AI)

Step 3: Template Selection
  → Filtered by occasion
  → Preview available
  → "Start from scratch" option

Step 4: AI Assistance (optional but recommended)
  → "Tell me about this person and what you want to say"
  → AI generates: message, scene suggestions, tone
  → Creator can accept, edit, or ignore

Step 5: Experience Builder
  → Scene-by-scene editing
  → Add/remove/reorder scenes
  → Customize text, photos, 3D objects, music

Step 6: Preview
  → Full recipient preview on mobile and desktop
  → "How will this look on their phone?"

Step 7: Delivery Settings
  → Send now / Schedule for later
  → Time zone selection
  → Expiration date (optional)
  → Password protection (optional)

Step 8: Publish & Share
  → Unique URL generated
  → Share via SMS, WhatsApp, email, copy link, QR code
  → Optional: notify me when they open it
```

**Flow requirements:**
- `PRD-CORE-005`: The creation flow must be completable in under 5 minutes for a first-time user using a template
- `PRD-CORE-006`: AI assistance must be optional — users who skip it must still be able to create a complete experience
- `PRD-CORE-007`: Preview must accurately represent the recipient experience on mobile
- `PRD-CORE-008`: The share step must offer at least: copy link, SMS, WhatsApp, email, QR code

### 13.4 Occasion Reminders

Personal users should be able to add important dates and receive reminders.

**Requirements:**
- `PRD-CORE-009`: Users can add recurring dates (birthdays, anniversaries) with names
- `PRD-CORE-010`: Reminders sent via email (and optionally push notification) X days before the occasion
- `PRD-CORE-011`: Reminder email includes a direct link to create an experience for that occasion
- `PRD-CORE-012`: Reminder timing is configurable (7 days, 3 days, 1 day before)

### 13.5 Personal User Mobile Experience

- `PRD-CORE-013`: The personal dashboard must be fully functional on mobile
- `PRD-CORE-014`: The creation flow must be completable on mobile (with some advanced editing features deferred to desktop)
- `PRD-CORE-015`: Touch interactions must be optimized for the creation flow

---

## §14 Business User Experience

### 14.1 Design Philosophy for Business Users

Business users are professionals. They need power, efficiency, and measurability. But they also need simplicity — most business users are not designers or developers. The business experience must feel like a professional tool that doesn't require a professional to use.

**Core UX principles for business users:**
- Onboarding guides them to first value quickly (first automation live within 30 minutes)
- Templates handle the design; they focus on brand and message
- Automation builder is visual and no-code
- Analytics are clear and actionable
- Integration setup is guided and tested

### 14.2 Business Dashboard

The business dashboard is more comprehensive than the personal dashboard but must remain navigable.

**Primary navigation:**

| Section | Description |
|---|---|
| **Overview** | Key metrics, recent activity, automation status, quick actions |
| **Experiences** | All created experiences with status and analytics |
| **Templates** | Browse, customize, and save templates |
| **Builder** | Create or edit an experience |
| **Automations** | Create and manage automated triggers |
| **Customers** | Customer list with experience history (if CRM integration active) |
| **Campaigns** | Manual campaign management |
| **Rewards** | Coupon and reward management |
| **Analytics** | Detailed performance analytics |
| **Integrations** | Connect stores, CRMs, email platforms |
| **Brand Settings** | Logo, colors, fonts, domain |
| **Team** | Team members, roles, permissions |
| **Billing** | Plan, usage, invoices |
| **API** | API keys, documentation, webhooks |
| **Settings** | Account, notifications, security |

**Dashboard requirements:**
- `PRD-BIZ-001`: Overview must show: active automations, experiences sent (last 30 days), open rate, and top-performing experience
- `PRD-BIZ-002`: Automation status must be visible at a glance (active/paused/error)
- `PRD-BIZ-003`: Quick action buttons: "Create Experience," "Create Automation," "View Analytics"

### 14.3 Business Onboarding Flow

Business onboarding is critical. The goal is to get a business to their first live automation within 30 minutes.

**Onboarding steps:**

```
Step 1: Business Profile
  → Business name, industry, website
  → Primary use case (post-purchase, retention, etc.)

Step 2: Brand Setup
  → Upload logo
  → Set brand colors (or auto-detect from website)
  → Choose brand font

Step 3: Connect Store (or skip)
  → Shopify / WooCommerce / Stripe / Zapier / Webhook
  → Guided connection with test event

Step 4: Choose First Automation
  → Recommended: "Post-Purchase Thank You"
  → Or: browse automation templates

Step 5: Select Experience Template
  → Pre-filtered for chosen automation
  → Preview with brand applied

Step 6: Customize Experience
  → Brand message, logo, colors already applied
  → Customize text, add reward (optional)

Step 7: Test
  → Send test experience to own email/phone
  → Verify it looks correct

Step 8: Activate
  → Automation goes live
  → Confirmation with expected impact

Step 9: Explore More
  → Suggested next automations
  → Link to analytics
```

**Onboarding requirements:**
- `PRD-BIZ-004`: Onboarding must be completable without connecting a store (manual trigger available)
- `PRD-BIZ-005`: Brand colors must be auto-detectable from a website URL (best-effort)
- `PRD-BIZ-006`: Test experience must be sendable to any email/phone without affecting live automations
- `PRD-BIZ-007`: Onboarding progress must be saveable and resumable

### 14.4 Business User Journeys

**Journey 1: Post-Purchase Automation Setup**

```
Business discovers MemorableDay (Google/App Store/referral)
→ Signs up (email or Google)
→ Business onboarding (brand setup)
→ Connects Shopify store
→ Selects "Post-Purchase Thank You" automation
→ Chooses template
→ Customizes with brand message and optional coupon
→ Tests with a real order
→ Activates automation
→ First customer receives experience
→ Business sees analytics (open rate, CTA clicks)
→ Business creates second automation (shipping, VIP)
→ Business upgrades plan for more automations
```

**Journey 2: Manual Campaign**

```
Business wants to send a holiday appreciation experience
→ Creates new campaign
→ Selects "Holiday Appreciation" template
→ Customizes with brand message and reward
→ Uploads or selects customer list
→ Schedules for December 20th
→ Reviews and confirms
→ Campaign sends on schedule
→ Analytics show open rate and reward redemption
```

**Journey 3: Delay Apology**

```
Shopify order is flagged as delayed (via webhook)
→ Automation triggers "Delay Apology" experience
→ Experience personalized with customer name, order details
→ Includes apology message, new estimated delivery, and $10 coupon
→ Customer receives experience
→ Customer opens, reads apology, claims coupon
→ Business sees: opened, coupon claimed, customer did not leave negative review
```

---

## §15 Recipient Experience

### 15.1 The Recipient Experience Is the Product

The recipient experience is the most important UX in the entire platform. It is what the creator is paying for. It is what creates the "wow" moment. It is what drives viral growth. It must be exceptional.

**Core requirements for the recipient experience:**
- `PRD-CORE-016`: Recipient experience must load in under 3 seconds on a 4G mobile connection
- `PRD-CORE-017`: Recipient experience must work without any account or login
- `PRD-CORE-018`: Recipient experience must be mobile-first and touch-optimized
- `PRD-CORE-019`: Recipient experience must work on all modern browsers (Chrome, Safari, Firefox, Edge)
- `PRD-CORE-020`: Recipient experience must be accessible (reduced motion, screen reader support, keyboard navigation)

### 15.2 Recipient Experience URL Structure

Every experience has a unique URL:

```
memorableday.online/e/[unique-id]
```

Where `[unique-id]` is a short, URL-safe, non-guessable identifier (e.g., `abc123xyz`).

**URL requirements:**
- `PRD-CORE-021`: Experience URLs must not be sequential or guessable
- `PRD-CORE-022`: URLs must be shareable via any channel (SMS, WhatsApp, email, social)
- `PRD-CORE-023`: URLs must generate correct Open Graph metadata for social preview (title, description, image)
- `PRD-CORE-024`: Business custom domain experiences must work at `gift.brand.com/e/[id]` or similar

### 15.3 Recipient Experience Flow

```
Recipient receives link (SMS, WhatsApp, email, etc.)
→ Taps link
→ Loading screen (branded, fast, beautiful)
→ Experience begins (Scene 1)
→ Recipient interacts (tap, swipe, click)
→ Scenes progress
→ Reward revealed (if applicable)
→ CTA presented (if applicable)
→ "Created with MemorableDay" attribution (subtle, beautiful)
→ Option to create their own experience
```

### 15.4 Loading Experience

The loading screen is the first impression. It must be beautiful and fast.

**Requirements:**
- `PRD-CORE-025`: Loading screen must show a branded animation (not a generic spinner)
- `PRD-CORE-026`: Loading screen must show the sender's name or a teaser ("Someone special sent you something")
- `PRD-CORE-027`: 3D assets must begin loading during the loading screen (progressive loading)
- `PRD-CORE-028`: If loading takes more than 5 seconds, show a progress indicator

### 15.5 Interaction Design

Recipients interact with experiences through:

- **Tap/click** to advance scenes or reveal content
- **Swipe** to navigate between scenes (mobile)
- **Tap to open** 3D objects (gift box, envelope)
- **Scroll** within a scene (for long content)
- **Pinch/zoom** for 3D objects (optional, advanced)

**Requirements:**
- `PRD-CORE-029`: All interactions must have clear visual affordances (the recipient knows what to do)
- `PRD-CORE-030`: Interactions must have satisfying haptic feedback on mobile (where supported)
- `PRD-CORE-031`: Auto-advance must be available for scenes that don't require interaction
- `PRD-CORE-032`: Recipients must be able to replay the experience

### 15.6 Accessibility for Recipients

- `PRD-CORE-033`: All 3D animations must have a reduced-motion alternative
- `PRD-CORE-034`: All text content must be readable by screen readers
- `PRD-CORE-035`: All interactive elements must be keyboard-navigable
- `PRD-CORE-036`: Color contrast must meet WCAG 2.1 AA standards
- `PRD-CORE-037`: Audio must be optional and controllable

### 15.7 Privacy for Recipients

- `PRD-CORE-038`: Recipients must not be required to create an account to view an experience
- `PRD-CORE-039`: Recipient analytics (open, view, interaction) must be collected with minimal data (no PII beyond what the creator provided)
- `PRD-CORE-040`: Password-protected experiences must require the password before any content loads
- `PRD-CORE-041`: Expired experiences must show a graceful expiration message, not a 404

### 15.8 Viral Attribution

The "Created with MemorableDay" attribution is a critical growth mechanism. It must be:

- **Beautiful** — not a banner or watermark, but an elegant part of the experience
- **Non-intrusive** — it should not interrupt the experience
- **Actionable** — it should lead to a clear path to create their own experience

**Requirements:**
- `PRD-CORE-042`: Attribution must appear at the end of the experience (after all content)
- `PRD-CORE-043`: Attribution must include a CTA: "Create your own experience"
- `PRD-CORE-044`: Clicking the CTA must lead to a landing page optimized for recipient-to-creator conversion
- `PRD-CORE-045`: White-label plans must be able to remove or replace the MemorableDay attribution
- `PRD-CORE-046`: Attribution must be visually consistent with the experience's design (not jarring)

### 15.9 Reward Redemption

When an experience includes a reward:

- `PRD-CORE-047`: Reward must be revealed at the appropriate scene (not immediately)
- `PRD-CORE-048`: Reward redemption must be one-tap (copy code, open store, etc.)
- `PRD-CORE-049`: Reward must be clearly explained (what it is, how to use it, when it expires)
- `PRD-CORE-050`: Reward redemption must be tracked and reported to the business

### 15.10 Unsupported Device Fallback

Not all devices support 3D. The experience must degrade gracefully.

- `PRD-CORE-051`: If 3D is not supported, show a beautiful 2D/animated fallback
- `PRD-CORE-052`: The fallback must preserve the emotional impact of the experience
- `PRD-CORE-053`: The fallback must be automatically detected and applied (no user action required)
- `PRD-CORE-054`: Creators must be able to preview the fallback experience

---

*Next: [Experience Architecture, Builder & Scene System →](06-experience-architecture-builder-scenes.md)*
