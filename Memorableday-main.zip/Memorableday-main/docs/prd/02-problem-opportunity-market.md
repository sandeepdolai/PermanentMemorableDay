# 02 — Problem, Opportunity & Target Market

**Sections:** §4 Problem · §5 Opportunity · §6 Target Market  
**PRD Index:** [← Executive Summary](01-executive-summary-vision-mission.md) | [Next: Personas →](03-personas-jtbd-user-problems.md)

---

## §4 Problem

### 4.1 The Personal Problem

People want to make the people they love feel special. The tools available to them are inadequate.

**Current options and their failures:**

| Option | What's Wrong |
|---|---|
| Text message | Impersonal, forgettable, no visual impact |
| Email | Cold, corporate-feeling, buried in inbox |
| Physical card | Requires planning, postage, time; arrives late or not at all for digital-native relationships |
| Digital greeting card (Hallmark, Moonpig) | Static, generic, feels like a checkbox not a gift |
| Video message (Loom, Cameo) | Requires recording, awkward for many people, no interactivity |
| Social media post | Public, performative, lacks intimacy |
| Gift delivery (Amazon, Uber Eats) | Transactional, no emotional narrative |

**The core personal problem:**

> There is no easy way to create a genuinely memorable, personalized, interactive digital moment for someone you care about — without being a designer, developer, or creative professional.

The gap between "I want to make this person feel amazing" and "I sent a text that says Happy Birthday 🎂" is enormous. No product has closed it.

**Secondary personal problems:**

- Long-distance relationships have no good digital gifting option
- People who are not creative feel unable to express deep emotion digitally
- Occasions like anniversaries, apologies, and "I miss you" have almost no dedicated digital tools
- Recipients of digital cards feel the sender didn't try very hard
- There is no way to create a digital experience that unfolds over time (scene by scene)

### 4.2 The Business Problem

E-commerce and DTC brands spend enormous resources acquiring customers and almost nothing making those customers feel valued after purchase.

**The post-purchase gap:**

| Touchpoint | Current Reality |
|---|---|
| Order confirmation | Generic transactional email |
| Shipping notification | Automated text with tracking link |
| Delivery confirmation | "Your package has been delivered" |
| Delay notification | Cold automated apology |
| VIP milestone | Nothing, or a generic discount email |
| Win-back | Batch-and-blast promotional email |

**The business problem in numbers:**

- The average e-commerce brand spends 5–7x more acquiring a new customer than retaining an existing one
- Customer retention rate improvement of 5% can increase profits by 25–95% (Bain & Company)
- 68% of customers leave a brand because they feel the company doesn't care about them (Rockefeller Corporation)
- Only 18% of companies focus on customer retention vs. 44% on acquisition (Invesp)
- A shipping delay handled poorly can permanently damage brand perception; handled well, it can increase loyalty

**The core business problem:**

> Businesses have no scalable, beautiful, personalized way to make individual customers feel genuinely appreciated — at the moments that matter most.

Transactional emails are the default because nothing better exists at scale. MemorableDay changes that.

**Secondary business problems:**

- Apology communications during delays are cold and often make things worse
- Post-purchase engagement is measured in clicks, not in customer sentiment
- Brand differentiation in e-commerce is increasingly difficult; customer experience is the last frontier
- Shopify merchants have no native tool for creating interactive post-purchase moments
- Agencies managing multiple brands have no unified platform for customer experience campaigns

### 4.3 The Recipient Problem

Recipients of digital communications are overwhelmed and desensitized.

- The average person receives 121 emails per day
- Push notification fatigue is at an all-time high
- Generic "Happy Birthday" texts feel obligatory, not meaningful
- Transactional emails are ignored or deleted without reading

**The recipient problem:**

> Recipients have been trained to expect nothing meaningful from digital communications. MemorableDay must break that expectation with an experience so different that it creates genuine surprise and delight.

---

## §5 Opportunity

### 5.1 Market Opportunity

**Digital Gifting Market:**
- Global digital gifting market: ~$20B (2024), projected $45B+ by 2030
- U.S. digital gifting: ~$8B, growing at 12–15% CAGR
- Key drivers: mobile-first behavior, remote relationships, instant delivery preference

**Customer Experience Software:**
- Global CX software market: ~$12B (2024), projected $23B by 2030
- Post-purchase experience is the fastest-growing sub-segment
- E-commerce brands increasingly compete on experience, not price

**Interactive Content:**
- Interactive content generates 2x more conversions than passive content (Demand Gen Report)
- 88% of marketers say interactive content differentiates them from competitors
- 3D web experiences are growing rapidly as WebGL/WebGPU adoption increases

**AI Personalization:**
- AI-powered personalization market: $2.7B (2024), growing at 23% CAGR
- Consumer expectation for personalized experiences has never been higher

### 5.2 The White Space

No product currently occupies the intersection of:

```
Interactive 3D Experiences
        +
Deep AI Personalization
        +
Business Automation
        +
Personal Gifting
        +
E-commerce Integration
```

This is the white space MemorableDay owns.

### 5.3 Specific Opportunities

| Opportunity | Size | Urgency |
|---|---|---|
| Post-purchase experience for Shopify merchants | 2M+ Shopify stores globally | High |
| Digital gifting for personal occasions | Hundreds of millions of occasions annually in the U.S. | High |
| Shipping delay communication | Every e-commerce brand faces delays | High |
| Long-distance relationship gifting | 14M+ long-distance couples in the U.S. | Medium |
| Agency white-label platform | Thousands of digital agencies | Medium |
| AI-powered experience creation | Universal — every creator benefits | High |
| Programmatic SEO for occasion keywords | Millions of monthly searches | High |

### 5.4 The Timing Advantage

Three technology trends converge to make MemorableDay possible now:

1. **3D on mobile is ready** — WebGL is supported on 98%+ of modern browsers; Three.js, Babylon.js, and similar libraries enable beautiful 3D without native apps
2. **AI generation is good enough** — LLMs can generate contextually appropriate, emotionally resonant messages; image generation can suggest visual themes
3. **Cloudflare's edge network** — enables global, low-latency delivery of rich experiences at a fraction of traditional CDN costs

### 5.5 Revenue Opportunity

**Conservative 3-year scenario:**
- 50,000 personal subscribers at $8/month average = $400K MRR
- 5,000 business subscribers at $49/month average = $245K MRR
- Total: ~$645K MRR / ~$7.7M ARR

**Optimistic 3-year scenario:**
- 200,000 personal subscribers at $10/month average = $2M MRR
- 20,000 business subscribers at $79/month average = $1.58M MRR
- Total: ~$3.58M MRR / ~$43M ARR

The business segment has significantly higher LTV and lower churn than personal, making it the primary revenue focus despite potentially smaller user numbers.

---

## §6 Target Market

### 6.1 Primary Market: United States

All product decisions, pricing, content, and SEO strategy are optimized for the U.S. market first.

**Why the U.S.:**
- Largest digital gifting market
- Highest e-commerce density (Shopify, WooCommerce, DTC brands)
- English-language SEO opportunity is largest
- USD pricing is standard for SaaS
- Cultural emphasis on celebration and customer experience

### 6.2 Personal User Market

**Total Addressable Market (TAM):**
- U.S. adults who send digital greetings/gifts: ~150M
- U.S. adults in long-distance relationships: ~14M
- U.S. adults who regularly celebrate occasions digitally: ~80M

**Serviceable Addressable Market (SAM):**
- U.S. adults willing to pay for a premium digital gifting experience: ~15–20M
- Estimated based on premium greeting card market + digital gift card adoption

**Serviceable Obtainable Market (SOM) — Year 3:**
- 200,000–500,000 paying personal subscribers

**Key Personal Segments:**

| Segment | Size | Willingness to Pay | Acquisition Channel |
|---|---|---|---|
| Romantic partners (anniversaries, Valentine's) | Very large | Medium-High | SEO, social |
| Long-distance relationships | Large | High | SEO, social |
| Parents celebrating children | Very large | Medium | SEO, referral |
| Gift shoppers (birthdays, holidays) | Massive | Low-Medium | SEO, viral |
| People in apology/reconciliation situations | Large | High | SEO |
| Friendship/social occasions | Very large | Low | Viral, social |

### 6.3 Business User Market

**Total Addressable Market (TAM):**
- U.S. e-commerce businesses: ~2.5M
- Shopify merchants (U.S.): ~700,000+
- DTC brands: ~50,000+
- Digital agencies: ~100,000+

**Serviceable Addressable Market (SAM):**
- E-commerce businesses with >$10K/month revenue that invest in CX: ~150,000
- Agencies managing e-commerce clients: ~20,000

**Serviceable Obtainable Market (SOM) — Year 3:**
- 20,000–50,000 paying business subscribers

**Key Business Segments:**

| Segment | Size | Willingness to Pay | Acquisition Channel |
|---|---|---|---|
| Shopify merchants (small-medium) | 700K+ | Medium | App store, SEO, content |
| DTC brands (established) | 50K+ | High | Direct sales, content |
| WooCommerce merchants | 500K+ | Medium | SEO, content |
| Digital agencies | 100K+ | High (white-label) | Direct, partnerships |
| Customer success teams | Large | High | Direct, LinkedIn |
| Marketing teams at mid-market brands | Large | High | Direct, content |

### 6.4 Secondary Markets (Future)

| Market | Timeline | Notes |
|---|---|---|
| Canada, UK, Australia | Year 2 | English-language, similar culture |
| Western Europe | Year 3 | Requires localization |
| Latin America | Year 3+ | Spanish localization, different payment methods |
| Enterprise (Fortune 500) | Year 3+ | Requires dedicated sales, SLAs, compliance |

### 6.5 Market Segmentation by Occasion

**Personal occasions (U.S. annual volume estimates):**

| Occasion | Annual U.S. Volume | Digital Opportunity |
|---|---|---|
| Birthdays | 330M+ | Very High |
| Valentine's Day | 190M+ | Very High |
| Mother's Day | 130M+ | High |
| Father's Day | 100M+ | High |
| Christmas/Holiday | 300M+ | High |
| Anniversaries | 50M+ | Very High |
| Graduations | 4M+ | High |
| Weddings | 2M+ | Medium |
| New baby | 3.6M+ | High |
| Apologies/reconciliation | Uncounted | Very High (underserved) |
| Long-distance moments | Ongoing | Very High (underserved) |

**Business occasions (U.S. annual volume estimates):**

| Occasion | Annual U.S. Volume | Digital Opportunity |
|---|---|---|
| E-commerce orders | 5B+ | Very High |
| Shipping notifications | 5B+ | Very High |
| Delivery confirmations | 5B+ | Very High |
| Delay apologies | 500M+ | Very High (underserved) |
| Customer milestones | 100M+ | High |
| Win-back campaigns | 500M+ | High |

---

*Next: [Personas, Jobs to Be Done & User Problems →](03-personas-jtbd-user-problems.md)*
