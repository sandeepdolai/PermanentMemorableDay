# 09 — AI System

**Section:** §21 AI System  
**PRD Index:** [← Interaction System](08-interaction-system.md) | [Next: Templates & Personalization →](10-templates-personalization-scheduling-sharing.md)

---

## §21 AI System

### 21.1 AI Philosophy

AI in MemorableDay must create genuine user value — not marketing hype. Every AI feature must pass this test:

> **Does this AI feature help a real user create a better experience than they could without it?**

If the answer is no, the feature doesn't belong.

The AI system has three core roles:

1. **Creator assistant** — helps personal users express what they feel but can't articulate
2. **Experience generator** — creates complete experience structures from a brief description
3. **Business intelligence** — helps businesses create personalized, contextually appropriate experiences at scale

AI amplifies human emotion. It does not replace it.

### 21.2 AI Feature Overview

| Feature | Audience | Priority | Value |
|---|---|---|---|
| AI Message Generator | Personal + Business | Core | Helps users write the perfect message |
| AI Experience Creator | Personal + Business | Core | Creates complete experience from a brief |
| AI Tone Adjuster | Personal + Business | Core | Adjusts message tone (romantic, funny, formal) |
| AI Scene Suggester | Personal + Business | Important | Suggests next scene based on context |
| AI Design Recommender | Personal + Business | Important | Suggests visual theme, colors, 3D objects |
| AI Personalization Engine | Business | Core | Personalizes experiences with customer data |
| AI Translation | Personal + Business | Advanced | Translates experiences to other languages |
| AI Content Rewriter | Personal + Business | Important | Rewrites existing content in a different style |
| AI Business Brief | Business | Important | Generates experience from business scenario |
| AI Occasion Detector | Personal | Important | Detects occasion from context and suggests templates |
| AI Image Suggestions | Personal + Business | Advanced | Suggests relevant images based on context |
| AI Narration | Personal | Experimental | Generates voice narration for scenes |

### 21.3 AI Message Generator

The most important AI feature. Helps users write the perfect message for any occasion.

**How it works:**

1. Creator provides context:
   - Occasion (birthday, anniversary, apology, etc.)
   - Recipient name and relationship
   - Key details ("we met in college," "she loves hiking," "I forgot our anniversary")
   - Desired tone (romantic, funny, heartfelt, sincere, playful)
   - Length preference (short, medium, long)

2. AI generates 3 message options

3. Creator can:
   - Accept one as-is
   - Edit any option
   - Ask for more options
   - Ask for a specific change ("make it funnier," "add a reference to our first date")

4. Message is inserted into the experience

**Requirements:**
- `PRD-AI-001`: AI must generate contextually appropriate messages, not generic templates
- `PRD-AI-002`: AI must support at least 5 tone options: romantic, heartfelt, funny, sincere, playful
- `PRD-AI-003`: AI must generate 3 distinct options (not variations of the same message)
- `PRD-AI-004`: AI must allow iterative refinement ("make it shorter," "add more humor")
- `PRD-AI-005`: AI-generated messages must be clearly labeled as AI-generated
- `PRD-AI-006`: AI must not generate offensive, inappropriate, or harmful content
- `PRD-AI-007`: AI generation must complete in under 5 seconds
- `PRD-AI-008`: AI must handle the case where the user provides minimal context gracefully

**Example interaction:**

```
User: "It's my wife's 10th anniversary. We met in college. We have two kids. 
       I want something emotional but not cheesy."

AI generates:

Option 1 (Heartfelt):
"Ten years ago, I sat next to you in a lecture hall and thought I was just 
going to class. I had no idea I was walking into the best chapter of my life.
Ten years, two kids, and a thousand ordinary moments that turned out to be 
extraordinary — because they were with you. Happy anniversary, [name]. 
Here's to ten thousand more."

Option 2 (Warm & Personal):
"A decade. Two kids. One home. Countless inside jokes. And still, every 
morning, I'm grateful it's you. Happy 10th anniversary, [name]. You make 
everything better."

Option 3 (Poetic):
"Ten years of choosing each other. Ten years of building something real. 
Ten years of you — and I'd choose every single one again. Happy anniversary."
```

### 21.4 AI Experience Creator

The most powerful AI feature. Creates a complete experience structure from a brief description.

**How it works:**

1. Creator describes what they want in natural language:
   - "Create a birthday experience for my best friend who loves travel and coffee"
   - "Create a shipping delay apology for a customer whose order is 3 days late, include a $10 coupon"

2. AI generates:
   - Recommended occasion/theme
   - Scene sequence (number of scenes, types)
   - 3D object suggestions for each scene
   - Message for each scene
   - Background/visual theme
   - Music suggestion
   - CTA (if applicable)
   - Reward (if applicable)

3. Creator reviews the generated experience in the builder

4. Creator can modify any element

5. Creator publishes

**Requirements:**
- `PRD-AI-009`: AI Experience Creator must generate a complete, publishable experience structure
- `PRD-AI-010`: Generated experience must be immediately previewable in the builder
- `PRD-AI-011`: Every element of the generated experience must be editable
- `PRD-AI-012`: AI must explain its choices ("I chose a rose because it's romantic and you mentioned love")
- `PRD-AI-013`: AI must generate experiences appropriate for the occasion (no romantic content for business apologies)
- `PRD-AI-014`: AI Experience Creator must complete in under 10 seconds
- `PRD-AI-015`: AI must handle business context (order data, customer name, delay reason) for business experiences

**Example business brief:**

```
Business input: "Our customer's order is three days late due to a carrier delay. 
                 Create a sincere apology experience and include a $10 coupon."

AI generates:

Scene 1: Package with clock animation
  Background: Warm, soft gradient
  3D Object: Package with clock overlay
  Message: "We owe you an apology, [Customer Name]."

Scene 2: Sincere message
  Text: "We know you were looking forward to receiving your order, and we're 
         truly sorry for the delay. Your package is on its way — it's just 
         taking a little longer than expected due to a carrier delay."
  
Scene 3: Updated information
  Order block: [Order number, new estimated delivery]
  Button: "Track My Order"

Scene 4: Reward reveal
  Reward block: $10 coupon code
  Text: "As a thank you for your patience, here's $10 off your next order."
  
Scene 5: Closing
  Text: "Thank you for being our customer. We'll make this right."
  Button: "Contact Support"
```

### 21.5 AI Tone Adjuster

Allows creators to adjust the tone of existing content without rewriting from scratch.

**Tone options:**

| Tone | Description | Example Use |
|---|---|---|
| **Romantic** | Warm, intimate, loving | Anniversary, Valentine's |
| **Heartfelt** | Sincere, emotional, genuine | Apology, gratitude |
| **Funny** | Playful, humorous, light | Birthday, friendship |
| **Formal** | Professional, respectful | Business, professional milestone |
| **Playful** | Fun, energetic, youthful | Birthday, celebration |
| **Sincere** | Direct, honest, earnest | Apology, thank you |
| **Inspirational** | Uplifting, motivating | Graduation, achievement |
| **Apologetic** | Remorseful, empathetic | Apology, delay |
| **Appreciative** | Grateful, warm | Thank you, VIP |
| **Luxury** | Elevated, premium, sophisticated | High-end brand experiences |

**Requirements:**
- `PRD-AI-016`: Tone adjustment must preserve the core meaning of the original message
- `PRD-AI-017`: Tone adjustment must show a before/after comparison
- `PRD-AI-018`: Creator must be able to accept, reject, or further adjust the result

### 21.6 AI Scene Suggester

When a creator is building an experience, AI suggests what scene should come next.

**How it works:**
- AI analyzes the current scenes in the experience
- AI suggests 3 options for the next scene (type, content, 3D object)
- Creator can accept, modify, or ignore

**Example:**
```
Current experience: [Intro scene] → [Rose bloom] → [Personal message]
AI suggests next scene:
  Option 1: Photo gallery ("Share some memories together")
  Option 2: Reward reveal ("Add a special gift")
  Option 3: Closing message ("End with a final thought")
```

**Requirements:**
- `PRD-AI-019`: Scene suggestions must be contextually appropriate (not random)
- `PRD-AI-020`: Suggestions must include a brief explanation of why each is recommended
- `PRD-AI-021`: Creator can request more suggestions if the initial ones don't fit

### 21.7 AI Design Recommender

Suggests visual design elements based on the occasion and content.

**Recommendations include:**
- Color palette (primary, secondary, accent)
- Background style (gradient, image, 3D environment)
- 3D object selection
- Font style (elegant, playful, modern, classic)
- Music genre/mood
- Overall visual theme

**Requirements:**
- `PRD-AI-022`: Design recommendations must be visually coherent (colors, fonts, and 3D objects must work together)
- `PRD-AI-023`: Recommendations must be occasion-appropriate
- `PRD-AI-024`: Creator can apply recommendations individually or all at once
- `PRD-AI-025`: Recommendations must not override existing creator choices without confirmation

### 21.8 AI Personalization Engine (Business)

For business users, AI personalizes experiences at scale using customer data.

**Personalization variables:**

| Variable | Source | Example |
|---|---|---|
| Customer name | Order data / CRM | "Thank you, Sarah" |
| Order number | Order data | "Order #12345" |
| Product name | Order data | "Your [Product Name] is on its way" |
| Order total | Order data | "Your $89 order" |
| Delivery date | Order data | "Arriving by Thursday" |
| Customer tier | CRM | "As a VIP customer..." |
| Order count | CRM | "This is your 5th order!" |
| Last purchase | CRM | "It's been 90 days since your last order" |
| Location | Order data | "Shipping to New York" |
| Custom fields | Business-defined | Any business-specific data |

**Requirements:**
- `PRD-AI-026`: Personalization must support at least 10 standard variables
- `PRD-AI-027`: Personalization must support custom business-defined variables
- `PRD-AI-028`: Personalization must gracefully handle missing data (fallback text)
- `PRD-AI-029`: Personalization preview must show how the experience looks with real data
- `PRD-AI-030`: Personalization must not expose one customer's data to another

### 21.9 AI Translation

Translates experiences to other languages for international recipients.

**Requirements:**
- `PRD-AI-031`: Translation must support at least: Spanish, French, Portuguese, German, Japanese (Phase 2)
- `PRD-AI-032`: Translation must preserve tone and emotional nuance, not just literal meaning
- `PRD-AI-033`: Creator must review and approve translation before publishing
- `PRD-AI-034`: Translation is an Advanced feature (Pro plan and above)

### 21.10 AI Content Rewriter

Rewrites existing content in a different style or for a different audience.

**Use cases:**
- "Make this more formal" (for a business experience)
- "Make this shorter" (for a concise experience)
- "Make this more emotional" (for a personal experience)
- "Simplify this" (for a clearer message)

**Requirements:**
- `PRD-AI-035`: Rewriter must preserve the core meaning and key facts
- `PRD-AI-036`: Rewriter must show a diff view (what changed)
- `PRD-AI-037`: Creator can accept, reject, or further modify the result

### 21.11 AI Usage Limits and Credits

AI features consume credits. Credits are allocated by plan.

| Plan | Monthly AI Credits | Overage |
|---|---|---|
| Free | 5 | Not available |
| Personal | 30 | Purchase additional |
| Pro | 100 | Purchase additional |
| Business | 200 | Purchase additional |
| Growth | 500 | Purchase additional |
| Agency | 1,000 | Purchase additional |
| Enterprise | Custom | Included |

**Credit consumption:**

| Action | Credits |
|---|---|
| AI Message Generator (3 options) | 1 credit |
| AI Experience Creator | 3 credits |
| AI Tone Adjustment | 1 credit |
| AI Scene Suggestion | 0.5 credits |
| AI Design Recommendation | 0.5 credits |
| AI Translation (per language) | 2 credits |
| AI Content Rewriter | 1 credit |

**Requirements:**
- `PRD-AI-038`: Credit balance must be visible in the builder and dashboard
- `PRD-AI-039`: Creator must be warned when credits are low (< 5 remaining)
- `PRD-AI-040`: Credit purchase must be available without plan upgrade
- `PRD-AI-041`: Credits must not expire within the billing period
- `PRD-AI-042`: Business plans must be able to purchase bulk AI credits

### 21.12 AI Safety and Content Moderation

- `PRD-AI-043`: AI must not generate content that is offensive, discriminatory, or harmful
- `PRD-AI-044`: AI must not generate content that could be used for phishing or fraud
- `PRD-AI-045`: AI output must be filtered through a content safety layer before display
- `PRD-AI-046`: Users who repeatedly attempt to generate harmful content must be flagged for review
- `PRD-AI-047`: AI must not generate content that impersonates real people or brands
- `PRD-AI-048`: AI-generated content must be clearly labeled as AI-generated in the builder

### 21.13 AI Cost Management

AI is a significant cost driver. The platform must manage AI costs carefully.

**Cost management strategies:**
- Credit system limits AI usage per plan
- Caching: identical or near-identical prompts return cached results
- Model selection: use appropriate model for each task (not always the most expensive)
- Rate limiting: prevent abuse of AI endpoints
- Monitoring: track AI cost per user, per plan, per feature

**Requirements:**
- `PRD-AI-049`: AI cost per user must be tracked and monitored
- `PRD-AI-050`: AI cost must be factored into plan pricing (AI credits must cover AI costs)
- `PRD-AI-051`: AI usage anomalies must trigger alerts for review

---

*Next: [Templates, Personalization, Scheduling & Sharing →](10-templates-personalization-scheduling-sharing.md)*
