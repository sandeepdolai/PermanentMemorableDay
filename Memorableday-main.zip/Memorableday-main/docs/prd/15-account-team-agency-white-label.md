# 15 — Account System, Team System, Agency System & White Label

**Sections:** §31 Account System · §32 Team System · §33 Agency System · §34 White Label  
**PRD Index:** [← Dashboard & Analytics](14-dashboard-analytics.md) | [Next: API →](16-api.md)

---

## §31 Account System

### 31.1 Account Types

MemorableDay has two primary account types:

| Account Type | Description | Dashboard |
|---|---|---|
| **Personal** | Individual user creating experiences for personal occasions | Personal dashboard |
| **Business** | Business or organization creating experiences for customers | Business dashboard |

Account type is selected at signup and can be changed later (with data migration).

### 31.2 Authentication

**Supported authentication methods:**

| Method | Description | Priority |
|---|---|---|
| **Email + Password** | Standard email/password authentication | Core |
| **Google OAuth** | Sign in with Google | Core |
| **Magic Link** | Passwordless email link | Important |
| **Apple Sign In** | Sign in with Apple (required for iOS apps) | Important |
| **SSO (SAML)** | Enterprise single sign-on | Enterprise |

**Requirements:**
- `PRD-SEC-013`: Passwords must be hashed using bcrypt or Argon2 (minimum cost factor 12)
- `PRD-SEC-014`: Email verification must be required before account activation
- `PRD-SEC-015`: Password reset must use time-limited, single-use tokens
- `PRD-SEC-016`: OAuth tokens must be stored securely and refreshed appropriately
- `PRD-SEC-017`: Failed login attempts must be rate-limited (5 attempts per 15 minutes)
- `PRD-SEC-018`: Suspicious login activity must trigger email notification to account owner
- `PRD-SEC-019`: Two-factor authentication (2FA) must be available (TOTP) on all plans
- `PRD-SEC-020`: 2FA must be required for Agency and Enterprise plans

### 31.3 Account Profile

**Personal account profile:**

| Field | Description |
|---|---|
| **Name** | Display name |
| **Email** | Primary email (used for login and notifications) |
| **Avatar** | Profile photo |
| **Time zone** | For scheduling |
| **Notification preferences** | Email, push |
| **Important dates** | Birthdays, anniversaries for reminders |
| **Language** | UI language preference |

**Business account profile:**

| Field | Description |
|---|---|
| **Business name** | Company name |
| **Website** | Business website URL |
| **Industry** | Business industry |
| **Contact email** | Primary contact email |
| **Time zone** | Business time zone |
| **Notification preferences** | Email, Slack, webhook |

### 31.4 Account Settings

**Security settings:**
- Change password
- Enable/disable 2FA
- View active sessions
- Revoke sessions
- View login history
- API key management

**Privacy settings:**
- Data export (GDPR/CCPA compliance)
- Account deletion
- Data retention preferences
- Marketing email opt-out

**Notification settings:**
- Experience opened notifications
- Scheduled experience reminders
- Billing notifications
- Product updates
- Marketing emails

**Requirements:**
- `PRD-SEC-021`: Account deletion must be available and must delete all user data within 30 days
- `PRD-SEC-022`: Data export must be available and must include all user-created content
- `PRD-SEC-023`: Active sessions must be viewable and revocable
- `PRD-SEC-024`: Login history must show last 10 logins with IP and device

### 31.5 Workspace

A **Workspace** is the organizational container for a business account. It contains:
- Brand settings
- Experiences
- Templates
- Automations
- Team members
- Integrations
- Analytics
- Billing

Personal accounts have a single implicit workspace. Business accounts have one workspace per plan (Agency plans can have multiple workspaces).

---

## §32 Team System

### 32.1 Team Philosophy

Business users often work in teams. The team system must support collaboration without complexity.

**Team principles:**
- Simple role system (not overly granular)
- Clear permissions that match real-world workflows
- Easy to add and remove team members
- Audit trail for important actions

### 32.2 Team Roles

| Role | Description | Permissions |
|---|---|---|
| **Owner** | Account owner; full control | All permissions |
| **Admin** | Full access except billing and ownership transfer | All except billing |
| **Editor** | Can create and edit experiences and automations | Create, edit, publish experiences; manage automations |
| **Analyst** | Read-only access to analytics | View analytics only |
| **Viewer** | Read-only access to experiences | View experiences only |

**Detailed permissions matrix:**

| Permission | Owner | Admin | Editor | Analyst | Viewer |
|---|---|---|---|---|---|
| Create experiences | ✓ | ✓ | ✓ | — | — |
| Edit experiences | ✓ | ✓ | ✓ | — | — |
| Publish experiences | ✓ | ✓ | ✓ | — | — |
| Delete experiences | ✓ | ✓ | — | — | — |
| Manage automations | ✓ | ✓ | ✓ | — | — |
| View analytics | ✓ | ✓ | ✓ | ✓ | — |
| Manage integrations | ✓ | ✓ | — | — | — |
| Manage team | ✓ | ✓ | — | — | — |
| Manage billing | ✓ | — | — | — | — |
| Manage brand settings | ✓ | ✓ | — | — | — |
| Manage API keys | ✓ | ✓ | — | — | — |

### 32.3 Team Management

**Team management features:**

| Feature | Description |
|---|---|
| **Invite member** | Send email invitation to join workspace |
| **Set role** | Assign role to team member |
| **Change role** | Update team member's role |
| **Remove member** | Remove team member from workspace |
| **View activity** | See team member's recent actions |
| **Pending invitations** | View and resend pending invitations |

**Requirements:**
- `PRD-BIZ-035`: Team invitations must expire after 7 days
- `PRD-BIZ-036`: Invited users must be able to join without an existing MemorableDay account
- `PRD-BIZ-037`: Team member removal must immediately revoke access
- `PRD-BIZ-038`: Owner cannot be removed without transferring ownership first

### 32.4 Team Limits by Plan

| Plan | Team Members |
|---|---|
| Free | 1 (owner only) |
| Personal | 1 (owner only) |
| Pro | 1 (owner only) |
| Business | 3 |
| Growth | 10 |
| Agency | 25 |
| Enterprise | Unlimited |

### 32.5 Approval Workflows (Advanced)

For businesses that require approval before publishing:

**Workflow:**
1. Editor creates experience
2. Editor submits for approval
3. Admin/Owner receives notification
4. Admin/Owner reviews and approves or rejects
5. If approved: experience is published
6. If rejected: editor receives feedback and can revise

**Requirements:**
- `PRD-BIZ-039`: Approval workflows are available on Growth plan and above
- `PRD-BIZ-040`: Approval notifications must be sent via email and in-app
- `PRD-BIZ-041`: Approval history must be logged for audit purposes

---

## §33 Agency System

### 33.1 Agency Philosophy

Agencies manage multiple client brands. They need a platform that lets them work efficiently across clients without switching accounts or losing context.

**Agency principles:**
- One login, multiple brands
- Clear separation between client brands
- Ability to create templates for specific clients
- Client-facing reporting without exposing other clients' data
- White-label capability (see §34)

### 33.2 Agency Workspace Structure

```
Agency Account
├── Agency Profile
├── Agency Team Members
├── Brand 1 (Client A)
│   ├── Brand Settings (logo, colors, domain)
│   ├── Experiences
│   ├── Templates
│   ├── Automations
│   ├── Analytics
│   └── Team Members (can be client-specific)
├── Brand 2 (Client B)
│   └── ...
└── Shared Resources
    ├── Shared Templates
    └── Shared Assets
```

### 33.3 Agency Features

| Feature | Description |
|---|---|
| **Multi-brand workspace** | Manage multiple client brands from one account |
| **Brand switching** | Switch between brands with one click |
| **Shared templates** | Templates available across all brands |
| **Brand-specific templates** | Templates private to a specific brand |
| **Client access** | Give clients limited access to their own brand |
| **Client reporting** | Generate reports for specific clients |
| **Approval workflows** | Require client approval before publishing |
| **Brand isolation** | Clients cannot see other clients' data |

**Requirements:**
- `PRD-BIZ-042`: Agency accounts must support at least 10 brands (Growth: 25, Enterprise: unlimited)
- `PRD-BIZ-043`: Brand switching must be instant (no page reload)
- `PRD-BIZ-044`: Client access must be strictly isolated — clients can only see their own brand
- `PRD-BIZ-045`: Agency team members can be assigned to specific brands or all brands

### 33.4 Client Management

**Client access levels:**

| Level | Description |
|---|---|
| **No access** | Agency manages everything; client has no login |
| **View only** | Client can view experiences and analytics |
| **Collaborator** | Client can create and edit experiences (requires approval) |
| **Full access** | Client has full access to their brand (except billing) |

**Requirements:**
- `PRD-BIZ-046`: Client access must be configurable per brand
- `PRD-BIZ-047`: Client login must show only their brand (not the agency dashboard)
- `PRD-BIZ-048`: Client reports must be shareable via a public link (no login required)

---

## §34 White Label

### 34.1 White Label Philosophy

White label allows businesses and agencies to present MemorableDay as their own product. The recipient experience should feel like it came directly from the brand — not from MemorableDay.

**White label levels:**

| Level | Description | Plan |
|---|---|---|
| **Branded** | MemorableDay branding visible | Free, Personal, Pro |
| **Co-branded** | Business logo + "Powered by MemorableDay" | Business |
| **White label** | No MemorableDay branding | Growth, Agency |
| **Full white label** | Custom domain + no MemorableDay branding | Agency, Enterprise |

### 34.2 White Label Features

| Feature | Description | Plan |
|---|---|---|
| **Remove MemorableDay branding** | No "Created with MemorableDay" attribution | Growth+ |
| **Custom domain** | Experiences served from brand's domain | Growth+ |
| **Custom email sender** | Emails sent from brand's domain | Growth+ |
| **Custom SMS sender** | SMS sent from brand's number | Agency+ |
| **Branded loading screen** | Loading screen shows brand logo only | Business+ |
| **Custom error pages** | Brand-specific error and expiration pages | Growth+ |
| **Custom favicon** | Brand favicon on experience pages | Business+ |
| **Remove MemorableDay from URL** | No "memorableday" in experience URL | Growth+ |

### 34.3 Custom Domain Requirements

See [§58 Custom Domains](24-hosting-cloudflare-domains.md) for full technical requirements.

**Business requirements:**
- `PRD-BIZ-049`: Custom domain setup must be completable without developer assistance
- `PRD-BIZ-050`: Custom domain must support SSL/TLS (automatically provisioned)
- `PRD-BIZ-051`: Custom domain experiences must be indistinguishable from native brand experiences
- `PRD-BIZ-052`: Custom domain must support wildcard subdomains for agency use

### 34.4 White Label Email

**Requirements:**
- `PRD-BIZ-053`: Custom email sender domain requires DNS verification (SPF, DKIM, DMARC)
- `PRD-BIZ-054`: Email templates must be fully brandable (logo, colors, footer)
- `PRD-BIZ-055`: Email unsubscribe must be handled by MemorableDay (compliance)

### 34.5 Agency White Label

Agencies can offer MemorableDay as their own product to clients:

- Agency's own branding on the platform
- Client-facing experiences show agency's brand (or client's brand)
- No MemorableDay branding anywhere in the client experience
- Agency can set their own pricing for clients

**Requirements:**
- `PRD-BIZ-056`: Agency white label is available on Agency plan and above
- `PRD-BIZ-057`: Agency white label must include custom domain support
- `PRD-BIZ-058`: Agency white label must not expose MemorableDay's pricing or plans to clients

---

*Next: [API →](16-api.md)*
