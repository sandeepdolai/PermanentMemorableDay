# 24 — Hosting, Cloudflare Infrastructure, Domain Architecture & Custom Domains

**Sections:** §55 Hosting · §56 Cloudflare Infrastructure Requirements · §57 Domain Architecture · §58 Custom Domains  
**PRD Index:** [← Security & Privacy](23-security-privacy-moderation.md) | [Next: Customer Support →](25-customer-support-admin-panel.md)

---

## §55 Hosting

### 55.1 Hosting Philosophy

MemorableDay's hosting strategy is built on three principles:

1. **Low initial cost** — the founder needs to launch without significant infrastructure investment
2. **Global performance** — recipients worldwide must get fast experiences
3. **Scalable architecture** — the system must grow without a complete rebuild

Cloudflare is the primary infrastructure provider. This is a fixed technical decision.

### 55.2 Why Cloudflare

| Benefit | Description |
|---|---|
| **Global CDN** | 300+ edge locations worldwide; experiences load fast everywhere |
| **Low cost** | Free tier covers significant traffic; paid tiers are cost-effective |
| **DDoS protection** | Enterprise-grade DDoS protection included |
| **SSL/TLS** | Automatic SSL for all domains |
| **Edge computing** | Cloudflare Workers enables server-side logic at the edge |
| **Object storage** | Cloudflare R2 for media storage (no egress fees) |
| **DNS** | Fast, reliable DNS management |
| **Security** | WAF, Bot Management, Rate Limiting |
| **Analytics** | Basic traffic analytics included |

### 55.3 Hosting Architecture Overview

```
                    ┌─────────────────────────────────────┐
                    │         Cloudflare Network           │
                    │                                     │
  User Request ────►│  DNS → WAF → CDN → Edge Cache      │
                    │                    ↓                │
                    │         Cloudflare Workers           │
                    │         (API, SSR, routing)          │
                    │                    ↓                │
                    │    ┌──────────────────────────┐     │
                    │    │   Origin Services         │     │
                    │    │   (if needed)             │     │
                    │    └──────────────────────────┘     │
                    │                                     │
                    │  ┌─────────┐  ┌─────────────────┐  │
                    │  │   R2    │  │  D1 / Hyperdrive │  │
                    │  │(Storage)│  │   (Database)     │  │
                    │  └─────────┘  └─────────────────┘  │
                    └─────────────────────────────────────┘
```

### 55.4 Service Mapping

| Service | Cloudflare Product | Notes |
|---|---|---|
| Public website hosting | Cloudflare Pages | Static/SSR; free tier generous |
| SaaS application hosting | Cloudflare Pages + Workers | |
| API / Backend | Cloudflare Workers | Edge-deployed serverless |
| Database | Cloudflare D1 (SQLite) or external | D1 is free tier; may need external DB at scale |
| Media storage | Cloudflare R2 | No egress fees; S3-compatible |
| CDN | Cloudflare CDN | Included with all plans |
| DNS | Cloudflare DNS | Free; fast |
| SSL/TLS | Cloudflare SSL | Automatic; free |
| DDoS protection | Cloudflare DDoS | Included |
| WAF | Cloudflare WAF | Free tier available; paid for advanced rules |
| Rate limiting | Cloudflare Rate Limiting | Free tier available |
| Email sending | External (Postmark, Resend) | Cloudflare Email Routing for receiving |
| SMS sending | External (Twilio) | No Cloudflare SMS product |
| Background jobs | Cloudflare Queues + Workers | |
| Scheduled jobs | Cloudflare Cron Triggers | |
| Real-time | Cloudflare Durable Objects | For real-time features |
| Video | Cloudflare Stream | Pay-per-minute; cost driver |
| Image optimization | Cloudflare Images | Pay-per-image; cost driver |

---

## §56 Cloudflare Infrastructure Requirements

### 56.1 What Stays Free/Low-Cost

**Free or near-free Cloudflare services:**

| Service | Free Tier | Notes |
|---|---|---|
| Cloudflare Pages | Unlimited sites, 500 builds/month | Sufficient for early stage |
| Cloudflare Workers | 100,000 requests/day | Sufficient for early stage |
| Cloudflare D1 | 5GB storage, 5M reads/day | Sufficient for early stage |
| Cloudflare R2 | 10GB storage, 1M Class A ops/month | Sufficient for early stage |
| Cloudflare CDN | Unlimited bandwidth | Free with any plan |
| Cloudflare DNS | Unlimited | Free |
| Cloudflare SSL | Unlimited | Free |
| Cloudflare DDoS | Unlimited | Free |

**Requirements:**
- `PRD-INFRA-002`: Architecture must maximize use of Cloudflare free tier during early stage
- `PRD-INFRA-003`: Architecture must be designed to scale beyond free tier without a rebuild

### 56.2 What Will Become a Cost Driver

**Cost drivers as the platform scales:**

| Service | Cost Driver | Estimated Cost at Scale |
|---|---|---|
| **Cloudflare Workers** | Requests beyond free tier | $0.50/million requests |
| **Cloudflare R2** | Storage beyond 10GB | $0.015/GB/month |
| **Cloudflare R2** | Class A operations (writes) | $4.50/million |
| **Cloudflare Stream** | Video storage and delivery | $5/1,000 minutes stored; $1/1,000 minutes delivered |
| **Cloudflare Images** | Image transformations | $5/100,000 images |
| **Cloudflare D1** | Reads/writes beyond free tier | $0.001/million reads |
| **AI API costs** | LLM API calls | $0.01–$0.10 per generation |
| **Email sending** | Per email sent | $0.001–$0.01 per email |
| **SMS sending** | Per SMS sent | $0.01–$0.05 per SMS |
| **Cloudflare WAF** | Advanced rules | $20+/month |

**Cost projections:**

| Stage | Monthly Traffic | Estimated Infrastructure Cost |
|---|---|---|
| Early (< 1,000 users) | < 100K requests/day | ~$0–$50/month |
| Growth (10,000 users) | ~1M requests/day | ~$200–$500/month |
| Scale (100,000 users) | ~10M requests/day | ~$2,000–$5,000/month |
| Large (1M users) | ~100M requests/day | ~$20,000–$50,000/month |

**Requirements:**
- `PRD-INFRA-004`: Infrastructure costs must be monitored monthly
- `PRD-INFRA-005`: Cost alerts must be configured for unexpected spikes
- `PRD-INFRA-006`: Video storage must be the primary cost management focus (most expensive per user)

### 56.3 Media Storage Strategy

Media (photos, videos, audio) is the largest storage cost driver.

**Strategy:**
- Photos: stored in Cloudflare R2; served via Cloudflare CDN; automatically optimized
- Videos: stored in Cloudflare R2 or Cloudflare Stream; transcoded on upload
- Audio: stored in Cloudflare R2; served via Cloudflare CDN
- 3D assets: stored in Cloudflare R2; served via Cloudflare CDN with aggressive caching

**Video cost management:**
- Video upload limits enforced by plan (see Entitlements)
- Videos are transcoded to efficient formats (H.264/MP4, VP9/WebM)
- Videos are compressed to reduce storage and bandwidth
- Unused videos (from deleted experiences) are purged after 30 days

**Requirements:**
- `PRD-INFRA-007`: Media storage costs must be tracked per user
- `PRD-INFRA-008`: Users who exceed storage limits must be notified and blocked from uploading
- `PRD-INFRA-009`: Deleted media must be purged from storage within 30 days

### 56.4 Database Strategy

**Early stage:** Cloudflare D1 (SQLite at the edge)
- Free tier: 5GB storage, 5M reads/day
- Sufficient for early stage (< 10,000 users)
- Limitations: no complex queries, limited write throughput

**Growth stage:** External database (Turso, PlanetScale, Neon, or similar)
- Distributed SQLite (Turso) or MySQL/PostgreSQL
- Better write throughput and query capabilities
- Higher cost but necessary for scale

**Requirements:**
- `PRD-INFRA-010`: Database architecture must support migration from D1 to external database without downtime
- `PRD-INFRA-011`: Database must be backed up daily
- `PRD-INFRA-012`: Database backups must be stored in a different region from the primary database

### 56.5 Background Processing

**Cloudflare Queues + Workers:**
- Webhook processing (Shopify, Lemon Squeezy, etc.)
- Email sending
- SMS sending
- Analytics aggregation
- Media processing (image optimization, video transcoding)
- Scheduled experience publishing

**Requirements:**
- `PRD-INFRA-013`: Background jobs must be idempotent (safe to retry)
- `PRD-INFRA-014`: Failed background jobs must be retried with exponential backoff
- `PRD-INFRA-015`: Background job failures must be logged and alerted

### 56.6 Monitoring and Observability

**Requirements:**
- `PRD-INFRA-016`: Application errors must be tracked (Sentry or equivalent)
- `PRD-INFRA-017`: API response times must be monitored (p50, p95, p99)
- `PRD-INFRA-018`: Uptime must be monitored with external checks (Better Uptime or equivalent)
- `PRD-INFRA-019`: Infrastructure costs must be monitored (Cloudflare dashboard + alerts)
- `PRD-INFRA-020`: Logs must be retained for at least 30 days

### 56.7 Disaster Recovery

**Requirements:**
- `PRD-INFRA-021`: Recovery Time Objective (RTO): < 4 hours
- `PRD-INFRA-022`: Recovery Point Objective (RPO): < 1 hour (daily backups minimum)
- `PRD-INFRA-023`: Disaster recovery plan must be documented and tested annually
- `PRD-INFRA-024`: Critical data must be backed up to a different cloud provider (not just Cloudflare)

---

## §57 Domain Architecture

### 57.1 Primary Domain

**Primary domain:** `memorableday.online`

This domain is the primary brand domain. All public-facing URLs use this domain.

### 57.2 Recommended URL Architecture

```
memorableday.online                    — Public website (homepage, SEO, marketing)
memorableday.online/e/[id]             — Recipient experience URLs
memorableday.online/pricing            — Pricing page
memorableday.online/blog/[slug]        — Blog
memorableday.online/templates/[slug]   — Template pages
memorableday.online/occasions/[slug]   — Occasion pages
memorableday.online/business/[slug]    — Business pages
memorableday.online/docs/              — Documentation
memorableday.online/api/               — API documentation

app.memorableday.online                — SaaS application (dashboard, builder)
app.memorableday.online/login          — Login
app.memorableday.online/signup         — Signup
app.memorableday.online/dashboard      — Dashboard
app.memorableday.online/builder/[id]   — Experience builder
```

**Why this architecture:**

| Decision | Rationale |
|---|---|
| Experience URLs on main domain (`/e/`) | Better SEO; simpler sharing; no subdomain confusion |
| App on `app.` subdomain | Clear separation of public website and application; allows different caching strategies |
| No `www.` | Modern convention; simpler |
| No `business.` subdomain | Business users use the same app; no need for separate subdomain |

### 57.3 Alternative Architecture Considered

**Alternative: `app.memorableday.online` for experiences**

```
memorableday.online                    — Public website
app.memorableday.online/e/[id]         — Recipient experiences
app.memorableday.online/dashboard      — Dashboard
```

**Why not recommended:**
- Experience URLs on `app.` subdomain are less shareable (looks like a SaaS tool, not a gift)
- SEO value of experience pages is lost on `app.` subdomain
- Recipients may be confused by `app.` in the URL

**Recommendation:** Keep experience URLs on the main domain (`memorableday.online/e/[id]`).

### 57.4 DNS Configuration

**Requirements:**
- `PRD-INFRA-025`: DNS must be managed through Cloudflare DNS
- `PRD-INFRA-026`: All subdomains must have SSL certificates (Cloudflare Universal SSL)
- `PRD-INFRA-027`: DNSSEC must be enabled
- `PRD-INFRA-028`: DNS TTL must be set appropriately (300s for frequently changing records, 3600s for stable records)

### 57.5 SSL/TLS Configuration

**Requirements:**
- `PRD-INFRA-029`: All domains must use HTTPS (HTTP redirects to HTTPS)
- `PRD-INFRA-030`: TLS 1.2 minimum; TLS 1.3 preferred
- `PRD-INFRA-031`: HSTS must be enabled with a minimum max-age of 1 year
- `PRD-INFRA-032`: SSL certificates must auto-renew (Cloudflare handles this)

---

## §58 Custom Domains

### 58.1 Custom Domain Use Cases

Businesses on Growth plan and above can serve experiences from their own domain:

| Use Case | Example |
|---|---|
| Brand subdomain | `gift.brand.com/e/[id]` |
| Experience subdomain | `experience.brand.com/e/[id]` |
| Thank you subdomain | `thankyou.brand.com/e/[id]` |
| Custom path | `brand.com/gift/[id]` (more complex) |

### 58.2 Custom Domain Setup Flow

**For the business:**

1. Business enters their desired custom domain in MemorableDay settings
2. MemorableDay provides DNS records to add (CNAME pointing to Cloudflare)
3. Business adds DNS records at their domain registrar
4. MemorableDay verifies DNS propagation
5. MemorableDay provisions SSL certificate (via Cloudflare for SaaS)
6. Custom domain is active

**Requirements:**
- `PRD-BIZ-064`: Custom domain setup must be completable without developer assistance
- `PRD-BIZ-065`: DNS verification must be automatic (no manual review required)
- `PRD-BIZ-066`: SSL certificate must be provisioned automatically (Cloudflare for SaaS)
- `PRD-BIZ-067`: Custom domain must be active within 24 hours of DNS propagation
- `PRD-BIZ-068`: Custom domain setup must include a verification step (test experience)

### 58.3 Cloudflare for SaaS

MemorableDay uses Cloudflare for SaaS to manage custom domains:

- Businesses add a CNAME record pointing to MemorableDay's Cloudflare zone
- Cloudflare for SaaS provisions SSL certificates for each custom domain
- Requests to custom domains are routed through Cloudflare to MemorableDay's infrastructure
- MemorableDay identifies the business from the custom domain and serves the correct experience

**Requirements:**
- `PRD-INFRA-033`: Cloudflare for SaaS must be used for custom domain management
- `PRD-INFRA-034`: Custom domain SSL certificates must auto-renew
- `PRD-INFRA-035`: Custom domain routing must add < 10ms latency

### 58.4 Custom Domain Limits

| Plan | Custom Domains |
|---|---|
| Free | 0 |
| Personal | 0 |
| Pro | 0 |
| Business | 0 |
| Growth | 1 |
| Agency | 5 |
| Enterprise | Unlimited |

### 58.5 Custom Domain Security

**Requirements:**
- `PRD-SEC-131`: Custom domains must be verified before activation (prevent domain hijacking)
- `PRD-SEC-132`: Custom domains must use HTTPS (no HTTP)
- `PRD-SEC-133`: Custom domain SSL certificates must be monitored for expiration
- `PRD-SEC-134`: Businesses must be notified if their custom domain DNS is misconfigured

### 58.6 Custom Email Sender Domain

Businesses on Growth plan and above can send emails from their own domain:

**Setup:**
1. Business enters their email sender domain (e.g., `mail.brand.com`)
2. MemorableDay provides DNS records (SPF, DKIM, DMARC)
3. Business adds DNS records
4. MemorableDay verifies DNS records
5. Custom email sender is active

**Requirements:**
- `PRD-BIZ-069`: Custom email sender must require SPF, DKIM, and DMARC verification
- `PRD-BIZ-070`: Custom email sender must be tested before activation
- `PRD-BIZ-071`: Email deliverability must be monitored for custom sender domains

---

*Next: [Customer Support & Admin Panel →](25-customer-support-admin-panel.md)*
