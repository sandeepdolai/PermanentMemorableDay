# 12 — Business Automation

**Section:** §27 Business Automation  
**PRD Index:** [← Rewards](11-rewards.md) | [Next: E-commerce Integrations →](13-ecommerce-integrations.md)

---

## §27 Business Automation

### 27.1 Automation Philosophy

Business automation is what makes MemorableDay scalable for businesses. Without automation, a business would need to manually create and send an experience for every customer interaction — impossible at scale.

With automation, a business sets up a rule once and every customer gets a personalized, beautiful experience at exactly the right moment — automatically.

**The automation promise:**
> Set it up once. Every customer feels like you made it just for them.

**Automation principles:**
- Automations must be no-code — any business user can set them up without technical knowledge
- Automations must be reliable — a failed automation is a missed customer moment
- Automations must be measurable — businesses must see the impact of every automation
- Automations must be controllable — businesses can pause, edit, or stop any automation at any time
- Automations must be testable — businesses can test before going live

### 27.2 Automation Architecture

An automation consists of:

```
Automation
├── Trigger (what starts the automation)
├── Conditions (optional filters)
├── Audience (who receives the experience)
├── Experience (what they receive)
├── Personalization (how it's customized for each recipient)
├── Reward (optional reward attached)
├── Schedule (when it's sent)
├── Delivery (how it's delivered — link, email, SMS)
└── Analytics (tracking and reporting)
```

### 27.3 Triggers

Triggers are events that start an automation. They come from connected integrations or manual inputs.

#### 27.3.1 E-commerce Triggers

| Trigger | Description | Source |
|---|---|---|
| `order.created` | New order placed | Shopify, WooCommerce, Stripe |
| `order.paid` | Order payment confirmed | Shopify, WooCommerce, Stripe |
| `order.fulfilled` | Order fulfilled/shipped | Shopify, WooCommerce |
| `order.shipped` | Shipping label created, tracking available | Shopify, WooCommerce |
| `order.out_for_delivery` | Package out for delivery | Carrier integration (future) |
| `order.delivered` | Package delivered | Carrier integration (future) |
| `order.delayed` | Shipping delay detected | Carrier integration / manual |
| `order.cancelled` | Order cancelled | Shopify, WooCommerce |
| `order.refunded` | Order refunded | Shopify, WooCommerce, Stripe |
| `order.partially_refunded` | Partial refund issued | Shopify, WooCommerce |
| `order.wrong_item` | Wrong item reported | Manual / support integration |
| `order.damaged` | Damaged item reported | Manual / support integration |

#### 27.3.2 Customer Milestone Triggers

| Trigger | Description | Condition |
|---|---|---|
| `customer.first_order` | Customer's first order | Order count = 1 |
| `customer.nth_order` | Customer's Nth order | Order count = N (configurable) |
| `customer.anniversary` | Customer's account anniversary | Account age = 1 year, 2 years, etc. |
| `customer.birthday` | Customer's birthday | If birthday data available |
| `customer.vip_status` | Customer reaches VIP status | Configurable threshold |
| `customer.loyalty_milestone` | Customer reaches loyalty milestone | Points threshold |
| `customer.total_spend` | Customer reaches spend milestone | Total spend threshold |

#### 27.3.3 Retention Triggers

| Trigger | Description | Condition |
|---|---|---|
| `customer.inactive_30` | Customer inactive for 30 days | No purchase in 30 days |
| `customer.inactive_60` | Customer inactive for 60 days | No purchase in 60 days |
| `customer.inactive_90` | Customer inactive for 90 days | No purchase in 90 days |
| `customer.inactive_180` | Customer inactive for 180 days | No purchase in 180 days |
| `customer.win_back` | Win-back campaign trigger | Configurable inactivity period |
| `customer.cart_abandoned` | Cart abandoned | Cart not completed after X hours |

#### 27.3.4 Campaign Triggers

| Trigger | Description |
|---|---|
| `campaign.manual` | Business manually triggers for a customer list |
| `campaign.scheduled` | Triggers at a specific date/time for a customer list |
| `campaign.recurring` | Triggers on a recurring schedule (weekly, monthly, annually) |
| `campaign.segment` | Triggers for a customer segment (e.g., all VIP customers) |

#### 27.3.5 Webhook / API Triggers

| Trigger | Description |
|---|---|
| `webhook.custom` | Any custom event sent via webhook |
| `api.trigger` | Triggered via MemorableDay API |
| `zapier.trigger` | Triggered via Zapier |
| `make.trigger` | Triggered via Make (Integromat) |

**Requirements:**
- `PRD-AUTO-001`: All triggers must be documented with their data payload
- `PRD-AUTO-002`: Triggers must be idempotent — duplicate events must not send duplicate experiences
- `PRD-AUTO-003`: Trigger deduplication window must be configurable (default: 24 hours)
- `PRD-AUTO-004`: Failed triggers must be logged and retried (up to 3 times)
- `PRD-AUTO-005`: Trigger history must be viewable in the automation dashboard

### 27.4 Conditions

Conditions filter which customers receive the experience when a trigger fires.

**Condition types:**

| Condition | Description | Example |
|---|---|---|
| **Order value** | Filter by order total | Only send for orders > $50 |
| **Product** | Filter by product purchased | Only send for Product X |
| **Collection** | Filter by product collection | Only send for "Premium" collection |
| **Customer tag** | Filter by customer tag | Only send to "VIP" tagged customers |
| **Customer location** | Filter by country/state | Only send to U.S. customers |
| **Order count** | Filter by total order count | Only send to customers with 1 order |
| **Customer email** | Filter by email domain | Exclude internal test orders |
| **Custom field** | Filter by custom business field | Any business-defined condition |

**Condition logic:**
- Conditions can be combined with AND / OR logic
- Conditions can be negated (NOT)
- Up to 5 conditions per automation (Growth plan: 10, Enterprise: unlimited)

**Requirements:**
- `PRD-AUTO-006`: Conditions must be configurable without technical knowledge
- `PRD-AUTO-007`: Condition builder must use plain language (not code)
- `PRD-AUTO-008`: Conditions must be testable with sample data before activation

### 27.5 Automation Builder UX

The automation builder is a no-code visual interface.

**Recommended layout:**

```
┌─────────────────────────────────────────────────────────────┐
│  Automation Name: [Post-Purchase Thank You]                 │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  TRIGGER                                                    │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  When: [Order is fulfilled ▼]                       │   │
│  │  From: [Shopify ▼]                                  │   │
│  └─────────────────────────────────────────────────────┘   │
│                          ↓                                  │
│  CONDITIONS (optional)                                      │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  + Add condition                                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                          ↓                                  │
│  EXPERIENCE                                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  [Select Experience ▼] or [Create New]              │   │
│  │  Preview: [thumbnail]                               │   │
│  └─────────────────────────────────────────────────────┘   │
│                          ↓                                  │
│  DELIVERY                                                   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Send via: [Email ▼] [SMS ▼] [Both ▼]              │   │
│  │  Delay: [Immediately ▼] or [After X hours/days]    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  [Test Automation]  [Save Draft]  [Activate]               │
└─────────────────────────────────────────────────────────────┘
```

**Requirements:**
- `PRD-AUTO-009`: Automation builder must be completable without technical knowledge
- `PRD-AUTO-010`: Automation builder must show a preview of the experience
- `PRD-AUTO-011`: Automation builder must allow testing with a real or simulated event
- `PRD-AUTO-012`: Automation builder must validate all required fields before activation
- `PRD-AUTO-013`: Automation builder must show estimated monthly sends based on historical data

### 27.6 Automation Delivery

When an automation triggers, the experience must be delivered to the customer.

**Delivery methods:**

| Method | Description | Requirements |
|---|---|---|
| **Email** | Experience link sent via email | Business must configure email sender |
| **SMS** | Experience link sent via SMS | Business must configure SMS provider |
| **Both** | Email + SMS | Both configured |
| **Webhook** | Experience URL sent to business's system | Business handles delivery |
| **API** | Experience URL returned via API | Business handles delivery |

**Email delivery:**
- MemorableDay sends the email on behalf of the business
- Email is branded with the business's logo and colors
- Email subject and body are customizable
- Email includes a prominent CTA button linking to the experience
- Email is sent from a MemorableDay-managed sending domain (initially)
- Custom email sender domain available on Growth plan and above

**SMS delivery:**
- MemorableDay sends SMS via a managed SMS provider (Twilio or similar)
- SMS contains a short message and the experience URL
- SMS message is customizable
- Custom SMS sender ID available on Growth plan and above

**Requirements:**
- `PRD-AUTO-014`: Email delivery must achieve > 95% deliverability rate
- `PRD-AUTO-015`: SMS delivery must achieve > 98% delivery rate
- `PRD-AUTO-016`: Delivery failures must be logged and retried
- `PRD-AUTO-017`: Business must be able to configure custom email sender domain (Growth+)
- `PRD-AUTO-018`: Delivery must respect customer opt-out preferences

### 27.7 Automation Limits by Plan

| Plan | Active Automations | Triggers Available |
|---|---|---|
| Free | 0 | None |
| Personal | 0 | None |
| Pro | 0 | None |
| Business | 3 | E-commerce + milestone |
| Growth | 10 | All triggers |
| Agency | 25 per brand | All triggers |
| Enterprise | Unlimited | All triggers + custom |

### 27.8 Pre-Built Automation Templates

To accelerate setup, MemorableDay provides pre-built automation templates:

| Template | Trigger | Experience | Business Value |
|---|---|---|---|
| **First Order Welcome** | `order.created` (count=1) | Welcome experience | Reduce first-order churn |
| **Post-Purchase Thank You** | `order.fulfilled` | Thank-you experience | Brand loyalty |
| **Shipping Notification** | `order.shipped` | Shipping experience | Reduce "where's my order" support |
| **Delivery Celebration** | `order.delivered` | Delivery experience | Post-purchase engagement |
| **Delay Apology** | `order.delayed` | Apology experience + coupon | Retain delayed customers |
| **5th Order VIP** | `customer.nth_order` (n=5) | VIP experience | Loyalty recognition |
| **Win-Back 90 Days** | `customer.inactive_90` | Win-back experience + offer | Reactivate lapsed customers |
| **Birthday Appreciation** | `customer.birthday` | Birthday experience + reward | Personal connection |
| **Review Request** | `order.delivered` + 3 days | Review request experience | Social proof |
| **Referral Invitation** | `order.delivered` + 7 days | Referral experience | Viral growth |

### 27.9 Automation Analytics

**Per automation:**

| Metric | Description |
|---|---|
| **Triggered** | Total times the automation fired |
| **Sent** | Total experiences sent |
| **Delivered** | Total experiences delivered (email/SMS) |
| **Opened** | Total experiences opened by recipient |
| **Open rate** | Opened / Sent |
| **Completed** | Recipients who completed the full experience |
| **Completion rate** | Completed / Opened |
| **CTA clicks** | Clicks on CTA buttons |
| **Rewards claimed** | Rewards claimed by recipients |
| **Revenue attributed** | Revenue from orders using reward codes |
| **Errors** | Failed sends with error details |

**Requirements:**
- `PRD-AUTO-019`: Automation analytics must be available in real-time (or near real-time)
- `PRD-AUTO-020`: Automation analytics must show trends over time (7 days, 30 days, 90 days)
- `PRD-AUTO-021`: Automation errors must be visible with actionable error messages
- `PRD-AUTO-022`: Automation analytics must be exportable (CSV)

### 27.10 Automation Safety

**Requirements:**
- `PRD-AUTO-023`: Automations must have a daily send limit per customer (default: 1 experience per customer per day)
- `PRD-AUTO-024`: Automations must respect customer opt-out preferences
- `PRD-AUTO-025`: Automations must have a global rate limit to prevent spam
- `PRD-AUTO-026`: Businesses must be able to add customers to a suppression list
- `PRD-AUTO-027`: Automations must not send to invalid email addresses or phone numbers
- `PRD-AUTO-028`: Automation errors must not silently fail — all errors must be logged and visible

### 27.11 Drip Sequences (Advanced)

A drip sequence is a series of automations triggered in sequence:

**Example:**
```
Order delivered
→ Day 0: Delivery celebration experience
→ Day 3: Review request experience
→ Day 7: Referral invitation experience
→ Day 30: "How are you enjoying it?" experience
```

**Requirements:**
- `PRD-AUTO-029`: Drip sequences are available on Growth plan and above
- `PRD-AUTO-030`: Drip sequences support up to 10 steps
- `PRD-AUTO-031`: Each step can have its own conditions (e.g., skip review request if customer already reviewed)
- `PRD-AUTO-032`: Drip sequences can be paused for a specific customer (e.g., if they contact support)

---

*Next: [E-commerce Integrations →](13-ecommerce-integrations.md)*
