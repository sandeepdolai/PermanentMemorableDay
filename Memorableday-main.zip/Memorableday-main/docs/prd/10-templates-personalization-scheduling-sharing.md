# 10 — Templates, Personalization, Scheduling & Sharing

**Sections:** §22 Template System · §23 Personalization · §24 Scheduling · §25 Sharing  
**PRD Index:** [← AI System](09-ai-system.md) | [Next: Rewards →](11-rewards.md)

---

## §22 Template System

### 22.1 Template Philosophy

Templates are the on-ramp to creation. They must be:

- **Beautiful by default** — every template looks impressive without customization
- **Occasion-specific** — templates are organized by occasion, not by design style
- **Fully editable** — templates are starting points, not constraints
- **Regularly updated** — new templates added for seasonal occasions and business scenarios
- **Discoverable** — templates are findable through search, browse, and AI recommendation

### 22.2 Template Structure

A template is a pre-built Experience with:
- A defined scene sequence
- Pre-configured 3D objects and animations
- Placeholder text (clearly marked for replacement)
- Pre-selected color palette and fonts
- Optional background music suggestion
- Optional reward placeholder

Templates do not contain personal information. They contain structure and style.

### 22.3 Template Categories

#### Personal Templates

| Category | Templates (Examples) | Occasions |
|---|---|---|
| **Romantic** | Rose Bloom, Starry Night, Love Letter, Heart Burst | Anniversary, Valentine's, "I love you" |
| **Birthday** | Confetti Explosion, Birthday Cake, Balloon Party, Surprise Box | Birthday |
| **Friendship** | Memory Wall, Adventure Together, Thank You Friend | Friendship, Thank you |
| **Family** | Family Milestone, Parent Appreciation, Sibling Love | Family occasions |
| **Apology** | Sincere Rose, Heartfelt Sorry, Peace Offering | Apology, reconciliation |
| **Celebration** | Achievement Unlocked, Graduation Day, New Chapter | Graduation, promotion, new job |
| **Holiday** | Christmas Magic, New Year Countdown, Thanksgiving Gratitude | Seasonal holidays |
| **Long Distance** | Thinking of You, Miss You, Virtual Hug | Long-distance relationships |
| **New Beginnings** | New Baby, New Home, Welcome | Life milestones |
| **Just Because** | Surprise!, Thinking of You, Random Act of Love | No specific occasion |
| **Elegant** | Minimal Love, Luxury Moment, Sophisticated | Premium aesthetic |
| **Playful** | Funny Birthday, Silly Sorry, Joke Reveal | Humorous occasions |
| **Emotional** | Deep Gratitude, Proud of You, You Matter | Emotional support |

#### Business Templates

| Category | Templates (Examples) | Trigger |
|---|---|---|
| **Post-Purchase** | First Order Welcome, Thank You for Choosing Us, Premium Unboxing | Order created |
| **Shipping** | Your Package Is Moving, On Its Way, Delivery Journey | Order shipped |
| **Delivery** | It's Here!, Unboxing Moment, Your Order Arrived | Order delivered |
| **Delay Apology** | We're Sorry for the Wait, Delay with Care, Making It Right | Order delayed |
| **VIP** | You're Our VIP, Exclusive Member, Top Customer | Customer milestone |
| **Loyalty** | 5th Order Celebration, 1 Year Together, Loyal Customer | Order milestone |
| **Win-Back** | We Miss You, Come Back, Special Offer | Customer inactive |
| **Review Request** | How Did We Do?, Share Your Experience, Your Opinion Matters | Post-delivery |
| **Referral** | Share the Love, Tell a Friend, Referral Reward | Post-purchase |
| **Holiday Campaign** | Holiday Appreciation, Season's Greetings, New Year Offer | Seasonal |
| **Product Launch** | Something New, Introducing..., First Look | Product launch |
| **Apology** | We Made a Mistake, Making It Right, Our Sincere Apology | Error/issue |

### 22.4 Template Discovery

**Browse interface:**
- Filter by: Occasion, Audience (Personal/Business), Style (Romantic/Playful/Elegant/etc.), 3D Object
- Sort by: Popular, New, Trending, Recommended
- Search: Full-text search across template names and descriptions
- Preview: Full-screen preview before selecting

**AI-powered recommendation:**
- When creator describes their occasion, AI recommends the most appropriate templates
- "Based on what you told me, here are 3 templates that might work"

**Requirements:**
- `PRD-CORE-102`: Template library must contain at least 50 templates at launch
- `PRD-CORE-103`: Templates must be previewable without selecting them
- `PRD-CORE-104`: Template preview must show the full recipient experience
- `PRD-CORE-105`: Templates must be searchable by keyword
- `PRD-CORE-106`: New templates must be added at least monthly

### 22.5 Template Limits by Plan

| Plan | Available Templates |
|---|---|
| Free | 10 (curated selection) |
| Personal | 50+ (all personal templates) |
| Pro | All templates |
| Business | All business templates + all personal |
| Growth | All templates + priority access to new templates |
| Agency/Enterprise | All templates + custom template creation |

### 22.6 Custom Templates

**For businesses:**
- Businesses can save any customized experience as a template
- Custom templates are private to the workspace
- Custom templates can be shared across team members
- Agency plans can create templates for specific clients

**Requirements:**
- `PRD-CORE-107`: Custom template creation must be available on Business plan and above
- `PRD-CORE-108`: Custom templates must be editable and deletable
- `PRD-CORE-109`: Custom templates must support brand settings (logo, colors applied automatically)

### 22.7 Template Marketplace (Future)

A future opportunity to allow third-party designers to create and sell templates:

- Designers submit templates for review
- MemorableDay reviews for quality and appropriateness
- Approved templates listed in marketplace
- Revenue sharing: 70% designer / 30% MemorableDay
- Buyers purchase templates with credits or one-time payment

This is an **Experimental** feature for Phase 4+. See [Future Opportunities](30-future-opportunities.md).

---

## §23 Personalization

### 23.1 Personalization Philosophy

Personalization is what transforms a template into a moment. The platform must make deep personalization easy — not just name insertion, but genuine contextual adaptation.

**Levels of personalization:**

| Level | Description | Who Does It |
|---|---|---|
| **Basic** | Name, occasion, date | Creator (manual) |
| **Contextual** | Relationship details, shared memories, personal references | Creator (with AI assistance) |
| **Dynamic** | Order data, customer data, real-time variables | Business automation |
| **AI-generated** | AI creates personalized content from context | AI system |

### 23.2 Personal User Personalization

**What creators can personalize:**

| Element | How |
|---|---|
| Recipient name | Text field → inserted into messages and 3D text |
| Sender name | Text field → used in closing messages |
| Personal message | Free text or AI-generated |
| Photos | Upload from device or cloud storage |
| Videos | Upload from device |
| Voice message | Record in browser |
| Music | Choose from library or upload |
| Important dates | Used in countdown timers and messages |
| Shared memories | Text descriptions used by AI for message generation |
| Occasion details | Used by AI for experience generation |

**Requirements:**
- `PRD-CORE-110`: Recipient name must be automatically inserted into all text blocks that contain the `{{recipient_name}}` placeholder
- `PRD-CORE-111`: Photo upload must support JPEG, PNG, HEIC, and WebP formats
- `PRD-CORE-112`: Photo upload must support up to 20 photos per experience (plan-dependent)
- `PRD-CORE-113`: Video upload must support MP4, MOV, and WebM formats
- `PRD-CORE-114`: Voice message recording must work in browser without additional software
- `PRD-CORE-115`: Music library must contain at least 50 royalty-free tracks at launch

### 23.3 Business Personalization

**Dynamic variables for business experiences:**

| Variable | Syntax | Source |
|---|---|---|
| Customer first name | `{{customer.first_name}}` | Order/CRM data |
| Customer last name | `{{customer.last_name}}` | Order/CRM data |
| Order number | `{{order.number}}` | Order data |
| Order total | `{{order.total}}` | Order data |
| Product name | `{{order.product_name}}` | Order data |
| Estimated delivery | `{{order.estimated_delivery}}` | Order data |
| Tracking URL | `{{order.tracking_url}}` | Order data |
| Coupon code | `{{reward.coupon_code}}` | Reward system |
| Business name | `{{business.name}}` | Brand settings |
| Custom field | `{{custom.field_name}}` | Business-defined |

**Requirements:**
- `PRD-BIZ-008`: All dynamic variables must be validated before experience activation
- `PRD-BIZ-009`: Missing variables must use graceful fallbacks (e.g., "Valued Customer" if name is missing)
- `PRD-BIZ-010`: Variable preview must show how the experience looks with real data
- `PRD-BIZ-011`: Business must be able to define custom variables for their specific use case

### 23.4 Photo and Media Personalization

**Photo handling:**
- Photos are uploaded to Cloudflare R2 (object storage)
- Photos are automatically optimized (resized, compressed, converted to WebP)
- Photos are served via Cloudflare CDN
- Photos are private by default (accessible only via the experience URL)

**Video handling:**
- Videos are uploaded to Cloudflare R2
- Videos are transcoded to web-optimized formats (MP4/H.264, WebM/VP9)
- Videos are served via Cloudflare CDN with adaptive bitrate
- Video size limits apply by plan

**Storage limits by plan:**

| Plan | Photo Storage | Video Storage | Total Storage |
|---|---|---|---|
| Free | 100MB | 0 | 100MB |
| Personal | 1GB | 500MB | 1.5GB |
| Pro | 5GB | 2GB | 7GB |
| Business | 10GB | 5GB | 15GB |
| Growth | 25GB | 10GB | 35GB |
| Agency | 50GB | 20GB | 70GB |
| Enterprise | Custom | Custom | Custom |

### 23.5 Music and Audio Personalization

**Music library:**
- Curated royalty-free music library organized by mood (romantic, celebratory, calm, playful, etc.)
- All tracks are properly licensed for use on the platform
- Tracks are available in 30-second, 60-second, and full-length versions
- Tracks loop seamlessly

**Custom music upload:**
- Personal and above plans can upload custom music
- Uploaded music must be owned by the creator or properly licensed
- Platform cannot verify licensing; creator accepts responsibility via terms of service
- Music is stored in Cloudflare R2

**Requirements:**
- `PRD-CORE-116`: Music library must contain at least 50 tracks at launch, organized by mood
- `PRD-CORE-117`: Music must fade in/out smoothly between scenes
- `PRD-CORE-118`: Music must be controllable by recipient (play/pause/mute)
- `PRD-CORE-119`: Music must not auto-play without user interaction (browser policy compliance)

---

## §24 Scheduling

### 24.1 Scheduling Philosophy

Timing is everything. A birthday experience that arrives at midnight in the recipient's time zone is magical. One that arrives three days late is forgettable. The scheduling system must be reliable, time-zone aware, and flexible.

### 24.2 Scheduling Options

| Option | Description | Use Case |
|---|---|---|
| **Publish now** | Experience is immediately accessible | Immediate sharing |
| **Schedule for later** | Experience publishes at a specific date/time | Birthday at midnight, anniversary |
| **Recurring** | Experience publishes on a recurring schedule | Annual birthday reminder |
| **Trigger-based** | Experience publishes when a business event occurs | Order shipped, order delivered |
| **Countdown-based** | Experience publishes when a countdown reaches zero | Surprise reveal |

### 24.3 Time Zone Handling

**Requirements:**
- `PRD-CORE-120`: Scheduling must support all IANA time zones
- `PRD-CORE-121`: Creator must be able to schedule in the recipient's time zone (not just their own)
- `PRD-CORE-122`: Scheduled time must be displayed in both creator's and recipient's time zones
- `PRD-CORE-123`: Scheduling must account for daylight saving time transitions
- `PRD-CORE-124`: Scheduling accuracy must be within 1 minute of the specified time

### 24.4 Scheduling Reliability

**Requirements:**
- `PRD-CORE-125`: Scheduled experiences must publish within 1 minute of the scheduled time
- `PRD-CORE-126`: Scheduling system must have 99.9% reliability (< 8.7 hours downtime per year)
- `PRD-CORE-127`: Failed scheduled publications must trigger an alert to the creator
- `PRD-CORE-128`: Creator must be able to reschedule a failed publication

### 24.5 Recurring Scheduling

For personal users who want to remember and celebrate recurring occasions:

- Annual birthday reminders (with option to create a new experience each year)
- Annual anniversary reminders
- Monthly "thinking of you" reminders

**Requirements:**
- `PRD-CORE-129`: Recurring scheduling is available on Personal plan and above
- `PRD-CORE-130`: Recurring experiences can use the same experience or prompt creator to create a new one
- `PRD-CORE-131`: Recurring schedule can be paused or cancelled at any time

### 24.6 Business Scheduling

For business users, scheduling integrates with automation:

- Trigger-based scheduling (order events)
- Campaign scheduling (send to a list at a specific time)
- Drip scheduling (send a series of experiences over time)

**Requirements:**
- `PRD-BIZ-012`: Business scheduling must support campaign scheduling to a customer list
- `PRD-BIZ-013`: Business scheduling must support drip sequences (experience 1 → wait 3 days → experience 2)
- `PRD-BIZ-014`: Business scheduling must support time-of-day optimization (send at 10am recipient's time)

### 24.7 Expiration

Experiences can have an expiration date after which they are no longer accessible.

**Requirements:**
- `PRD-CORE-132`: Expiration must be configurable per experience
- `PRD-CORE-133`: Expired experiences must show a graceful expiration message (not a 404)
- `PRD-CORE-134`: Creator must be notified before an experience expires (if they set an expiration)
- `PRD-CORE-135`: Creator can extend the expiration date of a published experience

---

## §25 Sharing

### 25.1 Sharing Philosophy

Every experience has a unique URL. Sharing must be frictionless — one tap to share via any channel. The experience URL is the product's distribution mechanism.

### 25.2 Experience URL

```
memorableday.online/e/[experience-id]
```

**URL requirements:**
- `PRD-CORE-136`: Experience IDs must be at least 8 characters, URL-safe, non-sequential
- `PRD-CORE-137`: URLs must be short enough to share via SMS without truncation
- `PRD-CORE-138`: URLs must work in all messaging apps (WhatsApp, iMessage, Messenger, etc.)

### 25.3 Sharing Channels

| Channel | Implementation | Priority |
|---|---|---|
| **Copy link** | One-click copy to clipboard | Core |
| **SMS** | Native SMS share (mobile) | Core |
| **WhatsApp** | WhatsApp share link | Core |
| **Email** | Email compose with link | Core |
| **Messenger** | Facebook Messenger share | Important |
| **Instagram** | Copy link (Instagram doesn't support direct share) | Important |
| **Twitter/X** | Twitter share link | Important |
| **QR Code** | Generated QR code for the experience URL | Important |
| **Embed** | Embed code for websites (Advanced) | Advanced |

### 25.4 Social Preview (Open Graph)

When an experience URL is shared on social media or messaging apps, it must generate a beautiful preview.

**Open Graph metadata:**

| Tag | Content |
|---|---|
| `og:title` | "[Sender Name] sent you something special" or custom title |
| `og:description` | "Open to see your experience" or occasion-specific text |
| `og:image` | A beautiful preview image of the experience (generated) |
| `og:url` | The experience URL |
| `og:type` | `website` |
| `twitter:card` | `summary_large_image` |

**Requirements:**
- `PRD-SEO-001`: Every experience must have unique Open Graph metadata
- `PRD-SEO-002`: Open Graph image must be generated automatically from the experience's first scene
- `PRD-SEO-003`: Open Graph image must be 1200x630px and optimized for fast loading
- `PRD-SEO-004`: Open Graph metadata must be served server-side (not client-side rendered)

### 25.5 QR Code

**Requirements:**
- `PRD-CORE-139`: QR codes must be generated automatically for every published experience
- `PRD-CORE-140`: QR codes must be downloadable as PNG and SVG
- `PRD-CORE-141`: QR codes must be scannable from a standard distance on a phone screen
- `PRD-CORE-142`: Business plans can generate branded QR codes (with logo in center)

### 25.6 Privacy and Access Control

| Setting | Description |
|---|---|
| **Unlisted** | Anyone with the link can view (default) |
| **Password protected** | Requires password to view |
| **One-time view** | Expires after first view |
| **Expiration date** | Expires at a specific date/time |
| **Private** | Only creator can view (draft mode) |

**Requirements:**
- `PRD-CORE-143`: Password protection must be enforced server-side (not just client-side)
- `PRD-CORE-144`: One-time view must be enforced server-side
- `PRD-CORE-145`: Creator can change privacy settings after publishing
- `PRD-CORE-146`: Creator can revoke access to a published experience (make it private)

### 25.7 Sharing Analytics

**Requirements:**
- `PRD-CORE-147`: Creator must be notified when recipient opens the experience (if enabled)
- `PRD-CORE-148`: Creator can see: opened (yes/no), open time, device type, number of views
- `PRD-CORE-149`: Business plans can see detailed analytics (see Analytics section)
- `PRD-CORE-150`: Sharing analytics must not expose recipient's personal information to creator

---

*Next: [Rewards →](11-rewards.md)*
