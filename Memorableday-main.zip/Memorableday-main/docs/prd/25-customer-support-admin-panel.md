# 25 — Customer Support & Admin Panel

**Sections:** §59 Customer Support · §60 Admin Panel  
**PRD Index:** [← Hosting & Cloudflare](24-hosting-cloudflare-domains.md) | [Next: Competitive Analysis →](26-competitive-analysis.md)

---

## §59 Customer Support

### 59.1 Support Philosophy

Support is a product feature, not a cost center. Every support interaction is an opportunity to:
- Retain a user who was about to churn
- Convert a free user to a paying user
- Learn about product problems
- Build brand loyalty

**Support principles:**
- Fast response times (users don't wait days for help)
- Helpful, human responses (not scripted deflection)
- Proactive support (help users before they need to ask)
- Self-service first (help center reduces support volume)

### 59.2 Support Tiers

| Tier | Plans | Response Time | Channels |
|---|---|---|---|
| **Community** | Free | Best effort (48–72h) | Help center, community forum |
| **Standard** | Personal, Pro | < 24 hours | Help center, email |
| **Priority** | Business, Growth | < 8 hours | Help center, email, chat |
| **Dedicated** | Agency, Enterprise | < 2 hours | Help center, email, chat, phone |

### 59.3 Support Channels

#### Help Center

A comprehensive self-service knowledge base at `memorableday.online/help`.

**Help center structure:**

| Section | Content |
|---|---|
| **Getting Started** | Account setup, first experience, onboarding |
| **Experience Builder** | How to use the builder, scenes, blocks |
| **3D System** | 3D objects, animations, customization |
| **AI Features** | AI message generator, experience creator |
| **Templates** | Finding, using, and customizing templates |
| **Scheduling** | How to schedule experiences |
| **Sharing** | How to share experiences |
| **Rewards** | Setting up and managing rewards |
| **Business Automations** | Creating and managing automations |
| **Integrations** | Shopify, WooCommerce, Zapier, etc. |
| **Analytics** | Understanding your analytics |
| **Billing** | Plans, payments, invoices |
| **Account & Security** | Profile, password, 2FA |
| **Troubleshooting** | Common issues and solutions |

**Requirements:**
- `PRD-CORE-220`: Help center must be searchable
- `PRD-CORE-221`: Help center articles must include screenshots and videos
- `PRD-CORE-222`: Help center must be accessible without login
- `PRD-CORE-223`: Help center must be indexed by search engines (SEO value)
- `PRD-CORE-224`: Help center articles must be rated (helpful/not helpful)

#### AI Support Chat

An AI-powered chat widget that answers common questions using the help center content.

**Requirements:**
- `PRD-CORE-225`: AI chat must be available 24/7
- `PRD-CORE-226`: AI chat must escalate to human support when it cannot answer
- `PRD-CORE-227`: AI chat must be able to look up account information (with authentication)
- `PRD-CORE-228`: AI chat must not make promises it cannot keep (billing changes, refunds)

#### Email Support

**Requirements:**
- `PRD-CORE-229`: Email support must be available at `support@memorableday.online`
- `PRD-CORE-230`: Email responses must include a ticket number for tracking
- `PRD-CORE-231`: Email support must use a ticketing system (Intercom, Zendesk, or similar)
- `PRD-CORE-232`: Support tickets must be categorized (billing, technical, product, abuse)

#### Live Chat (Priority and above)

**Requirements:**
- `PRD-CORE-233`: Live chat must be available during business hours (9am–6pm ET, Monday–Friday)
- `PRD-CORE-234`: Live chat must show estimated wait time
- `PRD-CORE-235`: Live chat must support file attachments (screenshots)

### 59.4 Support for Specific Scenarios

#### Billing Support

| Scenario | Resolution |
|---|---|
| Failed payment | Guide to update payment method via Lemon Squeezy portal |
| Unexpected charge | Explain billing cycle; offer refund if appropriate |
| Downgrade request | Guide through downgrade process; explain data retention |
| Cancellation | Process cancellation; offer pause option; collect feedback |
| Refund request | Evaluate per refund policy; process via Lemon Squeezy |

#### Technical Support

| Scenario | Resolution |
|---|---|
| Experience not loading | Check browser, device, network; escalate if needed |
| 3D not working | Check WebGL support; offer fallback |
| Integration not working | Check connection; review logs; escalate if needed |
| Automation not triggering | Check trigger configuration; review logs |
| Upload failing | Check file type, size; check storage limits |

#### Business Support

| Scenario | Resolution |
|---|---|
| Shopify integration issues | Guided reconnection; check permissions |
| Automation errors | Review error logs; fix configuration |
| Custom domain issues | Check DNS configuration; verify SSL |
| Analytics discrepancies | Explain data collection methodology |

### 59.5 Support Metrics

| Metric | Target |
|---|---|
| First response time (Standard) | < 24 hours |
| First response time (Priority) | < 8 hours |
| Resolution time (Standard) | < 72 hours |
| Resolution time (Priority) | < 24 hours |
| Customer satisfaction (CSAT) | > 90% |
| First contact resolution rate | > 70% |
| Help center deflection rate | > 60% |

### 59.6 Proactive Support

**Requirements:**
- `PRD-CORE-236`: Users with failed automations must receive an email notification
- `PRD-CORE-237`: Users approaching storage limits must receive a warning email
- `PRD-CORE-238`: Users with expiring trials must receive reminder emails
- `PRD-CORE-239`: Users who haven't created their first experience after 3 days must receive a help email

---

## §60 Admin Panel

### 60.1 Admin Panel Philosophy

The admin panel is the internal tool for MemorableDay's team to manage the platform. It must be:
- Secure (only accessible to authorized team members)
- Efficient (common tasks should be fast)
- Auditable (all admin actions are logged)
- Safe (destructive actions require confirmation)

### 60.2 Admin Panel Access

**Requirements:**
- `PRD-SEC-135`: Admin panel must be accessible only to MemorableDay team members
- `PRD-SEC-136`: Admin panel must require 2FA for all users
- `PRD-SEC-137`: Admin panel must be on a separate domain or path (not accessible to regular users)
- `PRD-SEC-138`: Admin actions must be logged with user, timestamp, and action details
- `PRD-SEC-139`: Admin panel must have role-based access (not all admins have all permissions)

### 60.3 Admin Panel Sections

#### User Management

| Feature | Description |
|---|---|
| **User list** | Search and filter all users |
| **User detail** | View user profile, plan, usage, experiences |
| **Impersonate user** | Log in as a user for support (with audit log) |
| **Suspend user** | Temporarily suspend account |
| **Delete user** | Permanently delete account and data |
| **Change plan** | Manually change user's plan |
| **Add credits** | Add AI credits or storage |
| **View billing** | View Lemon Squeezy subscription details |

#### Business Management

| Feature | Description |
|---|---|
| **Business list** | Search and filter all business accounts |
| **Business detail** | View business profile, plan, automations, analytics |
| **Integration status** | View connected integrations and their health |
| **Automation logs** | View automation trigger history |
| **Custom domain status** | View and manage custom domains |

#### Experience Moderation

| Feature | Description |
|---|---|
| **Flagged experiences** | Review experiences flagged by automated moderation or users |
| **Experience detail** | View full experience content |
| **Approve experience** | Clear flag, restore access |
| **Remove experience** | Take down experience, notify creator |
| **Escalate** | Escalate to legal/law enforcement |
| **Moderation history** | View all moderation actions |

#### Template Management

| Feature | Description |
|---|---|
| **Template list** | View all templates |
| **Create template** | Create new official template |
| **Edit template** | Edit existing template |
| **Publish/unpublish** | Control template availability |
| **Template analytics** | View template usage statistics |

#### 3D Asset Management

| Feature | Description |
|---|---|
| **Asset library** | View all 3D assets |
| **Upload asset** | Add new 3D asset |
| **Edit asset** | Update asset metadata |
| **Publish/unpublish** | Control asset availability |
| **Asset analytics** | View asset usage statistics |

#### AI Usage Management

| Feature | Description |
|---|---|
| **AI usage overview** | Total AI usage and cost |
| **Usage by user** | AI usage per user |
| **Usage by feature** | AI usage per feature |
| **Cost tracking** | AI cost per day/month |
| **Anomaly detection** | Users with unusual AI usage |

#### Storage Management

| Feature | Description |
|---|---|
| **Storage overview** | Total storage used |
| **Storage by user** | Storage per user |
| **Large files** | Files over a threshold |
| **Orphaned files** | Files not attached to any experience |
| **Purge orphaned** | Delete orphaned files |

#### Billing Management

| Feature | Description |
|---|---|
| **Revenue overview** | MRR, ARR, churn |
| **Subscription list** | All active subscriptions |
| **Failed payments** | Subscriptions with failed payments |
| **Refund management** | Process refunds via Lemon Squeezy |
| **Coupon management** | Create and manage promotional coupons |

#### Abuse Reports

| Feature | Description |
|---|---|
| **Report queue** | All pending abuse reports |
| **Report detail** | View report and reported content |
| **Resolve report** | Take action and close report |
| **Reporter history** | View reporter's history |
| **Reported user history** | View reported user's history |

#### Analytics (Internal)

| Feature | Description |
|---|---|
| **Platform overview** | Total users, experiences, revenue |
| **Growth metrics** | New signups, activations, conversions |
| **Engagement metrics** | DAU, WAU, MAU |
| **Viral metrics** | Recipient-to-creator conversion rate |
| **SEO metrics** | Organic traffic, keyword rankings |
| **Support metrics** | Ticket volume, response times, CSAT |

#### System Health

| Feature | Description |
|---|---|
| **Service status** | Status of all services |
| **Error rates** | API error rates |
| **Performance metrics** | Response times, throughput |
| **Infrastructure costs** | Cloudflare costs, AI costs |
| **Scheduled jobs** | Status of scheduled jobs |
| **Webhook health** | Webhook delivery rates |

#### Feature Flags

| Feature | Description |
|---|---|
| **Flag list** | All feature flags |
| **Enable/disable** | Toggle features on/off |
| **Rollout** | Gradual rollout to percentage of users |
| **User targeting** | Enable for specific users or plans |

#### CMS / Content Management

| Feature | Description |
|---|---|
| **Blog posts** | Create, edit, publish blog posts |
| **Help center articles** | Create, edit, publish help articles |
| **Landing pages** | Edit marketing landing pages |
| **Email templates** | Edit transactional email templates |
| **Announcement banners** | Create in-app announcements |

---

*Next: [Competitive Analysis →](26-competitive-analysis.md)*
