# 22 — Performance, Mobile & Accessibility

**Sections:** §49 Performance · §50 Mobile · §51 Accessibility  
**PRD Index:** [← UX & Design](21-ux-design-requirements.md) | [Next: Security & Privacy →](23-security-privacy-moderation.md)

---

## §49 Performance

### 49.1 Performance Philosophy

Performance is a product value, not an engineering concern. A slow experience is a broken experience. A slow recipient experience means the creator's effort was wasted. A slow dashboard means businesses can't work efficiently.

**Performance targets are product requirements.** They are not aspirational. They are the minimum acceptable standard.

### 49.2 Performance Targets

#### Public Website

| Metric | Target | Maximum |
|---|---|---|
| `PRD-PERF-001` | Lighthouse Performance Score | ≥ 90 | ≥ 80 |
| `PRD-PERF-002` | LCP (Largest Contentful Paint) | < 2.0s | < 2.5s |
| `PRD-PERF-003` | INP (Interaction to Next Paint) | < 100ms | < 200ms |
| `PRD-PERF-004` | CLS (Cumulative Layout Shift) | < 0.05 | < 0.1 |
| `PRD-PERF-005` | TTFB (Time to First Byte) | < 200ms | < 500ms |
| `PRD-PERF-006` | Total page weight (homepage) | < 500KB | < 1MB |

#### Recipient Experience

| Metric | Target | Maximum |
|---|---|---|
| `PRD-PERF-007` | Time to first scene (4G mobile) | < 2.5s | < 4s |
| `PRD-PERF-008` | Time to first 3D frame | < 3s | < 5s |
| `PRD-PERF-009` | 3D animation frame rate (mobile) | 60fps | 30fps |
| `PRD-PERF-010` | Total experience initial load | < 3MB | < 5MB |
| `PRD-PERF-011` | Scene transition time | < 300ms | < 500ms |

#### SaaS Application

| Metric | Target | Maximum |
|---|---|---|
| `PRD-PERF-012` | Dashboard initial load | < 2s | < 3s |
| `PRD-PERF-013` | Builder initial load | < 3s | < 5s |
| `PRD-PERF-014` | Analytics page load | < 2s | < 3s |
| `PRD-PERF-015` | API response time (p95) | < 200ms | < 500ms |
| `PRD-PERF-016` | Webhook processing time | < 1s | < 5s |

### 49.3 Performance Strategies

#### Asset Optimization

| Strategy | Description |
|---|---|
| **Image optimization** | All images served in WebP, with JPEG fallback; responsive sizes via `srcset` |
| **Image lazy loading** | Images below the fold loaded lazily |
| **Video optimization** | Videos transcoded to H.264/MP4 and VP9/WebM; adaptive bitrate |
| **3D asset compression** | Draco compression for geometry; KTX2 for textures |
| **Font optimization** | Self-hosted fonts; `font-display: swap`; subset to used characters |
| **CSS optimization** | Critical CSS inlined; non-critical CSS deferred |
| **JavaScript optimization** | Code splitting; tree shaking; deferred loading |

#### Caching Strategy

| Resource | Cache Duration | Cache Location |
|---|---|---|
| Static assets (JS, CSS) | 1 year (with content hash) | Cloudflare CDN |
| Images | 30 days | Cloudflare CDN |
| 3D assets | 30 days | Cloudflare CDN |
| API responses (public) | 5 minutes | Cloudflare CDN |
| API responses (authenticated) | No cache | — |
| Experience pages | 5 minutes (stale-while-revalidate) | Cloudflare CDN |

#### CDN Strategy

All static assets and experience pages are served from Cloudflare's global CDN:
- Assets are cached at the edge closest to the recipient
- Cache invalidation is triggered on content updates
- Cloudflare's Argo Smart Routing optimizes dynamic requests

#### Progressive Loading

For recipient experiences:
1. HTML shell loads immediately (< 500ms)
2. Critical CSS and fonts load (< 1s)
3. First scene content loads (< 2.5s)
4. 3D assets for first scene load (< 3s)
5. Subsequent scene assets preload in background

### 49.4 Performance Monitoring

**Requirements:**
- `PRD-PERF-017`: Core Web Vitals must be monitored in real-user monitoring (RUM)
- `PRD-PERF-018`: Performance regressions must trigger alerts
- `PRD-PERF-019`: Performance must be tested on real mobile devices (not just desktop emulation)
- `PRD-PERF-020`: Performance testing must include slow network simulation (3G, 4G)
- `PRD-PERF-021`: Performance budget must be enforced in CI/CD (builds fail if budget exceeded)

### 49.5 3D Performance Management

3D is the highest performance risk in the product. It must be managed carefully.

**3D performance strategies:**
- **Asset budgets**: Each 3D asset has a maximum file size and polygon count
- **LOD (Level of Detail)**: Simpler geometry on lower-end devices
- **Frustum culling**: Only render what's visible
- **Texture atlasing**: Combine multiple textures into one
- **Instancing**: Reuse geometry for repeated objects (e.g., confetti particles)
- **Progressive loading**: Low-res placeholder → high-res asset
- **Device detection**: Detect GPU capability and adjust quality accordingly

**Requirements:**
- `PRD-3D-022`: 3D system must detect device GPU capability on load
- `PRD-3D-023`: 3D quality must automatically adjust based on device capability
- `PRD-3D-024`: 3D must fall back to 2D if GPU performance is insufficient
- `PRD-3D-025`: 3D frame rate must be monitored; if it drops below 20fps, quality must be reduced

---

## §50 Mobile

### 50.1 Mobile-First Philosophy

Recipients will open experiences on their phones. This is not an assumption — it is a certainty. The recipient experience must be designed for mobile first, with desktop as a secondary consideration.

The creator experience must also work on mobile, though advanced editing features may be optimized for desktop.

### 50.2 Mobile Requirements for Recipient Experience

| Requirement | Description |
|---|---|
| `PRD-PERF-022` | Recipient experience must be fully functional on iOS Safari 15+ |
| `PRD-PERF-023` | Recipient experience must be fully functional on Android Chrome 90+ |
| `PRD-PERF-024` | Touch targets must be at least 44×44px |
| `PRD-PERF-025` | Swipe gestures must be smooth (no jank) |
| `PRD-PERF-026` | 3D must work on mid-range Android devices (Snapdragon 665 or equivalent) |
| `PRD-PERF-027` | Experience must not require landscape orientation |
| `PRD-PERF-028` | Experience must handle device rotation gracefully |
| `PRD-PERF-029` | Experience must work with iOS Safari's bottom navigation bar |
| `PRD-PERF-030` | Experience must not trigger iOS Safari's address bar on scroll |

### 50.3 Mobile Requirements for Creator Experience

| Requirement | Description |
|---|---|
| `PRD-PERF-031` | Personal dashboard must be fully functional on mobile |
| `PRD-PERF-032` | Template selection must be fully functional on mobile |
| `PRD-PERF-033` | Basic experience editing must be possible on mobile |
| `PRD-PERF-034` | Advanced editing (3D configuration, branching) may be desktop-only |
| `PRD-PERF-035` | Photo upload must work from mobile camera roll |
| `PRD-PERF-036` | Voice message recording must work on mobile |

### 50.4 Mobile Requirements for Business Dashboard

| Requirement | Description |
|---|---|
| `PRD-PERF-037` | Business dashboard overview must be fully functional on mobile |
| `PRD-PERF-038` | Analytics must be viewable on mobile |
| `PRD-PERF-039` | Automation status must be viewable and toggleable on mobile |
| `PRD-PERF-040` | Advanced automation building may be desktop-only |

### 50.5 Progressive Web App (PWA)

**Requirements:**
- `PRD-PERF-041`: The SaaS application must be installable as a PWA
- `PRD-PERF-042`: PWA must support offline viewing of previously loaded experiences
- `PRD-PERF-043`: PWA must support push notifications for experience opens and reminders
- `PRD-PERF-044`: PWA manifest must be configured with correct icons and theme colors

### 50.6 Native App (Future)

A native iOS and Android app is a future opportunity (Phase 3+). The PWA must be designed to eventually complement, not replace, a native app.

**Native app priority features:**
- Push notifications for experience opens
- Camera integration for photo/video capture
- Haptic feedback for interactions
- Face ID / Touch ID authentication
- Offline experience creation

---

## §51 Accessibility

### 51.1 Accessibility Philosophy

MemorableDay is about making people feel celebrated. That mission fails if the product is inaccessible to people with disabilities. Accessibility is not a compliance checkbox — it is a product value.

**Accessibility target:** WCAG 2.1 Level AA compliance across all public-facing pages and the SaaS application.

### 51.2 Visual Accessibility

| Requirement | Standard |
|---|---|
| `PRD-CORE-185` | Color contrast for normal text: ≥ 4.5:1 | WCAG 2.1 AA |
| `PRD-CORE-186` | Color contrast for large text (18px+): ≥ 3:1 | WCAG 2.1 AA |
| `PRD-CORE-187` | Color contrast for UI components: ≥ 3:1 | WCAG 2.1 AA |
| `PRD-CORE-188` | Color must not be the only way to convey information | WCAG 2.1 1.4.1 |
| `PRD-CORE-189` | Text must be resizable up to 200% without loss of content | WCAG 2.1 1.4.4 |
| `PRD-CORE-190` | Focus indicators must be visible and high-contrast | WCAG 2.1 2.4.7 |

### 51.3 Motor Accessibility

| Requirement | Standard |
|---|---|
| `PRD-CORE-191` | All functionality must be accessible via keyboard | WCAG 2.1 2.1.1 |
| `PRD-CORE-192` | No keyboard traps | WCAG 2.1 2.1.2 |
| `PRD-CORE-193` | Touch targets must be at least 44×44px | WCAG 2.1 2.5.5 |
| `PRD-CORE-194` | Drag-and-drop must have keyboard alternatives | WCAG 2.1 2.5.7 |
| `PRD-CORE-195` | No time limits on interactions (or time limits must be adjustable) | WCAG 2.1 2.2.1 |

### 51.4 Cognitive Accessibility

| Requirement | Standard |
|---|---|
| `PRD-CORE-196` | Page titles must be descriptive and unique | WCAG 2.1 2.4.2 |
| `PRD-CORE-197` | Navigation must be consistent across pages | WCAG 2.1 3.2.3 |
| `PRD-CORE-198` | Error messages must be specific and suggest corrections | WCAG 2.1 3.3.3 |
| `PRD-CORE-199` | Instructions must not rely solely on sensory characteristics | WCAG 2.1 1.3.3 |
| `PRD-CORE-200` | Language of page must be specified in HTML | WCAG 2.1 3.1.1 |

### 51.5 Screen Reader Accessibility

| Requirement | Standard |
|---|---|
| `PRD-CORE-201` | All images must have descriptive alt text | WCAG 2.1 1.1.1 |
| `PRD-CORE-202` | Decorative images must have empty alt text (alt="") | WCAG 2.1 1.1.1 |
| `PRD-CORE-203` | All form inputs must have associated labels | WCAG 2.1 1.3.1 |
| `PRD-CORE-204` | ARIA landmarks must be used correctly | WCAG 2.1 1.3.1 |
| `PRD-CORE-205` | Dynamic content changes must be announced to screen readers | WCAG 2.1 4.1.3 |
| `PRD-CORE-206` | Interactive elements must have accessible names | WCAG 2.1 4.1.2 |

### 51.6 Motion and Animation Accessibility

| Requirement | Standard |
|---|---|
| `PRD-CORE-207` | All animations must respect `prefers-reduced-motion: reduce` | WCAG 2.1 2.3.3 |
| `PRD-CORE-208` | No content must flash more than 3 times per second | WCAG 2.1 2.3.1 |
| `PRD-CORE-209` | Auto-playing animations must be pausable | WCAG 2.1 2.2.2 |
| `PRD-CORE-210` | 3D experiences must have a reduced-motion alternative | WCAG 2.1 2.3.3 |

### 51.7 Audio Accessibility

| Requirement | Standard |
|---|---|
| `PRD-CORE-211` | Audio must not auto-play | WCAG 2.1 1.4.2 |
| `PRD-CORE-212` | Audio controls must be visible and accessible | WCAG 2.1 1.4.2 |
| `PRD-CORE-213` | Voice messages must have a text transcript option | WCAG 2.1 1.2.1 |
| `PRD-CORE-214` | Videos must have captions | WCAG 2.1 1.2.2 |

### 51.8 Accessibility Testing

**Requirements:**
- `PRD-CORE-215`: Automated accessibility testing must be run in CI/CD (e.g., axe-core)
- `PRD-CORE-216`: Manual accessibility testing must be performed with screen readers (NVDA, VoiceOver)
- `PRD-CORE-217`: Accessibility testing must include keyboard-only navigation
- `PRD-CORE-218`: Accessibility issues must be tracked and prioritized in the product backlog
- `PRD-CORE-219`: Accessibility statement must be published at `memorableday.online/accessibility`

---

*Next: [Security, Privacy & Moderation →](23-security-privacy-moderation.md)*
